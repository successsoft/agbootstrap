<?php
//print_r($_POST);die;
require_once("dbconstants.class.php");
require_once("dbutils.class.php");
class USERSUTILS{
    /**
    * Get Banner Fields as array
    **/
    static function getFormFields (){
        $frmInpField_array = array(
            'txtUserId' => DBCONSTANTS::col_us_id,
            'txtFName'  => DBCONSTANTS::col_us_fname,
            'txtLName'  => DBCONSTANTS::col_us_lname,
            'txtEmail'  => DBCONSTANTS::col_us_email,
            'txtMobile' => DBCONSTANTS::col_us_mobile,
            'txtPass'   => DBCONSTANTS::col_us_pass,
            'txtDOB'    => DBCONSTANTS::col_us_dob,
            'txtGd'     => DBCONSTANTS::col_us_gen,
            'txtRfFrom' => DBCONSTANTS::col_us_rid,
            'txtRfBy'   => DBCONSTANTS::col_us_urid,
            'txtWss'    => DBCONSTANTS::col_us_wss,
            'regFtname' => DBCONSTANTS::col_us_ftname,
            'regNomi'   => DBCONSTANTS::col_us_nom,
            'regNrel'   => DBCONSTANTS::col_us_nomrl,
            'regAmno'   => DBCONSTANTS::col_us_mn2,
            'regOcp'    => DBCONSTANTS::col_us_occ,
            'regITyp'   => DBCONSTANTS::col_us_inctp,
            'regBkname' => DBCONSTANTS::col_us_bknm,
            'regBrname' => DBCONSTANTS::col_us_bcnm,
            'regIfsc'   => DBCONSTANTS::col_us_bkifsc,
            'regAcType' => DBCONSTANTS::col_us_acctp,
            'regAcName' => DBCONSTANTS::col_us_accnm,
            'regAcNo'   => DBCONSTANTS::col_us_accnum,
            'regPan'    => DBCONSTANTS::col_us_pan,
            'regAadhar' => DBCONSTANTS::col_us_aano,
            'regThname' => DBCONSTANTS::col_us_hdnm,
            'regThmno'  => DBCONSTANTS::col_us_hdno,
            'regjoinDat'=> DBCONSTANTS::col_us_dt
        );
        return $frmInpField_array;
    }
    
    /**
    * Insert or Updates the Banner Form
    **/
    static function saveForm($table, $srvFrmFieldValues){
        $wk_id = trim($_POST['txtUserId']);
        if(empty($wk_id)){
            //echo 'insert because new ';die;
            $wk_id = self::doInsertForm($table, $srvFrmFieldValues);
            $response_array['error'] = false;
            $response_array['wk_id'] = $wk_id;
            $response_array['msg']  = "User added successfully";
        }else{
            //echo 'update because new ';die;
            $wk_id = self::doUpdateForm($table, $srvFrmFieldValues);
            $response_array['error'] = false;
            $response_array['wk_id'] = $wk_id;
            $response_array['msg']  = "User updated successfully";
        }
        return $response_array; 
    }
    
    /**
    * Do Insert Form- Get insert coloumn
    **/
    static private function doInsertForm($table, $srvyFrm_InsertFieldValues){
        $insert_columns = array();
        UTILS::addInsertColumns($srvyFrm_InsertFieldValues, $insert_columns);
        
        
        $db_code = DBCONSTANTS::db_code;
        UTILS::default_timezone();

        
        //print_r($insert_columns);die;   
        $last_id = DBUTILS::exec_insertsql( $table, $insert_columns);
        return $last_id;
    }
    
    
    

    /**
    * Do Update Form- Get insert coloumn
    **/
    static private function doUpdateForm($table, $srvFrmFieldValues){
        
        $update_columns = array();
        UTILS::updateColumns($srvFrmFieldValues, $update_columns);
        //print_r($update_columns);die;
        
        UTILS::default_timezone();
        $date = date('Y-m-d H:i:s');
       
        
        UTILS::updateColumnsCustom($updateField_details, $update_columns);
        //print_r($update_columns);die;
        $update_row = array();
        $update_row = array(
            'txtUserId'      => DBCONSTANTS::col_us_id,
        );
        //print_r($update_row);die;
        $update_col = array();
        UTILS::addSearchColumns($update_row, $update_col);
        //print_r($update_col);die;
        if(sizeof($update_col) > 0){
            DBUTILS::exec_updatesql( $table, $update_columns, $update_col);
        }
        
        
        return trim($_POST['txtUserId']);
    }
    
}
