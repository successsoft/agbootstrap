<?php
  require_once("dbconstants.class.php");
  require_once("utils.class.php");
  require_once("dbutils.class.php");

 class LOGINUTILS{
    
     
    static function isValidAdmin($session){
        //print_r($_POST);die;
        $ui_columns = array();
        $ui_columns = array(
            'txtAdId'   => DBCONSTANTS::col_sa_id,
            'txtAdName' => DBCONSTANTS::col_sa_name,
            'txtAdPwd'  => DBCONSTANTS::col_sa_pwd,
            'txtAdLGId' => DBCONSTANTS::col_sa_lgtp
        );
        
        $searchField_details = array();
        $searchField_details = array(
            'username'      => DBCONSTANTS::col_sa_name,
        );
        
        //print_r($searchField_details);die;
        $search_columns = array();
        UTILS::PostData($searchField_details, $search_columns);
        
        //print_r($search_columns);
        $table =  DBCONSTANTS::db_code.DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_sa.DBCONSTANTS::db_code;
        
        $bindings = array();   
        $where = DBUTILS::filter2($search_columns, $bindings);
        $sql_query ="SELECT * FROM $table $where ";
        //print_r($sql_query);die;
        
        $data = DBUTILS::execute_column_query($ui_columns, $bindings, $sql_query);
        //print_r(sizeof($data));
        //print_r($data);die;
        $cnt = sizeof($data);
        if( $cnt == 0){
            return false;
        }else{
            $txtPassword = trim($_POST['txtAdPwd']); 
            $password = $data[0]['txtAdPwd']; 
            $check = UTILS::tep_validate_password($txtPassword, $password);
            if($check){
                //echo 'in';die;
                self::storeAdminInfoInSession($session,$data[0]);
                $response_array['error'] = false;
                $response_array['msg']  = 'Login Success';
                return $response_array;
            }else{
                //echo 'out';die;
                return false;
            }
        }
    }
    
    static function isValidUser($session){
        
        $ui_columns = array();
        $ui_columns = array(
            'hidUsId'   => DBCONSTANTS::col_us_id,
            'txtUt'     => DBCONSTANTS::col_us_ut,
            'txtUName'  => DBCONSTANTS::col_us_uname,
            'txtEId'    => DBCONSTANTS::col_us_eid,
            'txtPwd'    => DBCONSTANTS::col_us_pwd,
            'txtMNo'    => DBCONSTANTS::col_us_mno,
            'selState'  => DBCONSTANTS::col_us_stacc,
            'selDistrict'  => DBCONSTANTS::col_us_dtacc,
            'selBlock'  => DBCONSTANTS::col_us_bkacc,
        );
        
        $searchField_details = array();
        $searchField_details = array(
            'username'      => DBCONSTANTS::col_us_eid,
        );
        
        //print_r($searchField_details);die;
        $search_columns = array();
        UTILS::PostData($searchField_details, $search_columns);
        
        //print_r($search_columns);
        $table =  DBCONSTANTS::db_code.DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_us.DBCONSTANTS::db_code;
        
        $bindings = array();   
        $where = DBUTILS::filter2($search_columns, $bindings);
        $sql_query ="SELECT * FROM $table $where ";
        //print_r($sql_query);die;
        
        $data = DBUTILS::execute_column_query($ui_columns, $bindings, $sql_query);
        //print_r(sizeof($data));
        //print_r($data);die;
        $cnt = sizeof($data);
        if( $cnt == 0){
            return false;
        }else{
            $txtPassword = trim($_POST['password']); 
            $password = $data[0]['txtPwd']; 
            $check = UTILS::tep_validate_password($txtPassword, $password);
            if($check){
                //echo 'in';die;
                self::storeUserInfoInSession($session,$data[0]);
                $response_array['error'] = false;
                $response_array['msg']  = 'Login Success';
                return $response_array;
            }else{
                return false;
            }
        }
        
    }
    
    
    static function storeAdminInfoInSession($session, $data){
        $session = Session::getInstance();
        //TODO Move the keys as session variable constants in UserSession
        if(isset($_POST['remember'])){
            //echo "remember";die;
            /*setcookie("COId", $data[DBCONSTANTS::col_sa_id], time()+(60*60*24*365));
            setcookie("CONa", $data[DBCONSTANTS::col_sa_name], time()+(60*60*24*365));
            setcookie("COEl", $data[DBCONSTANTS::col_sa_eid], time()+(60*60*24*365));
            */
            //print_r($_COOKIE);die;
        }
        
        $session-> __set('TBOOK_ID',      $data['txtAdId']);
        $session-> __set('TBOOK_NAME',    $data['txtAdName']);
        $session-> __set('TBOOK_USTP',    $data['txtAdLGId']);
        $session-> __set('TBOOK_LGTP',    'A');
        $session-> __set('TBOOK_LGID',    $data['txtAdLGId']);
    }
    
    static function storeUserInfoInSession($session, $data){
        $session = Session::getInstance();
        //TODO Move the keys as session variable constants in UserSession
        if(isset($_POST['remember'])){
            //echo "remember";die;
            /*setcookie("COId", $data[DBCONSTANTS::col_sa_id], time()+(60*60*24*365));
            setcookie("CONa", $data[DBCONSTANTS::col_sa_name], time()+(60*60*24*365));
            setcookie("COEl", $data[DBCONSTANTS::col_sa_eid], time()+(60*60*24*365));
            */
            //print_r($_COOKIE);die;
        }
        
        $session-> __set('TBOOK_ID',      $data['hidUsId']);
        $session-> __set('TBOOK_NAME',    $data['txtUName']);
        $session-> __set('TBOOK_USTP',    $data['txtUt']);
        $session-> __set('TBOOK_ACCDT',   $data['selDistrict']);
        $session-> __set('TBOOK_ACCBK',   $data['selBlock']);
        $session-> __set('TBOOK_LGID',    $data['txtEId']);
        $session-> __set('TBOOK_LGTP',    'U');
    }
    
    
    
    
}