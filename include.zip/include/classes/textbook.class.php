<?php
//print_r($_POST);die;
require_once("dbconstants.class.php");
require_once("dbutils.class.php");
class TBOOKUTILS{
    /**
    * Get Banner Fields as array
    **/
    static function getFormFields (){
        $frmInpField_array = array(
            'hidTextBook'   => DBCONSTANTS::col_tbk_id,
            'selLang'   => DBCONSTANTS::col_tbk_langgid,
            'selClass'  => DBCONSTANTS::col_tbk_clsid,
            'selSub'    => DBCONSTANTS::col_tbk_subid,
            'selTm'     => DBCONSTANTS::col_tbk_tmid,
            'taDesp'    => DBCONSTANTS::col_tbk_desp,
            'fdname'    => DBCONSTANTS::col_tbk_fdnm,
            'oname'     => DBCONSTANTS::col_tbk_fonm,
            'fname'     => DBCONSTANTS::col_tbk_fsnm,
            'ext'       => DBCONSTANTS::col_tbk_ftp,
            'size'      => DBCONSTANTS::col_tbk_fsz,
            'bcfname'   => DBCONSTANTS::col_tbk_bkcv,
            'pdffname'  => DBCONSTANTS::col_tbk_pdf
        );
        return $frmInpField_array;
    }
    
    static function getFormMultipleFields (){
        $frmInpField_array = array(
            'hidTBMId'   => DBCONSTANTS::col_tbkm_id,
            'hidTBMTBId'   => DBCONSTANTS::col_tbkm_tbkid,
            'fdname'    => DBCONSTANTS::col_tbkm_fdnm,
            'oname'     => DBCONSTANTS::col_tbkm_fonm,
            'fname'     => DBCONSTANTS::col_tbkm_fsnm,
            'ext'       => DBCONSTANTS::col_tbkm_ftp,
            'size'      => DBCONSTANTS::col_tbkm_fsz
        );
        return $frmInpField_array;
    }
    
    /**
    * Insert or Updates the Banner Form
    **/
    static function saveForm($table, $srvFrmFieldValues){
        $tbk_id = trim($_POST['hidTextBook']);
        if(empty($tbk_id)){
            //echo 'insert because new ';die;
            $tbk_id = self::doInsertForm($table, $srvFrmFieldValues);
            $response_array['error'] = false;
            $response_array['tbk_id'] = $tbk_id;
            $response_array['msg']  = "Text Book added successfully";
        }else{
            //echo 'update because new ';die;
            $tbk_id = self::doUpdateForm($table, $srvFrmFieldValues);
            $response_array['error'] = false;
            $response_array['tbk_id'] = $tbk_id;
            $response_array['msg']  = "Text Book updated successfully";
        }
        return $response_array; 
    }
    
    static function saveMulForm($table, $srvFrmFieldValues){
        $tbk_id = trim($_POST['hidTBMId']);
        if(empty($tbk_id)){
            //echo 'insert because new ';die;
            $tbk_id = self::doInsertForm($table, $srvFrmFieldValues);
            $response_array['error'] = false;
            $response_array['msg']  = "Text Book added successfully";
        }else{
            //echo 'update because new ';die;
            $tbk_id = self::doUpdateForm2($table, $srvFrmFieldValues);
            $response_array['error'] = false;
            $response_array['msg']  = "Text Book updated successfully";
        }
        return $response_array; 
    }
    
    /**
    * Do Insert Form- Get insert coloumn
    **/
    static private function doInsertForm($table, $srvyFrm_InsertFieldValues){
        $insert_columns = array();
        UTILS::addInsertColumns($srvyFrm_InsertFieldValues, $insert_columns);
        $db_code = DBCONSTANTS::db_code;
        UTILS::default_timezone();

        array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_tbk_ss.$db_code,    'val' => 'A'));
        array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_tbk_cdate.$db_code, 'val' => date('Y-m-d H:i:s')));
        array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_tbk_mdate.$db_code, 'val' => date('Y-m-d H:i:s')));
        //print_r($insert_columns);die;   
        $last_id = DBUTILS::exec_insertsql( $table, $insert_columns);
        return $last_id;
    }
    
    
    

    /**
    * Do Update Form- Get insert coloumn
    **/
    static private function doUpdateForm($table, $srvFrmFieldValues){
        
        $update_columns = array();
        UTILS::updateColumns($srvFrmFieldValues, $update_columns);
        //print_r($update_columns);die;
        
        UTILS::default_timezone();
        $date = date('Y-m-d H:i:s');
       
        $updateField_details = array();
        $updateField_details = array(
            'txtMDate'  => array('db' =>DBCONSTANTS::col_tbk_mdate,'op' => DBCONSTANTS::op_eq, 'val' => $date)
        );
        
        UTILS::updateColumnsCustom($updateField_details, $update_columns);
        //print_r($update_columns);die;
        $update_row = array();
        $update_row = array(
            'hidTextBook'      => DBCONSTANTS::col_tbk_id,
        );
        //print_r($update_row);die;
        $update_col = array();
        UTILS::addSearchColumns($update_row, $update_col);
        //print_r($update_col);die;
        if(sizeof($update_col) > 0){
            DBUTILS::exec_updatesql( $table, $update_columns, $update_col);
        }
        return trim($_POST['hidTextBook']);
    }
    static private function doUpdateForm2($table, $srvFrmFieldValues){
        
        $update_columns = array();
        UTILS::updateColumns($srvFrmFieldValues, $update_columns);
        //print_r($update_columns);die;
        
        UTILS::default_timezone();
        $date = date('Y-m-d H:i:s');
       
        $updateField_details = array();
        $updateField_details = array(
            'txtMDate'  => array('db' =>DBCONSTANTS::col_tbkm_mdate,'op' => DBCONSTANTS::op_eq, 'val' => $date)
        );
        
        UTILS::updateColumnsCustom($updateField_details, $update_columns);
        //print_r($update_columns);die;
        $update_row = array();
        $update_row = array(
            'hidTBMId'      => DBCONSTANTS::col_tbkm_id,
        );
        //print_r($update_row);die;
        $update_col = array();
        UTILS::addSearchColumns($update_row, $update_col);
        //print_r($update_col);die;
        if(sizeof($update_col) > 0){
            DBUTILS::exec_updatesql( $table, $update_columns, $update_col);
        }
        return trim($_POST['hidTBMId']);
    }
}
