<?php
$basepath = $_SERVER['HTTP_HOST'];
//print_r($basepath);die;
if($basepath == 'demo.klabstechindia.com' ){
    class CONFIG{
        const base_url = "http://demo.klabstechindia.com/textbook/";
        const admin_url = "http://demo.klabstechindia.com/textbook/tnadmin/";
        
    	/** SQL server connection information  **/
        static function getDbConnDetails (){
            $sql_details = array(
                'user' => 'root',
                'pass' => 'yj5ndXt9Qgqi',
                'db'   => 'textbook',
                'host' => 'localhost'
            );
            return $sql_details;
        }
        
    }
} else if($basepath == '104.198.73.189' ){
    class CONFIG{
        const base_url = "http://104.198.73.189/~ttapp/tnscert/";
        const admin_url = "http://104.198.73.189/~ttapp/tnscert/tnadmin/";
        
    	/** SQL server connection information  **/
        static function getDbConnDetails (){
            $sql_details = array(
                'user' => 'root',
                'pass' => 'yj5ndXt9Qgqi',
                'db'   => 'textbook',
                'host' => 'localhost'
            );
            return $sql_details;
        }
        
    }
}else if($basepath == '192.168.1.33:8080'){
    class CONFIG{
        const base_url = "http://192.168.1.33:8080/textbook/";
        const admin_url = "http://192.168.1.33:8080/textbook/tnadmin/";
        
    	/** SQL server connection information  **/
        static function getDbConnDetails (){
            $sql_details = array(
                'user' => 'root',
                'pass' => '',
                'db'   => 'textbook',
                'host' => '192.168.1.33'
            );
            return $sql_details;
        }
        
    }
}else if($basepath == '192.168.1.45'){
    class CONFIG{
        const base_url = "http://192.168.1.45/textbook/";
        const admin_url = "http://192.168.1.45/textbook/tnadmin/";
        
    	/** SQL server connection information  **/
        static function getDbConnDetails (){
            $sql_details = array(
                'user' => 'root',
                'pass' => '',
                'db'   => 'textbook',
                'host' => '192.168.1.33'
            );
            return $sql_details;
        }
        
    }
}else if($basepath == '192.168.1.35'){
    class CONFIG{
        const base_url = "http://192.168.1.35/textbook/";
        const admin_url = "http://192.168.1.35/textbook/tnadmin/";
        
    	/** SQL server connection information  **/
        static function getDbConnDetails (){
            $sql_details = array(
                'user' => 'root',
                'pass' => '',
                'db'   => 'textbook',
                'host' => '192.168.1.33'
            );
            return $sql_details;
        }
        
    }
}else if($basepath == 'www.tnscert.org' ){
    class CONFIG{
        const base_url = "http://www.tnscert.org/tnscert/ebooks/";
        const admin_url = "http://www.tnscert.org/tnscert/ebooks/tnadmin/";
        
    	/** SQL server connection information  **/
        static function getDbConnDetails (){
            $sql_details = array(
                'user' => 'tnebooks',
                'pass' => '36vk$yW7',
                'db'   => 'tnscert2017_ebooks',
                'host' => 'localhost'
            );
            return $sql_details;
        }
        
    }
} 
else{
    class CONFIG{
        const base_url = "http://192.168.1.33:8080/textbook/";
        const admin_url = "http://192.168.1.33:8080/textbook/tnadmin/";
        
    	/** SQL server connection information  **/
        static function getDbConnDetails (){
            $sql_details = array(
                'user' => 'root',
                'pass' => '',
                'db'   => 'textbook',
                'host' => '192.168.1.33'
            );
            return $sql_details;
        }
        
    }
}
?>