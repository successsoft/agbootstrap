<?php
//print_r($_POST);die;
require_once("dbconstants.class.php");
require_once("dbutils.class.php");
class FDBKUTILS{
    /**
    * Get Banner Fields as array
    **/
    static function getFormFields (){
        $frmInpField_array = array(
            'hidFdbkId'     => DBCONSTANTS::col_fdbk_id,
            'feedbkname'    => DBCONSTANTS::col_fdbk_nm,
            'feedbkmno'     => DBCONSTANTS::col_fdbk_mno,
            'feedbkemail'   => DBCONSTANTS::col_fdbk_eid,
            'feedbk'        => DBCONSTANTS::col_fdbk_cmt
        );
        return $frmInpField_array;
    }
    
    /**
    * Insert or Updates the Banner Form
    **/
    static function saveForm($table, $srvFrmFieldValues){
        $fdbk_id = trim($_POST['hidFdbkId']);
        if(empty($fdbk_id)){
            //echo 'insert because new ';die;
            $fdbk_id = self::doInsertForm($table, $srvFrmFieldValues);
            $response_array['error'] = false;
            $response_array['fdbk_id'] = $fdbk_id;
            $response_array['msg']  = "Feedback sent to admin successfully";
        }else{
            //echo 'update because new ';die;
            $fdbk_id = self::doUpdateForm($table, $srvFrmFieldValues);
            $response_array['error'] = false;
            $response_array['fdbk_id'] = $fdbk_id;
            $response_array['msg']  = "Language updated successfully";
        }
        return $response_array; 
    }
    
    /**
    * Do Insert Form- Get insert coloumn
    **/
    static private function doInsertForm($table, $srvyFrm_InsertFieldValues){
        $insert_columns = array();
        UTILS::addInsertColumns($srvyFrm_InsertFieldValues, $insert_columns);
        $db_code = DBCONSTANTS::db_code;
        UTILS::default_timezone();

        array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_fdbk_ss.$db_code,    'val' => 'A'));
        array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_fdbk_cdate.$db_code, 'val' => date('Y-m-d H:i:s')));
        array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_fdbk_mdate.$db_code, 'val' => date('Y-m-d H:i:s')));
        //print_r($insert_columns);die;   
        $last_id = DBUTILS::exec_insertsql( $table, $insert_columns);
        return $last_id;
    }
    
    
    

    /**
    * Do Update Form- Get insert coloumn
    **/
    static private function doUpdateForm($table, $srvFrmFieldValues){
        
        $update_columns = array();
        UTILS::updateColumns($srvFrmFieldValues, $update_columns);
        //print_r($update_columns);die;
        
        UTILS::default_timezone();
        $date = date('Y-m-d H:i:s');
       
        $updateField_details = array();
        $updateField_details = array(
            'txtMDate'  => array('db' =>DBCONSTANTS::col_fdbk_mdate,'op' => DBCONSTANTS::op_eq, 'val' => $date)
        );
        
        UTILS::updateColumnsCustom($updateField_details, $update_columns);
        //print_r($update_columns);die;
        $update_row = array();
        $update_row = array(
            'hidFdbkId'      => DBCONSTANTS::col_fdbk_id,
        );
        //print_r($update_row);die;
        $update_col = array();
        UTILS::addSearchColumns($update_row, $update_col);
        //print_r($update_col);die;
        if(sizeof($update_col) > 0){
            DBUTILS::exec_updatesql( $table, $update_columns, $update_col);
        }
        
        
        
        return trim($_POST['hidFdbkId']);
    }
    
}
