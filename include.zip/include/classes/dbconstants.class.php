<?php

class DBCONSTANTS{
    
    const tbl_prefiex	= 'tb_';
    
    
    /** Table Names **/
    const tbl_sa	= 'site_administrators';
	const tbl_lang	= 'language';
	const tbl_cls 	= 'class';
	const tbl_sub	= 'subject';
	const tbl_tm	= 'term';
	const tbl_tbk	= 'text_book';
    const tbl_tbkm	= 'text_book_multiple';
    const tbl_fdbk	= 'feedback';
    const tbl_tbklg	= 'text_book_logs';
    
    /**  order by **/
    const order_asc  = 'ASC';
    const order_desc = 'DESC';

    const db_code      = '`';
    
    /**  operators **/
    const op_eq      = '=';
    const op_gteq    = '>=';
    const op_lteq    = '<=';
	const op_gt      = '>';
    const op_lt      = '<';
    const op_like    = 'LIKE';
    const op_between = 'BETWEEN';
    const op_and     = 'AND';
	const op_or      = 'OR';
    const op_nq      = '<>';
    const op_slike   = 'SLIKE';
    const op_elike   = 'ELIKE';
    const op_reg     = 'REGEXP'; //match beginning  of words
    const op_ereg    = 'EREGEXP'; //match ending of words
    const op_fureg   = 'FREGEXP'; //match full of words
    const op_not     = 'NOT';
    const op_in      = 'IN';
    const op_notnull = 'IS NOT NULL';
    const op_null    = 'IS NULL';
    const op_field_set = 'FIND_IN_SET';

    /** Form Status Draft/Approved/Unapproved **/
    const status_Active     = 'A';
    const status_Inactive   = 'I';
    const status_All        = 'All';
    
     /**  tbl_appinfo App Information Column Names **/
    const col_ainfo_id      = 'id';
    const col_ainfo_pf      = 'platform';
    const col_ainfo_vs      = 'version';
    const col_ainfo_sacc    = 'server_access';
	const col_ainfo_sms     = 'sms';
    const col_ainfo_st      = 'status';
    const col_ainfo_ln      = 'language';
    const col_ainfo_afor    = 'app_for';


    /** Site Administrator Column Names tbl_sa **/
    const col_sa_id     = 'id';
    const col_sa_name   = 'username';
    const col_sa_pwd    = 'password';
	const col_sa_lgtp   = 'login_type';
    const col_sa_eid    = 'email_id';
	const col_sa_sid    = 'send_mail';
	const col_sa_atkn   = 'authtoken';
	const col_sa_cdate  = 'created';
    const col_sa_mdate  = 'modified';

	/** Language Column Names tbl_lang (tb_language) **/
    const col_lang_id     = 'id';
    const col_lang_name   = 'language_name';
    const col_lang_ss	  = 'status';
	const col_lang_cdate  = 'created';
    const col_lang_mdate  = 'modified';

	/** Class Column Names tbl_cls (tb_class) **/
    const col_cls_id     = 'id';
    const col_cls_name   = 'class_name';
    const col_cls_ss	 = 'status';
	const col_cls_cdate  = 'created';
    const col_cls_mdate  = 'modified';

	/** Subject Column Names tbl_sub (tb_subject) **/
    const col_sub_id     = 'id';
    const col_sub_langid  = 'lang_ids';
	const col_sub_clsid  = 'class_ids';
    const col_sub_name   = 'subject_name';
    const col_sub_cimg   = 'cover_image';
    const col_sub_ss	 = 'status';
	const col_sub_cdate  = 'created';
    const col_sub_mdate  = 'modified';

	/** Term Column Names tbl_tm (tb_term) **/
    const col_tm_id     = 'id';
    const col_tm_name   = 'term_name';
    const col_tm_ss		= 'status';
	const col_tm_cdate  = 'created';
    const col_tm_mdate  = 'modified';

	/** Text Book Column Names tbl_tbk (tb_text_book) **/
    const col_tbk_id     = 'id';
    const col_tbk_langgid= 'lang_id';
	const col_tbk_clsid  = 'class_id';
	const col_tbk_subid  = 'sub_id';
	const col_tbk_tmid   = 'tm_id';
	const col_tbk_desp   = 'description';
	const col_tbk_fdnm   = 'folder_name';
    const col_tbk_fonm   = 'file_oname';
	const col_tbk_fsnm   = 'file_name';
	const col_tbk_ftp    = 'file_type';
	const col_tbk_fsz    = 'file_size';
	const col_tbk_bkcv   = 'book_cover';
	const col_tbk_pdf    = 'pdf_file';
    const col_tbk_dcepub = 'download_count_epub';
	const col_tbk_dcpdf  = 'download_count_pdf';
    const col_tbk_ss     = 'status';
	const col_tbk_cdate  = 'created';
    const col_tbk_mdate  = 'modified';
    
    /** Text Book Multiple Column Names tbl_tbkm (tb_text_book_multiple) **/
    const col_tbkm_id     = 'id';
    const col_tbkm_tbkid  = 'tbk_id';
	const col_tbkm_fdnm   = 'folder_name';
    const col_tbkm_fonm   = 'file_oname';
	const col_tbkm_fsnm   = 'file_name';
	const col_tbkm_ftp    = 'file_type';
	const col_tbkm_fsz    = 'file_size';
    const col_tbkm_ss     = 'status';
	const col_tbkm_cdate  = 'created';
    const col_tbkm_mdate  = 'modified';
    
    /** Feedback Column Names tbl_fdbk (tb_feedback) **/
    const col_fdbk_id     = 'id';
    const col_fdbk_nm     = 'feeback_name';
	const col_fdbk_mno    = 'feedback_mobile';
    const col_fdbk_eid    = 'feeback_email_id';
    const col_fdbk_cmt    = 'comments';
    const col_fdbk_ss     = 'status';
	const col_fdbk_cdate  = 'created';
    const col_fdbk_mdate  = 'modified';
    
    /** Text Book Logs Column Names tbl_tbklg (tb_text_book_logs) **/
    const col_tbklg_id     = 'id';
    const col_tbklg_tbkid  = 'tbk_id';
	const col_tbklg_ipadd  = 'ip_address';
    const col_tbklg_lat    = 'latitude';
	const col_tbklg_long   = 'longitude';
	const col_tbklg_ftp    = 'file_type';
	const col_tbklg_fss    = 'file_status';
    const col_tbklg_ss     = 'status';
	const col_tbklg_cdate  = 'created';
    const col_tbklg_mdate  = 'modified';
}
?>


