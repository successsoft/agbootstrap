<?php
//print_r($_POST);die;
require_once("dbconstants.class.php");
require_once("dbutils.class.php");
class SUBUTILS{
    /**
    * Get Banner Fields as array
    **/
    static function getFormFields (){
        $frmInpField_array = array(
            'hidSub'    => DBCONSTANTS::col_sub_id,
            'selLang'   => DBCONSTANTS::col_sub_langid,
            'selClass'  => DBCONSTANTS::col_sub_clsid,
            'txtTitle'  => DBCONSTANTS::col_sub_name,
            'cifname'   => DBCONSTANTS::col_sub_cimg,
        );
        return $frmInpField_array;
    }
    
    /**
    * Insert or Updates the Banner Form
    **/
    static function saveForm($table, $srvFrmFieldValues){
        $lang_id = trim($_POST['hidSub']);
        if(empty($lang_id)){
            //echo 'insert because new ';die;
            $lang_id = self::doInsertForm($table, $srvFrmFieldValues);
            $response_array['error'] = false;
            $response_array['lang_id'] = $lang_id;
            $response_array['msg']  = "Subject added successfully";
        }else{
            //echo 'update because new ';die;
            $lang_id = self::doUpdateForm($table, $srvFrmFieldValues);
            $response_array['error'] = false;
            $response_array['lang_id'] = $lang_id;
            $response_array['msg']  = "Subject updated successfully";
        }
        return $response_array; 
    }
    
    /**
    * Do Insert Form- Get insert coloumn
    **/
    static private function doInsertForm($table, $srvyFrm_InsertFieldValues){
        $insert_columns = array();
        UTILS::addInsertColumns($srvyFrm_InsertFieldValues, $insert_columns);
        $db_code = DBCONSTANTS::db_code;
        UTILS::default_timezone();

        array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_sub_ss.$db_code,    'val' => 'A'));
        array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_sub_cdate.$db_code, 'val' => date('Y-m-d H:i:s')));
        array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_sub_mdate.$db_code, 'val' => date('Y-m-d H:i:s')));
        //print_r($insert_columns);die;   
        $last_id = DBUTILS::exec_insertsql( $table, $insert_columns);
        return $last_id;
    }
    
    
    

    /**
    * Do Update Form- Get insert coloumn
    **/
    static private function doUpdateForm($table, $srvFrmFieldValues){
        
        $update_columns = array();
        UTILS::updateColumns($srvFrmFieldValues, $update_columns);
        //print_r($update_columns);die;
        
        UTILS::default_timezone();
        $date = date('Y-m-d H:i:s');
       
        $updateField_details = array();
        $updateField_details = array(
            'txtMDate'  => array('db' =>DBCONSTANTS::col_sub_mdate,'op' => DBCONSTANTS::op_eq, 'val' => $date)
        );
        
        UTILS::updateColumnsCustom($updateField_details, $update_columns);
        //print_r($update_columns);die;
        $update_row = array();
        $update_row = array(
            'hidSub'      => DBCONSTANTS::col_sub_id,
        );
        //print_r($update_row);die;
        $update_col = array();
        UTILS::addSearchColumns($update_row, $update_col);
        //print_r($update_col);die;
        if(sizeof($update_col) > 0){
            DBUTILS::exec_updatesql( $table, $update_columns, $update_col);
        }
        
        
        
        return trim($_POST['hidSub']);
    }
    
}
