<?php
require_once "dbconstants.class.php";
require_once "dbutils.class.php";
require_once "config.class.php";

class UTILS{
	
    static function default_timezone(){
        return date_default_timezone_set("Asia/Kolkata");
    }
    /**
     * Search during $_POST value
     */
    static function addSearchColumns($searchField_details, &$search_columns){
        //print_r($_POST);print_r($searchField_details);die;
        foreach ($_POST as $key => $value){
            if(array_key_exists($key,$searchField_details)){
                //print_r($key);die;
                $search_column = array();
                if($value!=NULL && trim($value)!=''){
                    $search_column[0]['db']       = $searchField_details[$key];
                    $search_column[0]['op']       = DBCONSTANTS::op_eq;
                    if(($key == 'txtAdminPassword')||($key == 'txtOldPass') || ($key == 'password') || ($key == 'txtLGData2')){
                        $value = trim($value);
                        $search_column[0]['val'][0]   = md5($value);
                    }else{
                        $search_column[0]['val'][0]   = trim($value);
                    }
                    $search_columns[] = $search_column;
                }
            }
        }
        //print_r($search_columns);die;
    }
    
    /**
     * Search during without operator only eq
     */
    static function addSearchColumns2($searchField_details, &$search_columns){
        //print_r($searchField_details);die;
        foreach($searchField_details as $key => $seachField):
            if(array_key_exists($key,$searchField_details)){
                $search_column = array();
                $search_column[0]['db']       = $seachField['db'];
                $search_column[0]['op']       = DBCONSTANTS::op_eq;
                if(($key == 'txtPassword')){
                    $value = trim($seachField['val']);
                    $search_column[0]['val'][0]   = self::tep_encrypt_password($value);
                }else{
                    $search_column[0]['val'][0]   = $seachField['val'];
                }
                $search_columns[] = $search_column;
            }
        endforeach;
    }
    
    /**
     * Search during with operato
     */
    static function addSearchColumns3($searchField_details, &$search_columns){
        foreach($searchField_details as $key => $seachField):
            //print_r($seachField);die;
            $search_column = array();
            $search_column[0]['db']       = $seachField['db'];
            $search_column[0]['op']       = $seachField['op'];
            if(($key == 'txtAdminPassword')||($key == 'txtOldPass') || ($key == 'password') || ($key == 'txtLGData2')){
                $value = trim($seachField['val']);
                $search_column[0]['val'][0]   = md5($value);
            }else{
                $search_column[0]['val'][0]   = $seachField['val'];
            }
            $search_columns[] = $search_column;
        endforeach;
    }
    
    static function addSearchColumns4($searchFieldDetails, &$search_columns){
        //print_r($searchFieldDetails);
        foreach($searchFieldDetails as $key => $seachField){
            //print_r($seachField);die;
            $search_column = array();
            if($seachField['op'] == DBCONSTANTS::op_notnull || $seachField['op'] == DBCONSTANTS::op_null){
                $search_column[0]['db']       = $seachField['db'];
                $search_column[0]['op']       = $seachField['op'];
                $search_column[0]['val'][0]   = "";
                if(isset($seachField['concat'])){
                    $search_column[0]['concat'] = $seachField['concat'];
                }else{
                    unset($search_column[0]['concat']);
                }
                $search_columns[] = $search_column;
            }else{
                if($seachField['val'] != NULL && trim($seachField['val']) != ''){
                    if($seachField['op'] != DBCONSTANTS::op_between){
                        $search_column[0]['db']       = $seachField['db'];
                        $search_column[0]['op']       = $seachField['op'];
                        $search_column[0]['val'][0]   = trim($seachField['val']);
                        if(isset($seachField['concat'])){
                            $search_column[0]['concat'] = $seachField['concat'];
                        }else{
                            unset($search_column[0]['concat']);
                        }
                        $search_columns[] = $search_column;
                    }
                }
            }
        }
        //print_r($search_columns);die;
    }
    
    static function addDateSearchColumn($searchField_details, &$search_columns){
        
        self::default_timezone();
        //'fromdt'=> array('db' => DBCONSTANTS::col_sch_mdt, 'val' => $start, 'op' => DBCONSTANTS::op_between, 'dtset' => 1),dtset group 
        //'todt'  => array('db' => DBCONSTANTS::col_sch_mdt, 'val' => $end,   'op' => DBCONSTANTS::op_between, 'dtset' => 1),
        $output = array();
        foreach($searchField_details as $key => $seachField){
            //print_r($seachField);die;
            $search_column = array();
            if($seachField['val'] != NULL && trim($seachField['val']) != ''){
                if($seachField['op'] == DBCONSTANTS::op_between){
                    //print_r($seachField);die;
                    $search_column['db']  = "DATE(".$seachField['db'].")";
                    $search_column['dtset'] = trim($seachField['dtset']);
                    $date = date('Y-m-d',strtotime($seachField['val']));
                    $search_column['val'][0] = trim($date);
                    if(self::in_multiarray($seachField['dtset'], $output, "dtset")){
                        $response = self::in_multiarray($seachField['dtset'], $output, "dtset");
                        $key = $response['key'];
                        $array = $response['array'];
                        $date = date('Y-m-d',strtotime($seachField['val']));
                        $array['val'][1] = trim($date);
                        $output[$key] = $array; 
                    }else{
                        $output[] = $search_column;    
                    }
                }
            }
        }
        if(sizeof($output) > 0){
            foreach($output as $res){
                //print_r($res);die;
                $search_column = array();
                $search_column[0]['db'] = $res['db'];
                if(sizeof($res['val']) == 2){
                    $search_column[0]['op']       = DBCONSTANTS::op_between;
                    $search_column[0]['val'][0]   = trim($res['val'][0]);
                    $search_column[0]['val'][1]   = trim($res['val'][1]);
                }else{
                    foreach($res['val'] as $val){
                        $search_column[0]['op']       = DBCONSTANTS::op_eq;
                        $search_column[0]['val'][0] = $val;
                    }  
                }
                $search_columns[] = $search_column;    
            }
        }
    }
    
    static function in_multiarray($elem, $array, $field){
        $top = sizeof($array) - 1;
        $bottom = 0;
        while($bottom <= $top)
        {
            if($array[$bottom][$field] == $elem){
                $response_array['key'] = $bottom;
                $response_array['array'] = $array[$bottom];
                return $response_array;
            }else{ 
                if(is_array($array[$bottom][$field])){
                    if(self::in_multiarray($elem, ($array[$bottom][$field]))){
                        $response_array['key'] = $bottom;
                        $response_array['array'] = $array[$bottom];
                        return $response_array;
                    }
                }
            }
    
            $bottom++;
        }        
        return false;
    }
    
    static function PostData($searchFieldDetails, &$search_columns){
        //print_r($searchFieldDetails);
        //print_r($_POST);die;
        foreach ($_POST as $key => $value){
            if(array_key_exists($key,$searchFieldDetails)){
                $search_column = array();
                if($value!=NULL && trim($value)!=''){
                    $search_column[0]['db']       = $searchFieldDetails[$key];
                    $search_column[0]['op']       = DBCONSTANTS::op_eq;
                    if(($key == 'txtAdminPassword')||($key == 'txtOldPass') || ($key == 'password') || ($key == 'txtLGData2')){
                        $value = trim($value);
                        $search_column[0]['val'][0]   = md5($value);
                    }else{
                        $search_column[0]['val'][0]   = trim($value);
                    }
                    $search_columns[] = $search_column;
                }
            }
        }
        //print_r($search_columns);die;
    }
    
    static function PostDataOp($searchFieldDetails, &$search_columns){
        //print_r($searchFieldDetails);
        foreach ($_POST as $key => $value){
            if(array_key_exists($key, $searchFieldDetails)){
                $search_column = array();
                if($value!=NULL && trim($value)!=''){
                    $search_column[0]['db']       = $searchFieldDetails[$key]['db'];
                    $search_column[0]['op']       = $searchFieldDetails[$key]['op'];
                    $search_column[0]['val'][0]   = trim($value);
                    if(isset($searchFieldDetails[$key]['concat'])){
                        $search_column[0]['concat'] = $searchFieldDetails[$key]['concat'];
                    }else{
                        unset($search_column[0]['concat']);
                    }
                    $search_columns[] = $search_column;
                }
            }
        }
        //print_r($search_columns);die;
    }
    
    static function GetData($searchFieldDetails, &$search_columns){
        //print_r($searchField_details);die;
        foreach ($_GET as $key => $value){
            if(array_key_exists($key, $searchFieldDetails)){
                $search_column = array();
                if($value!=NULL && trim($value)!=''){
                    $search_column[0]['db']       = $searchFieldDetails[$key];
                    $search_column[0]['op']       = DBCONSTANTS::op_eq;
                    $search_column[0]['val'][0]   = trim($value);
                    $search_columns[] = $search_column;
                }
            }
        }
        //print_r($search_columns);die;
    }
    
    static function searchColumnArray($searchFieldDetails, &$search_columns){
        //print_r($searchField_details);die;
        foreach ($_POST as $key => $value){
            if(array_key_exists($key,$searchFieldDetails)){
                $search_column = array();
                if($value!=NULL && trim($value)!=''){
                    $search_column[]['data'] = $searchFieldDetails[$key];
                    $search_columns['columns'] = $search_column;
                }
            }
        }
        //print_r($search_columns);die;
    }
    
    static function addInsertColumns($insertField_details, &$insert_columns){
        UTILS::default_timezone();
        //print_r($insertField_details);die;
        foreach ($_POST as $key => $value){
            if(array_key_exists($key, $insertField_details)){
                //print_r("array_key_exists");archive_date  txtArchiveDate
                if($value!=NULL && trim($value)!=''){
                    //print_r($insertField_details[$key]);print_r($key);
                    if($key == "txtPwd" || $key == 'txtVPwd' || $key == 'txtCPwd' || $key == 'txtGPwd' ):
                        $value = trim($value);
                        $value = self::tep_encrypt_password($value);
                        $value = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
                        $insert_column = array();
                        $insert_column['db']    = DBCONSTANTS::db_code.$insertField_details[$key].DBCONSTANTS::db_code;
                        $insert_column['val']   = trim($value); 
                        $insert_columns[]       = $insert_column;
                    elseif(($key == "txtAOnDescription") || ( $key == 'txtSDescription')):
                        $value = trim($value);
                        $insert_column = array();
                        $insert_column['db']    = DBCONSTANTS::db_code.$insertField_details[$key].DBCONSTANTS::db_code;
                        $insert_column['val']   = $value;
                        $insert_columns[]       = $insert_column;
                    elseif($key == "txtDate" || $key == "regjoinDat" || $key == "txtDOB" || $key == "PerTo" || $key == "school_opening" || $key == "regidate" || $key == "pf" || $key == "pt" ):
                        $value = trim($value);
                        
                        $date = date('Y-m-d',strtotime($value));
                        $insert_column = array();
                        $insert_column['db']    = DBCONSTANTS::db_code.$insertField_details[$key].DBCONSTANTS::db_code;
                        $insert_column['val']   = trim( $date );
                        $insert_columns[]       = $insert_column;
                    elseif($key == "txtITm" || $key == "txtOTm" || $key == "txtVSTIn" || $key == "txtVSTOt"):
                        $value = trim($value);
                        $date = date('H:i:s',strtotime($value));
                        $insert_column = array();
                        $insert_column['db']    = DBCONSTANTS::db_code.$insertField_details[$key].DBCONSTANTS::db_code;
                        $insert_column['val']   = trim( $date );
                        $insert_columns[]       = $insert_column;
                    else:
                        $insert_column = array();
                        $insert_column['db']    = DBCONSTANTS::db_code.$insertField_details[$key].DBCONSTANTS::db_code;
                        $value = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
                        $insert_column['val']   = trim( $value );
                        $insert_columns[]       = $insert_column;
                    endif;
                    
                }
           }
        }
        //print_r($insert_columns);die;
    }
    
    
    
    static function updateColumns($updateField_details, &$update_columns){
        UTILS::default_timezone();
        //print_r($updateField_details);
        //print_r($_POST);
        foreach ($_POST as $key => $value){
            //echo $key;die;
            //print_r($value);die;
            if(array_key_exists($key, $updateField_details)){
                //print_r("array_key_exists");
                if($key == "txtPwd" || $key == "txtNPass" || $key == 'txtVPwd' || $key == 'txtCPwd' || $key == 'txtGPwd' || $key == "txtCNPwd"):
                    $value = trim($value);
                    if(strlen($value)>0):
                        $value = self::tep_encrypt_password($value);
                        $update_column = array();
                        $update_column['db']    = DBCONSTANTS::db_code.$updateField_details[$key].DBCONSTANTS::db_code;
                        $update_column['op']       = DBCONSTANTS::op_eq;
    					$update_column['val']   = trim( $value );
                        $update_columns[]       = $update_column;
                    endif;
                elseif(($key == "txtDesc") || ($key == "txtAOnDescription") || ( $key == 'txtSDescription')):
                    $value = trim($value);
                    if($value!=NULL && trim($value)!=''):
                        $update_column = array();
                        $update_column['db']    = DBCONSTANTS::db_code.$updateField_details[$key].DBCONSTANTS::db_code;
                        $update_column['op']       = DBCONSTANTS::op_eq;
    					$update_column['val']   = trim( $value );
                        $update_columns[]       = $update_column;
                    endif;
                elseif($key == "txtDate"  || $key == "regjoinDat" || $key == "txtDOB" || $key == "PerTo" || $key == "school_opening" || $key == "regidate" || $key == "pf" || $key == "pt"):
                    $value = trim($value);
                    if($value!=NULL && trim($value)!=''):
                        $date = date('Y-m-d',strtotime($value));
                        $update_column = array();
                        $update_column['db']    = DBCONSTANTS::db_code.$updateField_details[$key].DBCONSTANTS::db_code;
                        $update_column['op']       = DBCONSTANTS::op_eq;
                        $update_column['val']   = trim( $date );
                        $update_columns[]       = $update_column;
                    endif;
                elseif($key == "txtITm" || $key == "txtOTm" || $key == "txtVSTIn" || $key == "txtVSTOt"):
                    $value = trim($value);
                    if($value!=NULL && trim($value)!=''):
                        $time = date('H:i:s',strtotime($value));
                        $update_column = array();
                        $update_column['db']    = DBCONSTANTS::db_code.$updateField_details[$key].DBCONSTANTS::db_code;
                        $update_column['op']       = DBCONSTANTS::op_eq;
                        $update_column['val']   = trim( $time );
                        $update_columns[]       = $update_column;
                    endif;
                else:
                    $value = trim($value);
                    if($value!=NULL && trim($value)!=''):
                        $update_column = array();
                        $update_column['db']    = DBCONSTANTS::db_code.$updateField_details[$key].DBCONSTANTS::db_code;
                        $update_column['op']       = DBCONSTANTS::op_eq;
    					$value = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
                        $update_column['val']   = trim( $value );
                        $update_columns[]       = $update_column;
                    endif;
                endif;
            }
        }
      // print_r($update_columns);die;
    }
    
    
    static function updateColumnsCustom($updateField_details, &$update_columns){
         foreach ($updateField_details as $key => $value){
            if(array_key_exists($key, $updateField_details)){
                $update_column = array();
                $update_column['db']    = $value['db'];
                $update_column['op']    = DBCONSTANTS::op_eq;
                $update_column['val']   = $value['val'];
                $update_columns[]       = $update_column;
            }
         }
    }
    
    static function searchUpdateCustomColumns($updateField_details, &$update_columns){
        foreach($updateField_details as $key => $seachField):
            //print_r($seachField);die;
            $search_column = array();
            $search_column[0]['db']       = $seachField['db'];
            $search_column[0]['op']       = DBCONSTANTS::op_eq;
            $search_column[0]['val'][0]   = $seachField['val'];
            $update_columns[] = $search_column;
        endforeach;
    }
    
    /** Update column where **/
    static function updateColumnsWhere($updateField_details, &$update_columns){
        //print_r($_POST);print_r($updateField_details);die;
        foreach ($_POST as $key => $value){
            if(array_key_exists($key,$updateField_details)){
                //print_r($key);die;
                $update_column = array();
                if($value!=NULL && trim($value)!=''){
                    $update_column[0]['db']       = $updateField_details[$key];
                    $update_column[0]['op']       = DBCONSTANTS::op_eq;
                    $update_column[0]['val'][0]   = trim($value);
                    $update_columns[] = $update_column;
                }
            }
        }
    }
    
    static function updateColumnsWhere2($updateField_details, &$update_columns){
        //print_r($searchField_details);die;
        foreach($updateField_details as $key => $updateField):
            if(array_key_exists($key, $updateField_details)){
                $update_column = array();
                if($updateField['val'] != NULL && trim($updateField['val'])!=''){
                    $update_column[0]['db']       = $updateField['db'];
                    $update_column[0]['op']       = DBCONSTANTS::op_eq;
                    $update_column[0]['val'][0]   = $updateField['val'];
                    $update_columns[] = $update_column;
                }
            }
        endforeach;
    }
	
	/**
     * $implode_column = array();
    UTILS::implodeColumn($ui_columns, $implode_column);
    $sql_query = "SELECT  ".implode(", ",$implode_column)." FROM $table $joinTable $where ";
    //print_r($sql_query);die;
    
    $data = DBUTILS::execute_column_query_array($ui_columns, $bindings, $sql_query); */
	static function implodeColumn($column, &$implode_columns){
        //print_r($column);die;
        foreach($column as $key => $value){
            if(isset($value['tb'])){
                $implode_column = $value['tb'].".".$value['db']." ".$key;
            }else{
                $implode_column = $value['db']." ".$key;
            }
            $implode_columns[] = $implode_column;
        }
        
    }
    
    static function stringToSlug($str) {
        // trim the string
        $str = strtolower(trim($str));
        // replace all non valid characters and spaces with an underscore
        $str = preg_replace('/[^a-z0-9-]/', '_', $str);
        $str = preg_replace('/-+/', "_", $str);
        return $str;
    }    
    
    static function send_mail ($to, $subject, $message, $senderMail, $senderName, $bcc = '', $cc = ''){
        $from = $senderName." <".$senderMail.">"; 
        $headers = "From: $from \r\n";
        if ($cc != '') {
             $headers .= "Cc: $cc\r\n";
        }
        if ($bcc != '') {
            $headers .= "Bcc: $bcc\r\n";
        }
        $headers  .= 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        //$headers .= "X-Mailer: PHP/" . phpversion();
        
        $mail = @mail($to, $subject, $message, $headers ); 
    
        //function return true, if email sent, otherwise return fasle
        if($mail){ return TRUE; } else { return FALSE; }
    }
     
    static function send_mail_attachment ($to, $subject, $message, $senderMail, $senderName, $files = '', $bcc = '', $cc = ''){
        $from = $senderName." <".$senderMail.">"; 
        $headers = "From: $from";
        if ($cc != '') {
             $headers .= "Cc: $cc\r\n";
        }
        if ($bcc != '') {
            $headers .= "Bcc: $bcc\r\n";
        }
        
        // boundary 
        $semi_rand = md5(time()); 
        $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x"; 
    
        // headers for attachment 
        $headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
    
        // multipart boundary 
        $message = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" .
        "Content-Transfer-Encoding: 7bit\n\n" . $message . "\n\n"; 
    
        // preparing attachments
        //print_r(count($files));die;
        $base_url  = CONFIG::base_url;
        // preparing attachments
    	if(count($files) > 0){
    		for($i=0;$i<count($files);$i++){
    			if(is_file($files[$i])){
    				$message .= "--{$mime_boundary}\n";
    				$fp =    @fopen($files[$i],"rb");
    				$data =  @fread($fp,filesize($files[$i]));
    				@fclose($fp);
    				$data = chunk_split(base64_encode($data));
    				$message .= "Content-Type: application/octet-stream; name=\"".basename($files[$i])."\"\n" . 
    				"Content-Description: ".basename($files[$i])."\n" .
    				"Content-Disposition: attachment;\n" . " filename=\"".basename($files[$i])."\"; size=".filesize($files[$i]).";\n" . 
    				"Content-Transfer-Encoding: base64\n\n" . $data . "\n\n";
    			}
    		}
    	}
        
        $message .= "--{$mime_boundary}--";
        $returnpath = "-f" . $senderMail;
    
        //send email
        $mail = @mail($to, $subject, $message, $headers, $returnpath); 
    
        //function return true, if email sent, otherwise return fasle
        if($mail){ return TRUE; } else { return FALSE; }
    
    }
    
    static function SMTP_mail ($to_email, $to_name, $subject, $message, $senderMail, $senderName, $bcc = '', $cc = ''){
        require 'PHPMailer/PHPMailerAutoload.php';

        //Create a new PHPMailer instance
        $mail = new PHPMailer;
        
        //Tell PHPMailer to use SMTP
        $mail->isSMTP();
        
        //Enable SMTP debugging
        // 0 = off (for production use)
        // 1 = client messages
        // 2 = client and server messages
        $mail->SMTPDebug = 2;
        
        //Ask for HTML-friendly debug output
        $mail->Debugoutput = 'html';
        
        //Set the hostname of the mail server
        $mail->Host = 'smtp.gmail.com';
        // use
        // $mail->Host = gethostbyname('smtp.gmail.com');
        // if your network does not support SMTP over IPv6
        
        //Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
        // I tried PORT 25, 465 too
        $mail->Port = 587;
        
        //Set the encryption system to use - ssl (deprecated) or tls
        $mail->SMTPSecure = 'tls';
        
        //Whether to use SMTP authentication
        $mail->SMTPAuth = true;
        
        //Username to use for SMTP authentication - use full email address for gmail
        $mail->Username = "xxxxx@gmail.com";
        
        //Password to use for SMTP authentication
        $mail->Password = "xxxxx";
        
        //Set who the message is to be sent from
        $mail->setFrom('xxxx@gmail.com', 'xxxx x');
        
        
        //Set who the message is to be sent to
        $mail->addAddress($to_email, $to_name);
        
        //Set the subject line
        $mail->Subject = $subject;
        
        //Read an HTML message body from an external file, convert referenced images to embedded,
        //convert HTML into a basic plain-text alternative body
        $mail->msgHTML($message);
        
        //Replace the plain text body with one created manually
        $mail->AltBody = 'This is a plain-text message body';
        
        // send as HTML
        $mail->IsHTML(true); 
        
        //send the message, check for errors
        if (!$mail->send()) {
            echo "Mailer Error: " . $mail->ErrorInfo;
        } else {
            echo "Message sent!";
        }
    }
    
    static function genRandomString($length = 4){
    		// inicializa variables
    	$gen_rand = "";
    	$i = 0;
    	//$possible = "0123456789bcdfghjkmnpqrstvwxyz";
        $possible = "0123456789";  
    	
    	// agrega random
    	while ($i < $length){
    		$char = substr($possible, mt_rand(0, strlen($possible)-1), 1);
    		
    		if (!strstr($gen_rand, $char)) { 
    			$gen_rand .= $char;
    			$i++;
    		}
    	}
    	return $gen_rand;
    }
    
    /** ***Encrypt Password Start** **/
    static function tep_encrypt_password($plain) {
        $password = '';
        for ($i=0; $i<10; $i++) {
            $password .= rand();
        }
        $salt = substr(md5($password), 0, 2);
        $password = md5($salt . $plain) . ':' . $salt;
        return $password;
    }
    
    
    static function tep_validate_password($plain, $encrypted) {
        if (self::tep_not_null($plain) && self::tep_not_null($encrypted)) {
            // split apart the hash / salt
            $stack = explode(':', $encrypted);
            if (sizeof($stack) != 2) return false;
            //echo $plain."3333".$stack[1]."###".md5($stack[1] . $plain)."###".$stack[0];
            //print_r($encrypted);
            //echo $stack[0];die;
            //print_r(md5($stack[1] . $plain));die;
            if (md5($stack[1] . $plain) == $stack[0]) {
                return true;
            }
        }
        return false;
    }
    
    static function tep_not_null($value) {
        if (is_array($value)) {
            if (sizeof($value) > 0) {
                return true;
            } else {
                return false;
            }
        } else {
            if (($value != '') && (strtolower($value) != 'null') && (strlen(trim($value)) > 0)) {
                return true;
            }   else {
                return false;
            }
        }
    }
	/** ***Encrypt Password End** **/

    static function sendsms($mobileno, $sms) {
        $msg = rawurlencode($sms);
        //$url = "http://trsms.krispal.in/API/pushsms.aspx?username=yarlventures@gmail.com&password=123456&senderid=YMSHOP&mobile=$mobileno&text=$msg";
        //$url = "http://sms.klabsindia.com/API/pushsms.aspx?username=ktsuser3@klabs.com&password=ktsuser123&senderid=TNSCHS&mobile=$mobileno&text=$msg";
        $url = "http://trsms.krispal.in/API/PushSMSUC.aspx?username=ktsuser3@klabs.com&password=ktsuser123&senderid=TNSCHS&mobile=$mobileno&text=$msg";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        
        $data = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        //return 'data: '.$data.', httpcode '.$httpcode;
    }
    
    /**
     * Currency Conversion
     */
    static function currency($from_Currency,$to_Currency,$amount) {
		//$amount = urlencode($amount);
		//  $from_Currency = urlencode($from_Currency);
		//  $to_Currency = urlencode($to_Currency);
		//  $get = file_get_contents("http://www.google.com/finance/converter?a=$amount&from=$from_Currency&to=$to_Currency");
		//  $get = explode("<span class=bld>",$get);
		//  $get = explode("</span>",$get[1]);  
		//  $new_string = preg_replace("/[^0-9\.]/", null, $get[0]);
		
		
		$amount = urlencode($amount);
		$from_Currency = urlencode($from_Currency);
		$to_Currency = urlencode($to_Currency);
		$url = "http://www.google.com/finance/converter?a=".$amount."&from=".$from_Currency."&to=".$to_Currency;
		//$url = "http://www.google.com/ig/calculator?hl=en&q=$amount$from_Currency=?$to_Currency";
		$ch = curl_init();
		$timeout = 0;
		curl_setopt ($ch, CURLOPT_URL, $url);
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch,  CURLOPT_USERAGENT , "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)");
		curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		$rawdata = curl_exec($ch);
		curl_close($ch);
		//echo $rawdata;
		//$data = explode('"', $rawdata);
		//$data = explode('Indian rupees', $data['3']);
		//$var = $data['0'];
		//$new_string = ereg_replace("[^0-9.]", "", $var); 
		  $data = explode("<span class=bld>",$rawdata);
		  $data = explode("</span>",$data[1]);  
		  $new_string = preg_replace("/[^0-9\.]/", null, $data[0]);
		
		
		return trim($new_string);
	}
    
    /** ***Get IP End** **/
    static function getIp() {
		$ip = $_SERVER['REMOTE_ADDR'];     
		if($ip){
			if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
				$ip = $_SERVER['HTTP_CLIENT_IP'];
			} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
				$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
			}
			return $ip;
		}
		// There might not be any data
		return false;
	}
	/*****Get IP End****/
	
	/** ***Get Own URL Start** **/
	static function getOwnURL() { 
		$s = empty($_SERVER["HTTPS"]) ? '' : ($_SERVER["HTTPS"] == "on") ? "s" : ""; 
		$protocol = $this->strleft(strtolower($_SERVER["SERVER_PROTOCOL"]), "/").$s; 
		$port = ($_SERVER["SERVER_PORT"] == "80" || $_SERVER["SERVER_PORT"] == "82") ? "" : (":".$_SERVER["SERVER_PORT"]);  
		return $protocol."://".$_SERVER['SERVER_NAME'].$port.$_SERVER['REQUEST_URI']; 
	}
    
    static function PriceFormat2fix($get,$digit=0){
		$get = ($get) ? number_format($get,$digit,'.','') : "0.00";
		$num=explode('.',$get);
		$price=$num[0];
		
		$explrestunits = "";
		if(strlen($price)>3){
			$lastthree = substr($price, strlen($price)-3, strlen($price));
			$restunits = substr($price, 0, strlen($price)-3);
			$restunits = (strlen($restunits)%2 == 1)?"0".$restunits:
			$restunits;
			$expunit = str_split($restunits, 2);
			for($i=0; $i<sizeof($expunit); $i++){
				if($i==0)
				{
					$explrestunits .= (int)$expunit[$i].",";
				}else{
					$explrestunits .= $expunit[$i].",";
				}
			}
			$thecash = $explrestunits.$lastthree;
		} else {
			$thecash = $price;
		}
		
		if($digit==0){ $final_cash=$thecash; }else{ if(strlen($num[1])>=1){ $final_cash=$thecash.".".$num[1]; }else{ $final_cash=$thecash; } }
		
		return $final_cash;
	}
    
    static function dateTime($date1){
        date_default_timezone_set("Asia/Kolkata");
        $date2 = date('Y-m-d H:i:s');
        
        $diff = abs(strtotime($date2) - strtotime($date1));
        
        $years = floor($diff / (365*60*60*24));
        $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
        $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
        
        $hours = floor($diff / (60 * 60));
        $diff -= $hours * (60 * 60);
        
        $minutes = floor($diff / 60);
        $diff -= $minutes * 60;
        
        $seconds = floor($diff);
        $diff -= $seconds;
        
        $hours = str_pad($hours, 2, "0", STR_PAD_LEFT);
        $minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);
        $seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);
        
        //echo $years." - ".$months." - ".$days." - ".$hours." - ".$minutes." - ".$seconds;die;
        if($years > 0){
            return "{$years} year ago";
        }else if($months > 0){
            return "{$months} months ago";
        }else if($days > 0){
            return "{$days} days ago";
        }else if($hours > 0){
            return "{$hours} hours ago";
        }else if($minutes > 0){
            return "{$minutes} minutes ago";
        }else if($seconds > 0){
            return "{$seconds} seconds ago";
        }else{
            return '';
        }
         
    }
    
    static function backup_tables($tables = '*'){
		$sql_details = CONFIG::getDbConnDetails();
		
		$host = $sql_details['host'];
		$user = $sql_details['user'];
		$pass = $sql_details['pass'];
		$db = $sql_details['db'];
		
		$link = mysql_connect($host, $user, $pass);
		mysql_select_db($db, $link);

		//get all of the tables
		if($tables == '*'){
			$tables = array();
			$result = mysql_query('SHOW TABLES');

			while($row = mysql_fetch_row($result)){
				$tables[] = $row[0];
			}
		}
		else {
			$tables = is_array($tables) ? $tables : explode(',',$tables);
		}
		//print_r($tables);die;
		//cycle through
		$return="";
		foreach($tables as $table){
		
			$result = mysql_query('SELECT * FROM '.$table);
			$num_fields = mysql_num_fields($result);
			//print_r($num_fields);exit;
			$return.= 'DROP TABLE '.$table.';';
			$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
			$return.= "\n\n".$row2[1].";\n\n";

			for ($i = 0; $i < $num_fields; $i++){
				while($row = mysql_fetch_row($result)){
					$return.= 'INSERT INTO '.$table.' VALUES(';
					for($j=0; $j<$num_fields; $j++){
						$row[$j] = addslashes($row[$j]);
						// $row[$j] = preg_replace("\n","\\n",$row[$j]);

						$row[$j] = preg_replace("/(\n){2,}/", "\\n", $row[$j]); 

						if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
							if ($j<($num_fields-1)) { $return.= ','; }
					}
					$return.= ");\n";
				}
			}
			$return.="\n\n\n";

		}

		//save file
		self::default_timezone();
		$handle = fopen('db-backup-'.date('d-M-Y H-i-s').'.sql','w+');
		// print_r($handle);exit;
		fwrite($handle,$return);
		fclose($handle);
		/**Header('Content-type: application/octet-stream');
		Header('Content-Disposition: attachment; filename=../../../../dbbackup/db-backup-'.date('d-M-Y H-i-s').'.sql');*/
		//echo $return;
		return true;
	}
    
    static function get_image_lat_long($file_path = false){
        if(file_exists($file_path)){
            $details = exif_read_data($file_path);
    		
    		$sections = explode(',',$details['SectionsFound']);
            //print_r($details);die;
            if((isset($details['GPSLatitude']))&&(isset($details['GPSLongitude']))){
    			
    			$lat_ref = $details['GPSLatitudeRef']; 
    			$lat = $details['GPSLatitude']; //sets a variable equal to the Latitude
    			list($num, $dec) = explode('/', $lat[0]); //calculates the Degrees
    			$lat_s = $num / $dec;
    			list($num, $dec) = explode('/', $lat[1]); //calculates the Minutes
    			$lat_m = $num / $dec;
    			list($num, $dec) = explode('/', $lat[2]); //calculates the Seconds
    			$lat_v = $num / $dec;
    
    			$lon_ref = $details['GPSLongitudeRef'];
    			$lon = $details['GPSLongitude']; //sets the variable for the longitude
    			list($num, $dec) = explode('/', $lon[0]); //puts the degrees into a variable
    			$lon_s = $num / $dec;
    			list($num, $dec) = explode('/', $lon[1]); //puts the minutes into a variable
    			$lon_m = $num / $dec;
    			list($num, $dec) = explode('/', $lon[2]); //puts the seconds into a variable
    			$lon_v = $num / $dec;
    
    			//Calculates the GPS location in decimal form.
    			$gps_int = array($lat_s + $lat_m / 60.0 + $lat_v / 3600.0, $lon_s
    					 + $lon_m / 60.0 + $lon_v / 3600.0);
    
    			//print_r($gps_int);die;
    			
    
    			$GPSLatitude = $gps_int[0];
                $GPSLongitude = $gps_int[1];
                
                return array("latitude" => $GPSLatitude, "longitude" => $GPSLongitude);
                
            }else{
                return false;
            }
        }else{
            return false;
        }
    }
    
    static function crypto_rand_secure($min, $max) {
        $range = $max - $min;
        if ($range < 1) return $min; // not so random...
        $log = ceil(log($range, 2));
        $bytes = (int) ($log / 8) + 1; // length in bytes
        $bits = (int) $log + 1; // length in bits
        $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
        do {
            $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
            $rnd = $rnd & $filter; // discard irrelevant bits
        } while ($rnd > $range);
        return $min + $rnd;
    }
    /** Get Token **/
    static function getToken($length) {
        $token = "";
        $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
        $codeAlphabet.= "0123456789";
        $max = strlen($codeAlphabet); // edited
    
        for ($i=0; $i < $length; $i++) {
            $token .= $codeAlphabet[self::crypto_rand_secure(0, $max-1)];
        }
    
        return $token;
    }

	/**
     * Push Notification 
     * Android Api
     */
    static function pushnotification($registrationID, $title, $notmsg, $OrderId, $notfor = '' ){
        $apiKey = "AAAA0r8XfZI:APA91bFLdoph4_9lWrCzytFxFyaT1sdGTt45V5Rosov27KMnVygUVrisONFhGpjr8MAWMtiAhTle2umy0bjLu94LpKtxFszJ7kjWd6jFH_mWGGCHs7FFD5FVbuSW3fB6dHrD8Wkiu20S";
        // Replace with the real client registration IDs  "fA38aSXm554:APA91bHf9bywNLGEe8zBZUJC5aBziclTik9mBrcxaJ6g2EJbyrSg33qp0YgoXeEYOIQS0jr9H4NTK2gv6GUxKxOrWIUEgA-h5CPSnDHva9IoYDwn_Wu2F0CHd2nG1SShvymvivapkWZH",
        $registrationIDs = array( $registrationID );
    
        // Message to be sent
        $message = $notmsg;
    
        // Set POST variables
        $url = 'https://android.googleapis.com/gcm/send';
    
        $fields = array(
            'registration_ids' => $registrationIDs,
            'notification' => array( "body" => $message,"title" => $title, 'id' => $OrderId, 'notfor' => $notfor ),
        );
        $headers = array(
            'Authorization: key=' . $apiKey,
            'Content-Type: application/json'
        );
        //print_r($fields);die;
        // Open connection
        $ch = curl_init();
    
        // Set the URL, number of POST vars, POST data
        curl_setopt( $ch, CURLOPT_URL, $url);
        curl_setopt( $ch, CURLOPT_POST, true);
        curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true);
        //curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $fields));
    
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        // curl_setopt($ch, CURLOPT_POST, true);
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode( $fields));
    
        // Execute post
        $result = curl_exec($ch);
    
        // Close connection
        curl_close($ch);
        return $result;
    }
	
    /** Creating log file using txt **/
	static function txtlog( $path, $str ){
        //print_r($str);die;
        if( empty( $path ) ) return false;
        UTILS::default_timezone();
        if( file_exists( $path ) ){
            //print_r($path);die;
            $fp = fopen( $path, 'a' );
            $str =  "\r\n".date( 'd/m/Y H:i:s' ) ." " . $str;
            fwrite( $fp, $str );
            fclose( $fp );
        }else{
           //print_r('new');die;
           $fp = fopen( $path, 'w' );
           $str =  "\r\n".date( 'd/m/Y H:i:s' ) . " " . $str;
           fwrite( $fp, $str );
           fclose( $fp );
        }
        return true;
    }
    
    static function formatSizeUnits($bytes){
    	if ($bytes >= 1073741824){
    		$bytes = number_format($bytes / 1073741824, 2) . ' GB';
    	}elseif ($bytes >= 1048576){
    		$bytes = number_format($bytes / 1048576, 2) . ' MB';
    	}elseif ($bytes >= 1024){
    		$bytes = number_format($bytes / 1024, 2) . ' KB';
    	}elseif ($bytes > 1){
    		$bytes = $bytes . ' bytes';
    	}elseif ($bytes == 1){
    		$bytes = $bytes . ' byte';
    	}else{
    		$bytes = '0 bytes';
    	}
    
    	return $bytes;
    }
}
?>