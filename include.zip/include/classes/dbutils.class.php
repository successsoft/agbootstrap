<?php

require_once("dbconstants.class.php");
require_once("config.class.php");

class DBUTILS {
    

    /**
    * Insert
    */
    static function exec_insertsql($table, $columnsData){
        try {
            $db = self::sql_connect();
            //print_r($columnsData);die;
            $db_code = DBCONSTANTS::db_code;
            $fields = implode(",", self::pluck($columnsData, 'db'));
            //$values = implode(",", self::pluck($columnsData, 'val'));

			$bindings = array();
			$values = self::pluckinsert($columnsData, 'val', $bindings);

            $sql = "INSERT INTO $table ($fields) VALUES ($values)";
            //print_r($sql);die;
            
			if ( $sql === null ) {
                $sql = $bindings;
            }
            $stmt = $db->prepare( $sql );
            //echo $sql;
            // Bind parameters
            if ( is_array( $bindings ) ) {
                for ( $i=0, $ien=count($bindings) ; $i<$ien ; $i++ ) {
                    $binding = $bindings[$i];
					//print_r($binding);die;
                    $stmt->bindValue( $binding['key'], $binding['val'], $binding['type'] );
                }
            }
        
            $stmt->execute();
			//echo $db->lastInsertId();die;
            //$db->exec($sql);
            //echo "New record created successfully";die;
            return $db->lastInsertId();

        }
        catch(PDOException $e){
            throw new RuntimeException($e->getMessage());
            //echo $sql . "<br>" . $e->getMessage();
        }
    }
 
    /**
    * Update Data in table
    */
    static function exec_updatesql($table, $columnsData , $search_columns){
        try {
            //print_r("exec_updatesql");die;
            $bindings = array();
            //print_r($search_columns);
            //print_r($columnsData);
            $where = self::filter2($search_columns,$bindings);
            //print_r($where);die;
            //print_r($bindings);
        
            $db = self::sql_connect();
        
            //$fields = implode(",", $columnsData );
            //print_r($fields);die;
            //$bindings = array();
            $fields = self::pluckupdate($columnsData, $bindings);
            $sql = "UPDATE $table SET $fields $where";
            //print_r($sql);die;
            // Argument shifting
            if ( $sql === null ) {
                $sql = $bindings;
            }
            $stmt = $db->prepare( $sql );
            //echo $sql;
            // Bind parameters
            if ( is_array( $bindings ) ) {
                for ( $i=0, $ien=count($bindings) ; $i<$ien ; $i++ ) {
                    $binding = $bindings[$i];
                    $stmt->bindValue( $binding['key'], $binding['val'], $binding['type'] );
                }
            }
        
            $stmt->execute();
           
            //$count = $stmt->rowCount();
            //echo "Updated record successfully".$count;die;
        }
        catch(PDOException $e){
            throw new RuntimeException($e->getMessage());
            //echo $sql . "<br>" . $e->getMessage();
        }
    }
    
    /** 
     * Delete sql
     */
    static function exec_deletesql($table, $search_columns){
        try {
            //print_r("exec_updatesql");die;
            $bindings = array();
            //print_r($search_columns);
            $where = self::filter2($search_columns,$bindings);
            //print_r($where);
            //print_r($bindings);
        
            $db = self::sql_connect();
        
            $sql = "DELETE FROM  $table $where";
            //print_r($sql);die;
            
            // Argument shifting
            if ( $sql === null ) {
                $sql = $bindings;
            }
            $stmt = $db->prepare( $sql );
            //echo $sql;
            // Bind parameters
            if ( is_array( $bindings ) ) {
                for ( $i=0, $ien=count($bindings) ; $i<$ien ; $i++ ) {
                    $binding = $bindings[$i];
                    $stmt->bindValue( $binding['key'], $binding['val'], $binding['type'] );
                }
            }
        
            $stmt->execute();
        }
        catch(PDOException $e){
            throw new RuntimeException($e->getMessage());
            //echo $sql . "<br>" . $e->getMessage();
        }
    }
    
    /**
	 * Create the data output array for the DataTables rows
	 *
	 *  @param  array $columns Column information array
	 *  @param  array $data    Data from the SQL get
	 *  @return array          Formatted data in a row based format
	 */
    static function data_output ( $columns, $data, $sno ) {
		$out = array();
        $count = $sno + 1;
		for ( $i=0, $ien=count($data) ; $i<$ien ; $i++ ) {
			$row = array();

			for ( $j=0, $jen=count($columns) ; $j<$jen ; $j++ ) {
				$column = $columns[$j];

				// Is there a formatter?
				if ( isset( $column['formatter'] ) ) {
					$row[ $column['dt'] ] = $column['formatter']( $data[$i][ $column['db'] ], $data[$i] );
				}else if ( isset( $column['as'] ) ) {
				    //echo $column['as'];die;
				    if($column['as'] == 'sno'){
				        $row[ $column['dt'] ] = $count; 
                    }else {
                       $row[ $column['dt'] ] = $data[$i][ $columns[$j]['as'] ];    
                    }
				}else { 
				    if($column['dt'] == 'sno'){
                        $row[ $column['dt'] ] = $count; 
                    }else {
                       $row[ $column['dt'] ] = $data[$i][ $columns[$j]['db'] ];    
                    }
                }
			}

			$out[] = $row;
            $count++;
		}

		return $out;
	}
    
    /**
	 * Paging
	 *
	 * Construct the LIMIT clause for server-side processing SQL query
	 *
	 *  @param  array $request Data sent to server by DataTables
	 *  @param  array $columns Column information array
	 *  @return string SQL limit clause
	 */
	static function limit ( $request, $columns ) {
		$limit = '';

		if ( isset($request['start']) && $request['length'] != -1 ) {
			$limit = "LIMIT ".intval($request['start']).", ".intval($request['length']);
		}

		return $limit;
	}


	/**
	 * Ordering
	 *
	 * Construct the ORDER BY clause for server-side processing SQL query
	 *
	 *  @param  array $request Data sent to server by DataTables
	 *  @param  array $columns Column information array
	 *  @return string SQL order by clause
	 */
	static function order ( $request, $columns ) {
		$order = '';
		if ( isset($request['order']) && count($request['order']) ) {
			$orderBy = array();
			$dtColumns = self::orderpluck( $columns, 'dt' );
            for ( $i=0, $ien=count($request['order']) ; $i<$ien ; $i++ ) {
				// Convert the column index into the column data property
				$columnIdx = intval($request['order'][$i]['column']);
				$requestColumn = $request['columns'][$columnIdx];
				$columnIdx = array_search( $requestColumn['data'], $dtColumns );
				$column = $columns[ $columnIdx ];
                if ( $requestColumn['orderable'] == 'true' ) {
					$dir = $request['order'][$i]['dir'] === 'asc' ?
						'ASC' :
						'DESC';
					if(isset($column['tb'])):
						$orderBy[] = ''.$column['tb'].'.'.$column['db'].' '.$dir;
					else:
						$orderBy[] = ''.$column['db'].' '.$dir;
					endif;
				}
			}

			$order = 'ORDER BY '.implode(', ', $orderBy);
		}

		return $order;
	}


	/**
	 * Searching / Filtering
	 *
	 * Construct the WHERE clause for server-side processing SQL query.
	 *
	 * NOTE this does not match the built-in DataTables filtering which does it
	 * word by word on any field. It's possible to do here performance on large
	 * databases would be very poor
	 *
	 *  @param  array $request Data sent to server by DataTables
	 *  @param  array $columns Column information array
	 *  @param  array $bindings Array of values for PDO bindings, used in the
	 *    sql_exec() function
	 *  @return string SQL where clause
	 */
	static function filter ( $request, $columns, &$bindings ) {
        //print_r($request);die;
        //print_r($columns);die;
		$globalSearch = array();
		$columnSearch = array();
		//$dtColumns = self::pluck( $columns, 'dt' );
        $dtColumns = self::filterpluck( $columns, 'dt' );

		if ( isset($request['search']) && $request['search']['value'] != '' ) {
			$str = $request['search']['value'];

			for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {
				$requestColumn = $request['columns'][$i];
                //print_r($requestColumn);die;
                $columnIdx = array_search( $requestColumn['data'], $dtColumns );
				$column = $columns[ $columnIdx ];
                if ( $requestColumn['searchable'] == 'true' ) {
				    $binding = self::bind( $bindings, '%'.$str.'%', PDO::PARAM_STR );
                    if(isset($column['tb']))
                        $globalSearch[] = "".$column['tb'].".".$column['db']." LIKE ".$binding;
                    else
					   $globalSearch[] = "".$column['db']." LIKE ".$binding;
				}
			}
		}

		// Individual column filtering
		for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {
			$requestColumn = $request['columns'][$i];
			$columnIdx = array_search( $requestColumn['data'], $dtColumns );
			$column = $columns[ $columnIdx ];

			$str = $requestColumn['search']['value'];

			if ( $requestColumn['searchable'] == 'true' &&
			 $str != '' ) {
				$binding = self::bind( $bindings, '%'.$str.'%', PDO::PARAM_STR );
                if(isset($column['tb']))
                    $columnSearch[] = "".$column['tb'].".".$column['db']." LIKE ".$binding;
                else
				    $columnSearch[] = "".$column['db']." LIKE ".$binding;
			}
		}

		// Combine the filters into a single string
		$where = '';

		if ( count( $globalSearch ) ) {
			$where = '('.implode(' OR ', $globalSearch).')';
		}

		if ( count( $columnSearch ) ) {
			$where = $where === '' ?
				implode(' AND ', $columnSearch) :
				$where .' AND '. implode(' AND ', $columnSearch);
		}

		if ( $where !== '' ) {
			$where = 'WHERE '.$where;
		}

		return $where;
	}
    
    static function filter2 ( $searchCols, &$bindings ) {
        //print_r($searchCols);
        $columnSearch=array();
        for ( $i=0, $ien=count($searchCols) ; $i<$ien ; $i++ ) {
            $searchColumn = $searchCols[$i];
            //print_r($searchColumn);
            $str = $searchColumn[0]['val'][0];
            // echo $str;
            if($searchColumn[0]['op'] == DBCONSTANTS::op_between){
                $binding1 = self::bind( $bindings, $str, PDO::PARAM_STR );
                $str = $searchColumn[0]['val'][1];
                $binding2 = self::bind( $bindings, $str, PDO::PARAM_STR );
                $columnSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ".$binding1." ". DBCONSTANTS::op_and. " ".$binding2;
            }else if($searchColumn[0]['op'] == DBCONSTANTS::op_like){
                $binding = self::bind( $bindings, '%'.$str.'%', PDO::PARAM_STR );
                $columnSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ".$binding;
            }else if($searchColumn[0]['op'] == DBCONSTANTS::op_reg){
                $binding = self::bind( $bindings, '[[:<:]]'.$str, PDO::PARAM_STR );
                $columnSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ".$binding;
            }else if($searchColumn[0]['op'] == DBCONSTANTS::op_ereg){
                $binding = self::bind( $bindings, $str.'[[:>:]]', PDO::PARAM_STR );
                $columnSearch[] = "".$searchColumn[0]['db']." REGEXP ".$binding;
            }else if($searchColumn[0]['op'] == DBCONSTANTS::op_fureg){
                $binding = self::bind( $bindings, '[[:<:]]'.$str.'[[:>:]]', PDO::PARAM_STR );
                $columnSearch[] = "".$searchColumn[0]['db']." REGEXP ".$binding;
            }else if($searchColumn[0]['op'] == DBCONSTANTS::op_field_set){
                $binding = self::bind( $bindings, $str, PDO::PARAM_STR );
                $columnSearch[] = $searchColumn[0]['op']." ( ".$binding.", ".$searchColumn[0]['db']." )";
            }else if($searchColumn[0]['op'] == DBCONSTANTS::op_notnull){
                $columnSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op'];
            }else if($searchColumn[0]['op'] == DBCONSTANTS::op_notnull){
                $columnSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op'];
            }else if($searchColumn[0]['op'] == DBCONSTANTS::op_in){
                $explode = explode(",",$str);
                if(!empty($explode)){
                    $bindval = array();
                    foreach($explode as $str){
                        $bindval[] = self::bind( $bindings, $str, PDO::PARAM_STR );
                    }
                    if(!empty($bindval)){
                        $impbinVal = implode(',', $bindval);
                        $columnSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ( ".$impbinVal. " )";    
                    }
                }
            }else{
                $binding = self::bind( $bindings, $str, PDO::PARAM_STR );
                //$columnSearch[] = "".$searchColumn[0]['db']." = ".$binding;
                $columnSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ".$binding;
             }
        }
        //print_r($columnSearch);
  
        // Combine the filters into a single string
        $where = '';
        //echo count( $columnSearch );

        if ( count( $columnSearch ) ) {
            $where = $where === '' ?
            implode(' AND ', $columnSearch) :
            $where .' AND '. implode(' AND ', $columnSearch);
        }
        if ( $where !== '' ) {
            $where = 'WHERE '.$where;
        }
        //print_r($where);
        return $where;
    }
    
     static function filter3 ( $searchCols, &$bindings ) {
        //print_r($searchCols);
        $columnSearch=array();
        $globalSearch = array();
        for ( $i=0, $ien=count($searchCols) ; $i<$ien ; $i++ ) {
            $searchColumn = $searchCols[$i];
            //print_r($searchColumn);die;
            if(isset($searchColumn[0]['concat'])){
                if($searchColumn[0]['concat'] == 'OR'){
                    $str = $searchColumn[0]['val'][0];
                    // echo $str;
                    if($searchColumn[0]['op'] == DBCONSTANTS::op_between){
                        $binding1 = self::bind( $bindings, $str, PDO::PARAM_STR );
                        $str = $searchColumn[0]['val'][1];
                        $binding2 = self::bind( $bindings, $str, PDO::PARAM_STR );
                        $columnSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ".$binding1." ". DBCONSTANTS::op_and. " ".$binding2;
                    }else if($searchColumn[0]['op'] == DBCONSTANTS::op_like){
                        $binding = self::bind( $bindings, '%'.$str.'%', PDO::PARAM_STR );
                        $columnSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ".$binding;
                    }else if($searchColumn[0]['op'] == DBCONSTANTS::op_slike){
                        $binding = self::bind( $bindings, $str.'%', PDO::PARAM_STR );
                        $columnSearch[] = "".$searchColumn[0]['db']." LIKE ".$binding;
                    }else if($searchColumn[0]['op'] == DBCONSTANTS::op_elike){
                        $binding = self::bind( $bindings, '%'.$str, PDO::PARAM_STR );
                        $columnSearch[] = "".$searchColumn[0]['db']." LIKE ".$binding;
                    }else if($searchColumn[0]['op'] == DBCONSTANTS::op_field_set){
                        $binding = self::bind( $bindings, $str, PDO::PARAM_STR );
                        $columnSearch[] = $searchColumn[0]['op']." ( ".$binding.", ".$searchColumn[0]['db']." )";
                    }else{
                        $binding = self::bind( $bindings, $str, PDO::PARAM_STR );
                        //$columnSearch[] = "".$searchColumn[0]['db']." = ".$binding;
                        $columnSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ".$binding;
                    }
                }elseif($searchColumn[0]['concat'] == 'NOT'){

                    $str = $searchColumn[0]['val'][0];
                    if($searchColumn[0]['op'] == DBCONSTANTS::op_between){
                        $binding1 = self::bind( $bindings, $str, PDO::PARAM_STR );
                        $str = $searchColumn[0]['val'][1];
                        $binding2 = self::bind( $bindings, $str, PDO::PARAM_STR );
                        $globalSearch[] = "".$searchColumn[0]['db']." NOT ".$searchColumn[0]['op']." ".$binding1." ". DBCONSTANTS::op_and. " ".$binding2;
                    }else if($searchColumn[0]['op'] == DBCONSTANTS::op_like){
                        $binding = self::bind( $bindings, '%'.$str.'%', PDO::PARAM_STR );
                        $globalSearch[] = "".$searchColumn[0]['db']." NOT ".$searchColumn[0]['op']." ".$binding;
                    }else if($searchColumn[0]['op'] == DBCONSTANTS::op_slike){
                        $binding = self::bind( $bindings, $str.'%', PDO::PARAM_STR );
                        $globalSearch[] = "".$searchColumn[0]['db']." NOT LIKE ".$binding;
                    }else if($searchColumn[0]['op'] == DBCONSTANTS::op_elike){
                        $binding = self::bind( $bindings, '%'.$str, PDO::PARAM_STR );
                        $globalSearch[] = "".$searchColumn[0]['db']." NOT LIKE ".$binding;
                    }else if($searchColumn[0]['op'] == DBCONSTANTS::op_field_set){
                        $binding = self::bind( $bindings, $str, PDO::PARAM_STR );
                        $columnSearch[] = $searchColumn[0]['op']." ( ".$binding.", ".$searchColumn[0]['db']." )";
                    }else{
                        $binding = self::bind( $bindings, $str, PDO::PARAM_STR );
                        $globalSearch[] = "".$searchColumn[0]['db']." <> ".$binding;
                    }

                }else{
                    $str = $searchColumn[0]['val'][0];
                    if($searchColumn[0]['op'] == DBCONSTANTS::op_between){
                        $binding1 = self::bind( $bindings, $str, PDO::PARAM_STR );
                        $str = $searchColumn[0]['val'][1];
                        $binding2 = self::bind( $bindings, $str, PDO::PARAM_STR );
                        $globalSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ".$binding1." ". DBCONSTANTS::op_and. " ".$binding2;
                    }else if($searchColumn[0]['op'] == DBCONSTANTS::op_like){
                        $binding = self::bind( $bindings, '%'.$str.'%', PDO::PARAM_STR );
                        $globalSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ".$binding;
                    }else if($searchColumn[0]['op'] == DBCONSTANTS::op_slike){
                        $binding = self::bind( $bindings, $str.'%', PDO::PARAM_STR );
                        $globalSearch[] = "".$searchColumn[0]['db']." LIKE ".$binding;
                    }else if($searchColumn[0]['op'] == DBCONSTANTS::op_elike){
                        $binding = self::bind( $bindings, '%'.$str, PDO::PARAM_STR );
                        $globalSearch[] = "".$searchColumn[0]['db']." LIKE ".$binding;
                    }else if($searchColumn[0]['op'] == DBCONSTANTS::op_field_set){
                        $binding = self::bind( $bindings, $str, PDO::PARAM_STR );
                        $columnSearch[] = $searchColumn[0]['op']." ( ".$binding.", ".$searchColumn[0]['db']." )";
                    }else{
                        $binding = self::bind( $bindings, $str, PDO::PARAM_STR );
                        $globalSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ".$binding;
                    }
                    
                }
            }else{
                $str = $searchColumn[0]['val'][0];
                if($searchColumn[0]['op'] == DBCONSTANTS::op_between){
                    $binding1 = self::bind( $bindings, $str, PDO::PARAM_STR );
                    $str = $searchColumn[0]['val'][1];
                    $binding2 = self::bind( $bindings, $str, PDO::PARAM_STR );
                    $columnSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ".$binding1." ". DBCONSTANTS::op_and. " ".$binding2;
                }else if($searchColumn[0]['op'] == DBCONSTANTS::op_like){
                    $binding = self::bind( $bindings, '%'.$str.'%', PDO::PARAM_STR );
                    $columnSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ".$binding;
                }else if($searchColumn[0]['op'] == DBCONSTANTS::op_slike){
                    $binding = self::bind( $bindings, $str.'%', PDO::PARAM_STR );
                    $columnSearch[] = "".$searchColumn[0]['db']." LIKE ".$binding;
                }else if($searchColumn[0]['op'] == DBCONSTANTS::op_elike){
                    $binding = self::bind( $bindings, '%'.$str, PDO::PARAM_STR );
                    $columnSearch[] = "".$searchColumn[0]['db']." LIKE ".$binding;
                }else if($searchColumn[0]['op'] == DBCONSTANTS::op_field_set){
                    $binding = self::bind( $bindings, $str, PDO::PARAM_STR );
                    $columnSearch[] = $searchColumn[0]['op']." ( ".$binding.", ".$searchColumn[0]['db']." )";
                }else{
                    $binding = self::bind( $bindings, $str, PDO::PARAM_STR );
                    $columnSearch[] = "".$searchColumn[0]['db']." ".$searchColumn[0]['op']." ".$binding;
                }
            }
            
        }
        //print_r($columnSearch);die;
        //print_r($globalSearch);die;
  
        // Combine the filters into a single string
		$where = '';

		if ( count( $columnSearch ) ) {
			$where = '('.implode(' OR ', $columnSearch).')';
		}
         
		if ( count( $globalSearch ) ) {
			$where = $where === '' ?
				implode(' AND ', $globalSearch) :
				$where .' AND ('. implode(' AND ', $globalSearch).')';
		}

		if ( $where !== '' ) {
			$where = 'WHERE '.$where;
		}
        //echo $where;die;
		return $where;
    }

	/**
	 * Perform the SQL queries needed for an server-side processing requested,
	 * utilising the helper functions of this class, limit(), order() and
	 * filter() among others. The returned array is ready to be encoded as JSON
	 * in response to an SSP request, or can be modified if needed before
	 * sending back to the client.
	 *
	 *  @param  array $request Data sent to server by DataTables
	 *  @param  array $sql_details SQL connection details - see sql_connect()
	 *  @param  string $table SQL table to query
	 *  @param  string $primaryKey Primary key of the table
	 *  @param  array $columns Column information array
	 *  @return array          Server-side processing response array
	 */
	static function simple ( $request, $table, $primaryKey, $columns, $default=false ) {
		$bindings = array();
		$db = self::sql_connect();

		// Build the SQL query string from the request
		$limit = self::limit( $request, $columns );
		$order = self::order( $request, $columns );
		$where = self::filter( $request, $columns, $bindings, $default );
        
        $query = "SELECT SQL_CALC_FOUND_ROWS ".implode(", ", self::pluck($columns, 'db'))."
			 FROM $table
			 $where
			 $order
			 $limit";
        //echo $query;die;
		// Main query to actually get the data
		$data = self::sql_exec( $db, $bindings,$query );
        
		// Data set length after filtering
		$resFilterLength = self::sql_exec( $db, "SELECT FOUND_ROWS()" );
        //print_r($resFilterLength);die;
		//$recordsFiltered = $resFilterLength[0];
        $recordsFiltered = $resFilterLength[0]['FOUND_ROWS()'];

		// Total data set length
        $lengthSql = "SELECT COUNT({$primaryKey}) as count FROM   $table".($default !== false ? ' WHERE '.$default : '');

		$resTotalLength = self::sql_exec( $db, 	$lengthSql );
        //$recordsTotal = $resTotalLength[0][0]
        $recordsTotal = $resTotalLength[0]['count'];

        /**
		 * Output
		 */
		return array(
			"draw"            => intval( $request['draw'] ),
			"recordsTotal"    => intval( $recordsTotal ),
			"recordsFiltered" => intval( $recordsFiltered ),
			"data"            =>  self::data_output( $columns, $data, $request['start'] )
		);
	}
	
	static function simpleJoin ( $request, $table, $joinTable, $primaryKey, $columns, $default=false, $group = ''   ) {
		$bindings = array();
		$db = self::sql_connect();

		// Build the SQL query string from the request
		$limit = self::limit( $request, $columns );
		$order = self::order( $request, $columns );
        $where = self::filter( $request, $columns, $bindings, $default );
        
        $query = "SELECT SQL_CALC_FOUND_ROWS ".implode(", ", self::pluck($columns, 'db'))."
			 FROM $table
             $joinTable
			 $where
             $group
			 $order
			 $limit";
        //echo $query;die;
		// Main query to actually get the data
		$data = self::sql_exec( $db, $bindings,$query );

		// Data set length after filtering
		$resFilterLength = self::sql_exec( $db, "SELECT FOUND_ROWS()" );
        //print_r($resFilterLength);die;
		//$recordsFiltered = $resFilterLength[0];
        $recordsFiltered = $resFilterLength[0]['FOUND_ROWS()'];

		// Total data set length
		$resTotalLength = self::sql_exec( $db, 	"SELECT COUNT({$primaryKey}) as count FROM   $table $joinTable ".($default !== false ? ' WHERE '.$default : ''));
        //$recordsTotal = $resTotalLength[0][0]
        $recordsTotal = $resTotalLength[0]['count'];

        /**
		 * Output
		 */
		return array(
			"draw"            => intval( $request['draw'] ),
			"recordsTotal"    => intval( $recordsTotal ),
			"recordsFiltered" => intval( $recordsFiltered ),
			"data"            =>  self::data_output( $columns, $data, $request['start'] )
		);
	}
    
    static function complex ( $request, $table, $primaryKey, $columns, $whereResult=null, $whereAll=null, $group='' ) {
		$bindings = array();
		$db = self::sql_connect();
		$localWhereResult = array();
		$localWhereAll = array();
		$whereAllSql = '';

		// Build the SQL query string from the request
		$limit = self::limit( $request, $columns );
		$order = self::order( $request, $columns );
		$where = self::filter( $request, $columns, $bindings );
        
		$whereResult = self::_flatten( $whereResult );
        $whereAll = self::_flatten( $whereAll );

		if ( $whereResult ) {
			$where = $where ?
				$where .' AND '.$whereResult :
				'WHERE '.$whereResult;
		}

		if ( $whereAll ) {
			$where = $where ?
				$where .' AND '.$whereAll :
				'WHERE '.$whereAll;

			$whereAllSql = 'WHERE '.$whereAll;
		}
        
        $query = "SELECT SQL_CALC_FOUND_ROWS ".implode(", ", self::pluck($columns, 'db'))."
			 FROM $table
			 $where
			 $group
			 $order
			 $limit";
		//echo $query;die;
		// Main query to actually get the data
		$data = self::sql_exec( $db, $bindings, $query );

		// Data set length after filtering
		$resFilterLength = self::sql_exec( $db,
			"SELECT FOUND_ROWS()"
		);
		//$recordsFiltered = $resFilterLength[0][0];
        $recordsFiltered = $resFilterLength[0]['FOUND_ROWS()'];

		// Total data set length
		$resTotalLength = self::sql_exec( $db, $bindings,
			"SELECT COUNT({$primaryKey}) as count
			 FROM   $table ".
			$where
		);
        //$recordsTotal = $resTotalLength[0][0];
		$recordsTotal = $resTotalLength[0]['count'];;

		/*
		 * Output
		 */
		return array(
			"draw"            => intval( $request['draw'] ),
			"recordsTotal"    => intval( $recordsTotal ),
			"recordsFiltered" => intval( $recordsFiltered ),
			"data"            =>  self::data_output( $columns, $data, $request['start'] )
		);
	}
    
    static function complexJoin ( $request, $table, $joinTable, $primaryKey, $columns, $whereResult = null, $whereAll=null, $group='' ) {
		//print_r($columns);die;
        $bindings = array();
		$db = self::sql_connect();
		$localWhereResult = array();
		$localWhereAll = array();
		$whereAllSql = '';

		// Build the SQL query string from the request
		$limit = self::limit( $request, $columns );
        $order = self::order( $request, $columns );
        $where = self::filter( $request, $columns, $bindings );
                
		$whereResult = self::_flatten( $whereResult );
        $whereAll = self::_flatten( $whereAll );

		if ( $whereResult ) {
			$where = $where ?
				$where .' AND '.$whereResult :
				'WHERE '.$whereResult;
		}

		if ( $whereAll ) {
			$where = $where ?
				$where .' AND '.$whereAll :
				'WHERE '.$whereAll;

			$whereAllSql = 'WHERE '.$whereAll;
		}
        
        //print_r(implode(", ", self::pluck($columns, 'db')));die;
        $query = "SELECT SQL_CALC_FOUND_ROWS ".implode(", ", self::pluck($columns, 'db'))."
			 FROM $table $joinTable
			 $where
             $group
			 $order
			 $limit";
        //echo $query;die;
		// Main query to actually get the data
		$data = self::sql_exec( $db, $bindings, $query );
        
		// Data set length after filtering
		$resFilterLength = self::sql_exec( $db,
			"SELECT FOUND_ROWS()"
		);
        //print_r($resFilterLength);die;
		$recordsFiltered = $resFilterLength[0]['FOUND_ROWS()'];

		// Total data set length
        $query = "SELECT COUNT({$primaryKey}) as count FROM   $table $joinTable ".$where;
		$resTotalLength = self::sql_exec( $db, $bindings, $query );
		$recordsTotal = $resTotalLength[0]['count'];;

		/*
		 * Output
		 */
		return array(
			"draw"            => intval( $request['draw'] ),
			"recordsTotal"    => intval( $recordsTotal ),
			"recordsFiltered" => intval( $recordsFiltered ),
			"data"            => self::data_output( $columns, $data, $request['start'] )
		);
	}
    
    static function complexJoin2 ( $request, $table, $joinTable, $primaryKey, $columns, $whereResult = null, $whereAll=null, $group='' ) {
		//print_r($columns);die;
        $bindings = array();
		$db = self::sql_connect();
		$localWhereResult = array();
		$localWhereAll = array();
		$whereAllSql = '';

		// Build the SQL query string from the request
		$limit = self::limit( $request, $columns );
        $order = self::order( $request, $columns );
        $where = self::filter( $request, $columns, $bindings );
                
		$whereResult = self::_flatten( $whereResult );
        $whereAll = self::_flatten( $whereAll );

		if ( $whereResult ) {
			$where = $where ?
				$where .' AND '.$whereResult :
				'WHERE '.$whereResult;
		}

		if ( $whereAll ) {
			$where = $where ?
				$where .' AND '.$whereAll :
				'WHERE '.$whereAll;

			$whereAllSql = 'WHERE '.$whereAll;
		}
        
        //print_r(implode(", ", self::pluck($columns, 'db')));die;
        $query = "SELECT SQL_CALC_FOUND_ROWS ".implode(", ", self::pluck($columns, 'db'))."
			 FROM $table $joinTable
			 $where
             $group
			 $order
			 $limit";
        //echo $query;die;
		// Main query to actually get the data
		$data = self::sql_exec( $db, $bindings, $query );

		// Data set length after filtering
		$resFilterLength = self::sql_exec( $db,
			"SELECT FOUND_ROWS()"
		);
        //print_r($resFilterLength);die;
		$recordsFiltered = $resFilterLength[0]['FOUND_ROWS()'];

		// Total data set length
		$resTotalLength = self::sql_exec( $db, $bindings,
			"SELECT COUNT({$primaryKey}) as count
			 FROM   $table $joinTable".
			$where
		);
		$recordsTotal = $resTotalLength[0]['count'];;

		/*
		 * Output
		 */
		return array(
			"draw"            => intval( $request['draw'] ),
			"recordsTotal"    => intval( $recordsTotal ),
			"recordsFiltered" => intval( $recordsFiltered ),
			"data"            => self::data_output( $columns, $data, $request['start'] )
		);
	}
    
    static function complexJoinCustom ( $request, $table, $joinTable, $primaryKey, $columns,  $whereResult=null, $whereAll=null, $group , $order) {
		$bindings = array();
		$db = self::sql_connect();
		$localWhereResult = array();
		$localWhereAll = array();
		$whereAllSql = '';

		// Build the SQL query string from the request
		$limit = self::limit( $request, $columns );
        //$order = self::order( $request, $columns );
		$where = self::filter( $request, $columns, $bindings );
                
		$whereResult = self::_flatten( $whereResult );
        $whereAll = self::_flatten( $whereAll );

		if ( $whereResult ) {
			$where = $where ?
				$where .' AND '.$whereResult :
				'WHERE '.$whereResult;
		}

		if ( $whereAll ) {
			$where = $where ?
				$where .' AND '.$whereAll :
				'WHERE '.$whereAll;

			$whereAllSql = 'WHERE '.$whereAll;
		}
        
        //print_r(implode(", ", self::pluck($columns, 'db')));die;
        $query = "SELECT SQL_CALC_FOUND_ROWS ".implode(", ", self::pluck($columns, 'db'))."
			 FROM $table $joinTable
			 $where
             $group
			 $order
			 $limit";
		// Main query to actually get the data
		$data = self::sql_exec( $db, $bindings, $query );

		// Data set length after filtering
		$resFilterLength = self::sql_exec( $db,
			"SELECT FOUND_ROWS()"
		);
        //print_r($resFilterLength);die;
		$recordsFiltered = $resFilterLength[0]['FOUND_ROWS()'];

		// Total data set length
		$resTotalLength = self::sql_exec( $db, $bindings,
			"SELECT COUNT({$primaryKey}) as count
			 FROM   $table ".
			$whereAllSql
		);
		$recordsTotal = $resTotalLength[0]['count'];;

		/*
		 * Output
		 */
		return array(
			"draw"            => intval( $request['draw'] ),
			"recordsTotal"    => intval( $recordsTotal ),
			"recordsFiltered" => intval( $recordsFiltered ),
			"data"            => self::data_output( $columns, $data, $request['start'] )
		);
	}

    
	static function getSqlResultsAsArrayWithUIColumnsAsKey ( $columns, $data ) {
        $out = array();
        //print_r($columns);
        //print_r($data);die;
        for ( $i=0, $ien=count($data) ; $i<$ien ; $i++ ) {
            $row = array();
            //print_r("i:$i\n");
            //print_r($data[$i]);
     
            foreach ($columns as $key => $value){
                //print_r("Key: $key; Value: $value\n");
                $row[$key] = $data[$i][$value];
                //print_r($row);die;
            }
            //print_r($row);
            $out[] = $row;
            //print_r($out);
        }
        return $out;
    }
    static function execute_query_return_results_uicolumnsKeys ($columns, $bindings, $query ) {
 
        $db = self::sql_connect();
        // Build the SQL query string from the request
 
        //print_r($bindings);
        // Main query to actually get the data
        $data = self::sql_exec( $db, $bindings, $query);
        $cnt  = sizeof($data);
        $result = array();
        //print_r($cnt);
        //print_r($data);
        if($cnt > 1){
            $result[] = $data[0];
        }else{
            $result = $data;
        }
        
        //print_r($result);die;
        return self::getSqlResultsAsArrayWithUIColumnsAsKey($columns, $result);
    }
    
    static function execute_column_query ($columns, $bindings, $query ) {
        //echo 'test';
        $db = self::sql_connect();
        // Build the SQL query string from the request
 
        // Main query to actually get the data
        $data = self::sql_exec( $db, $bindings, $query);
        $cnt  = sizeof($data);
        $result = array();
        //print_r($cnt);
        //print_r($data);
        $result = $data;
        //print_r($result);die;
        return self::getSqlResultsAsArrayWithUIColumnsAsKey($columns, $result);
    }
	
	static function getSqlResultsAsArrayWithUIColumnsAsKeyArray ( $columns, $data ) {
        $out = array();
       // print_r($columns);print_r($data);die;
        for ( $i=0, $ien=count($data) ; $i<$ien ; $i++ ) {
            $row = array();
            //print_r("i:$i\n");
            //print_r($data[$i]);
     
            foreach ($columns as $key => $value){
                //print_r($key);print_r($value);die;
                //print_r("Key: $key; Value: $value\n");
                $row[$key] = $data[$i][$key];
                //print_r($row);die;
            }
            //print_r($row);
            $out[] = $row;
            //print_r($out);
        }
        return $out;
    }
    
    static function execute_column_query_array ($columns, $bindings, $query ) {
        //echo 'test';
        $db = self::sql_connect();
        // Build the SQL query string from the request
 
        // Main query to actually get the data
        $data = self::sql_exec( $db, $bindings, $query);
        $cnt  = sizeof($data);
        $result = array();
        //print_r($cnt);
        //print_r($data);
        $result = $data;
        //print_r($result);die;
        return self::getSqlResultsAsArrayWithUIColumnsAsKeyArray($columns, $result);
    }
    
    /**
     * Query excucte
     *
     */
    static function execute_sql_query ($query,$bindings){
        
        $db = self::sql_connect();
        
        //print_r($bindings);
        // Main query to actually get the data
        $data = self::sql_exec( $db, $bindings, $query);
        
        //print_r($data);
        return $data;
    }
    
    /** 
     * SQL Count
     */
    static function execute_sql_count ($query,$bindings){
        
        $db = self::sql_connect();
        
        //print_r($bindings);
        // Main query to actually get the data
        $data = self::sql_exec_count( $db, $bindings, $query);
        
        //print_r($data);
        return $data;
    }
    
    /**
    * Connect to the database
    * @return resource Database connection handle
    */
    static function sql_connect () {
        $sql_details = CONFIG::getDbConnDetails();    
        try {
            $db = @new PDO( "mysql:host={$sql_details['host']};dbname={$sql_details['db']};charset=utf8", $sql_details['user'], $sql_details['pass'],
                    array( PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION )
                );
        }catch (PDOException $e) {
            throw new RuntimeException($e->getMessage());
          //self::fatal(
          // "An error occurred while connecting to the database. ".
          // "The error reported by the server was: ".$e->getMessage()
          //    );
        }
        return $db;
    }
    
    
    /**
	 * Execute an SQL query on the database
	 *
	 * @param  resource $db  Database handler
	 * @param  array    $bindings Array of PDO binding values from bind() to be
	 *   used for safely escaping strings. Note that this can be given as the
	 *   SQL query string if no bindings are required.
	 * @param  string   $sql SQL query to execute.
	 * @return array         Result from the query (all rows)
	 */
	static function sql_exec ( $db, $bindings, $sql=null ) {
		// Argument shifting
		if ( $sql === null ) {
			$sql = $bindings;
		}

		$stmt = $db->prepare( $sql );
		//echo $sql;die;

		// Bind parameters
		if ( is_array( $bindings ) ) {
			for ( $i=0, $ien=count($bindings) ; $i<$ien ; $i++ ) {
				$binding = $bindings[$i];
				$stmt->bindValue( $binding['key'], $binding['val'], $binding['type'] );
			}
		}

		// Execute
		try {
			$stmt->execute();
		}
		catch (PDOException $e) {
			self::fatal( "An SQL error occurred: ".$e->getMessage() );
		}

		// Return all
		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
    
    static function sql_exec_count ( $db, $bindings, $sql=null ) {
    
        // Argument shifting
        if ( $sql === null ) {
            $sql = $bindings;
        }
        $stmt = null;
        $stmt = $db->prepare( $sql , array(PDO::ATTR_CURSOR => PDO::CURSOR_SCROLL));
        $stmt->execute();
        $data = $stmt->rowCount();
        return $data;
    }
    
    /** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Internal methods
	 */

	/**
	 * Throw a fatal error.
	 *
	 * This writes out an error message in a JSON string which DataTables will
	 * see and show to the user in the browser.
	 *
	 * @param  string $msg Message to send to the client
	 */
	static function fatal ( $msg ) {
		echo json_encode( array( 
			"error" => $msg
		) );

		exit(0);
	}

	/**
	 * Create a PDO binding key which can be used for escaping variables safely
	 * when executing a query with sql_exec()
	 *
	 * @param  array &$a    Array of bindings
	 * @param  *      $val  Value to bind
	 * @param  int    $type PDO field type
	 * @return string       Bound key to be used in the SQL where this parameter
	 *   would be used.
	 */
	static function bind ( &$a, $val, $type ) {
		$key = ':binding_'.count( $a );

		$a[] = array(
			'key' => $key,
			'val' => $val,
			'type' => $type
		);

		return $key;
	}


	/**
	 * Pull a particular property from each assoc. array in a numeric array, 
	 * returning and array of the property values from each item.
	 *
	 *  @param  array  $a    Array to get data from
	 *  @param  string $prop Property to read
	 *  @return array        Array of property values
	 */
	/** static function pluck ( $a, $prop ) {
        $out = array();
        for ( $i=0, $len=count($a) ; $i<$len ; $i++ ) {
            if(isset($a[$i]['tb']))
        	   $out[] = $a[$i]['tb'].".".$a[$i][$prop];
            else   
                $out[] = $a[$i][$prop];
		}

		return $out;
	} */
    
    static function pluck ( $a, $prop ) {
		
        $out = array();
        for ( $i=0, $len=count($a) ; $i<$len ; $i++ ) {
            if(isset($a[$i]['tb'])):
				if(isset($a[$i]['as'])):
	    			$out[] = $a[$i]['tb'].".".$a[$i][$prop]." ".$a[$i]['as'];
				else:
					$out[] = $a[$i]['tb'].".".$a[$i][$prop];
				endif;
            elseif(isset($a[$i]['co'])):
				if(isset($a[$i]['as'])):
	    			$out[] = $a[$i]['co']." ".$a[$i]['as'];
				else:
					$out[] = $a[$i]['co'];
				endif;
            elseif(isset($a[$i]['as'])):
                $out[] = $a[$i][$prop]." ".$a[$i]['as'];
            else:
            
                $out[] = $a[$i][$prop];
			endif;
		}

		return $out;
    }
    
    static function orderpluck ( $a, $prop ) {
		
        $out = array();
        for ( $i=0, $len=count($a) ; $i<$len ; $i++ ) {
            $out[] = $a[$i][$prop];
		}
		//print_r($out);die;
		return $out;
	}
    
    static function filterpluck ( $a, $prop ) {
		
        $out = array();
        for ( $i=0, $len=count($a) ; $i<$len ; $i++ ) {
            $out[] = $a[$i][$prop];
		}
		//print_r($out);die;
		return $out;
	}

	static function pluckinsert ( $a, $prop, &$bindings ) {
		
        $columnSearch = array();
        for ( $i=0, $len=count($a) ; $i<$len ; $i++ ) {
            //$out[] = $a[$i][$prop];
			$str = $a[$i][$prop];
			$binding = self::bind( $bindings, $str, PDO::PARAM_STR );

			$columnSearch[] = $binding;
		}

		//print_r($columnSearch);
  
        // Combine the filters into a single string
        $where = '';
        //echo count( $columnSearch );

        if ( count( $columnSearch ) ) {
            $where = $where === '' ?
            implode(', ', $columnSearch) :
            $where .', '. implode(', ', $columnSearch);
        }
        return $where;
	}
    
    static function pluckupdate ( $searchCols, &$bindings ) {
        //print_r($searchCols);die;
        $columnSearch=array();
        if(!empty($searchCols)){
            foreach($searchCols as $searchColumn){
                $str = $searchColumn['val'];
                $binding = self::bind( $bindings, $str, PDO::PARAM_STR );
                $columnSearch[] = "".$searchColumn['db']." ".$searchColumn['op']." ".$binding;
            }
        }
        //print_r($columnSearch);
  
        // Combine the filters into a single string
        $where = '';
        //echo count( $columnSearch );

        if ( count( $columnSearch ) ) {
            $where = $where === '' ?
            implode(', ', $columnSearch) :
            $where .', '. implode(', ', $columnSearch);
        }
        return $where;
    }
    
    /**
	 * Return a string from an array or a string
	 *
	 * @param  array|string $a Array to join
	 * @param  string $join Glue for the concatenation
	 * @return string Joined string
	 */
	static function _flatten ( $a, $join = ' AND ' ){
        if ( ! $a ) {
			return '';
		}
		else if ( $a && is_array($a) ) {
			return implode( $join, $a );
		}
		return $a;
	}

}