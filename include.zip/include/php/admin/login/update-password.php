<?php
try{
    //sleep(1);
    header('Content-type: application/json');
    require_once "../../../classes/session.class.php";
    require_once "../../../classes/loginutils.class.php";
    $mySession = Session::getInstance();
    UTILS::default_timezone();
    //print_r($_SESSION);die;
    
    if($mySession->TBOOK_LGTP == 'A' ){
        $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_sa;
        $ui_columns = array();
        $ui_columns = array(
            'txtAdId'   => DBCONSTANTS::col_sa_id,
            'txtAdPwd'  => DBCONSTANTS::col_sa_pwd,
        );
        
        $searchField_details = array();
        $searchField_details = array(
            'txtAdId'      => array('db' => DBCONSTANTS::col_sa_id, 'val' => $mySession->TBOOK_ID, 'op' =>  DBCONSTANTS::op_eq),
        );
        
        //print_r($searchField_details);die;
        $search_columns = array();
        UTILS::addSearchColumns2($searchField_details, $search_columns);
        
        //print_r($search_columns);die;
        
        $bindings = array();   
        $where = DBUTILS::filter2($search_columns, $bindings);
        $sql_query ="SELECT * FROM $table $where ";
        //print_r($sql_query);die;
        
        $data = DBUTILS::execute_column_query($ui_columns, $bindings, $sql_query);
        //print_r(sizeof($data));
        //print_r($data);die;
        $cnt = sizeof($data);
        if( $cnt == 0){
           $response_array['error'] = true;
           $response_array['msg']  = "Unauthorized user"; 
        }else{
            $txtPassword = trim($_POST['txtOPass']); 
            $password = $data[0]['txtAdPwd']; 
            $check = UTILS::tep_validate_password($txtPassword, $password);
            if($check){
                //echo 'in';die;
                $encrypt = UTILS::tep_encrypt_password($_POST['txtNPass']);
                
                $update_add_col = array();
                $update_add_col = array(
                    'pwd'   => array('db' => DBCONSTANTS::col_sa_pwd,   'val' =>  $encrypt),
                    'mdate' => array('db' => DBCONSTANTS::col_sa_mdate, 'val' =>  date('Y-m-d H:i:s'))
                );
                $update_column = array();
                UTILS::updateColumnsCustom($update_add_col, $update_column);
                //print_r($update_column);die;
                $update_row = array(
                	'txtAdId'      => array('db' => DBCONSTANTS::col_sa_id, 'val' => $data[0]['txtAdId'], 'op' =>  DBCONSTANTS::op_eq),
                );
                $update_col = array();
                UTILS::updateColumnsWhere2($update_row, $update_col);
                //print_r($update_col);die;
                if(sizeof($update_col) > 0){
    				DBUTILS::exec_updatesql( $table, $update_column, $update_col);
                }
                
                $response_array['error'] = false;
                $response_array['msg']  = "Password updated successfully. Please logout to check"; 
            }else{
                $response_array['error'] = true;
                $response_array['msg']  = "Old password mismatch"; 
            } 
        }
    }else{
        $response_array['error'] = true;
        $response_array['msg']  = "Unauthorized user"; 
    }
    $statusCode = 200;

}catch(Exception $e){
    $statusCode = 401;
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();
}
echo json_encode($response_array);
exit();
?>