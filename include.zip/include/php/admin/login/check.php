<?php ob_start();
try{
    $mySession = Session::getInstance();
    if($mySession->__isset('TBOOK_ID') ){
        
    }else{
        $admin_url  = CONFIG::admin_url;
        header('Location:'.$admin_url);
        exit(0);
    }
}catch(Exception $e){
    echo $e->getMessage();
}
ob_flush();
?>
