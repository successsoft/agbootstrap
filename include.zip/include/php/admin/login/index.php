<?php
//print_r($_POST);
//die;
 //print_r("invoke login process");die;
try{
    //sleep(1);
    header('Content-type: application/json');
    require_once "../../../classes/session.class.php";
    require_once "../../../classes/loginutils.class.php";
    
    $mySession = Session::getInstance();
    
    $isValidAdmin = LOGINUTILS::isValidAdmin($mySession);
    if(!$isValidAdmin){
        $response_array['error'] = true;
        $response_array['msg']  =  'Invalid credentials';
    }else{
        $response_array['error'] = false;
        $response_array['msg']['logintype'] = 'ADMIN';
    }
    echo json_encode($response_array);
    exit();
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['mesg']  = $e->getMessage();
    echo json_encode($response_array);
    exit();
}
?>