<?php 
require_once "../include/classes/config.class.php";
require_once "../include/classes/session.class.php"; 

$admin_url = CONFIG::admin_url;
try{
    $mySession = Session::getInstance();
    
    $mySession-> __unset('YH_ID');
    $mySession-> __unset('YH_NAME');
    $mySession-> __unset('YH_LGTP');
    $mySession->destroy();
    header('Location:'.$admin_url);
    exit(0);
    
}catch(Exception $e){
    echo $e->getMessage();
}
?>