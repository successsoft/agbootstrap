<?php
//print_r($_POST);die;
try{
    header('Content-type: application/json');
    if(!isset($req)){
        require_once "../../../classes/utils.class.php";    
    }
    $response_array['error'] = false;
    $ui_columns = array();
    $ui_columns = array(
        'hidClass'   => DBCONSTANTS::col_cls_id,
        'txtTitle'  => DBCONSTANTS::col_cls_name,
    );
    //print_r($ui_columns); die;
    
    $searchField_details = array();
    $searchField_details = array(
        'ss'    => array('db' => DBCONSTANTS::col_cls_ss, 'val' => 'A')
    );
    
    $search_columns = array();
    UTILS::addSearchColumns2($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_cls;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    $query ="SELECT * FROM $table $where ";
    //print_r($query);die;
    
    $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
    //print_r($data);die;
    
    $response_array['msg']['class-count']  = sizeof($data);
    
    /** Text book count **/
    $ui_columns = array();
    $ui_columns = array(
        'hidTBkId'   => DBCONSTANTS::col_tbk_id,
    );
    //print_r($ui_columns); die;
    
    $searchField_details = array();
    $searchField_details = array(
        'ss'    => array('db' => DBCONSTANTS::col_tbk_ss,       'val' => 'A')
    );
    
    $search_columns = array();
    UTILS::addSearchColumns2($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tbk;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    $query ="SELECT * FROM $table $where ";
    //print_r($query);die;
    
    
    $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
    //print_r($data);die;
    $response_array['msg']['textbook-count']  = sizeof($data);
    
    /** downloadcount **/
    $ui_columns = array();
    $ui_columns = array(
        'dcepub'      => array('db' => "SUM(".DBCONSTANTS::col_tbk_dcepub.")"),
		'dcpdf'      => array('db' => "SUM(".DBCONSTANTS::col_tbk_dcpdf.")"),
    );
    //print_r($ui_columns); die;
    
    $searchField_details = array();
    $searchField_details = array(
        'ss'    => array('db' => DBCONSTANTS::col_tbk_ss,       'val' => 'A')
    );
    
    $search_columns = array();
    UTILS::addSearchColumns2($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tbk;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    
    $implode_column = array();
    UTILS::implodeColumn($ui_columns, $implode_column);
    $sql_query = "SELECT ".implode(", ",$implode_column)." FROM $table $where ";
    //print_r($query);die;
    
    
    $data = DBUTILS::execute_column_query_array( $ui_columns, $bindings, $sql_query);
    //print_r($data);die;
    $response_array['msg']['download-count']  = $data[0]['dcepub'] + $data[0]['dcpdf'];
    
    /** feedback count **/
    $ui_columns = array();
    $ui_columns = array(
        'dcpdf'      => DBCONSTANTS::col_fdbk_id,
    );
    //print_r($ui_columns); die;
    
    $searchField_details = array();
    $searchField_details = array(
        'ss'    => array('db' => DBCONSTANTS::col_fdbk_ss,       'val' => 'A')
    );
    
    $search_columns = array();
    UTILS::addSearchColumns2($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_fdbk;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    
    $sql_query = "SELECT * FROM $table $where ";
    //print_r($query);die;
    
    
    $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $sql_query);
    //print_r($data);die;
    $response_array['msg']['feedback-count']  = sizeof($data);
    
    $statusCode = 200;
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();
    $statusCode = 405;
}
if(!isset($req)){
    echo json_encode($response_array);
    exit();
}else{
    
}