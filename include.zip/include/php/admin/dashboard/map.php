<?php
//print_r($_POST);die;
try{
    header('Content-type: application/json');
    if(!isset($req)){
        require_once "../../../classes/utils.class.php";    
    }
    
    UTILS::default_timezone();
    $min = date("Y-m-d H:i:s", strtotime("-5 minutes"));
    $response_array['error'] = false;
    
    $ui_columns = array();
    $ui_columns = array(
        'ftp'       => DBCONSTANTS::col_tbklg_ftp,
        'fss'       => DBCONSTANTS::col_tbklg_fss,
        'latitude'  => DBCONSTANTS::col_tbklg_lat,
        'longitude' => DBCONSTANTS::col_tbklg_long
    );
    //print_r($ui_columns); die;
    
    $searchField_details = array();
    $searchField_details = array(
        'ss'    => array('db' => DBCONSTANTS::col_tbklg_ss,     'op' => DBCONSTANTS::op_eq,     'val' => 'A'),
        'fss'   => array('db' => DBCONSTANTS::col_tbklg_fss,    'op' => DBCONSTANTS::op_nq,     'val' => 'N'),
        'dt'    => array('db' => DBCONSTANTS::col_tbklg_cdate,  'op' => DBCONSTANTS::op_gt,     'val' => $min),
        'fss2'  => array('db' => DBCONSTANTS::col_tbklg_fss,    'op' => DBCONSTANTS::op_eq,     'val' => trim($_GET['viewdata']))
    );
    
    $search_columns = array();
    UTILS::addSearchColumns4($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tbklg;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    $query ="SELECT * FROM $table $where GROUP BY ".DBCONSTANTS::col_tbklg_lat.", ".DBCONSTANTS::col_tbklg_long.", ".DBCONSTANTS::col_tbklg_fss;
    //print_r($query);die;
    
    $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
    //print_r($data);die;
    if(sizeof($data) > 0){
        $response_array['error'] = false;
        $response_array['msg'] = $data;
    }else{
        $response_array['error'] = true;
    }
    
    $ui_columns = array();
    $ui_columns = array(
        'dcnt'  => array('db' => "SUM(".DBCONSTANTS::col_tbklg_fss." = 'D')"),
		'vcnt'  => array('db' => "SUM(".DBCONSTANTS::col_tbklg_fss." = 'V')"),
    );
    //print_r($ui_columns); die;
    $searchField_details = array();
    $searchField_details = array(
        'ss'    => array('db' => DBCONSTANTS::col_tbklg_ss,     'op' => DBCONSTANTS::op_eq,     'val' => 'A'),
        'fss'   => array('db' => DBCONSTANTS::col_tbklg_fss,    'op' => DBCONSTANTS::op_nq,     'val' => 'N'),
        'dt'    => array('db' => DBCONSTANTS::col_tbklg_cdate,  'op' => DBCONSTANTS::op_gt,     'val' => $min),
    );
    
    $search_columns = array();
    UTILS::addSearchColumns4($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tbklg;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    
    $implode_column = array();
    UTILS::implodeColumn($ui_columns, $implode_column);
    $sql_query = "SELECT ".implode(", ",$implode_column)." FROM $table $where ";
    //print_r($sql_query);die;
    
    
    $data = DBUTILS::execute_column_query_array( $ui_columns, $bindings, $sql_query);
    //print_r($data);die;
    $response_array['count']['total']  = $data[0]['dcnt'] + $data[0]['vcnt'];
    $response_array['count']['dcnt']  = $data[0]['dcnt'];
    $response_array['count']['vcnt']  = $data[0]['vcnt'];
    
    $statusCode = 200;
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();
    $statusCode = 405;
}
if(!isset($req)){
    echo json_encode($response_array);
    exit();
}else{
    
}