<?php
try{
    require_once "../../../classes/utils.class.php";
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tbk;
    $jTable1 = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_lang;
    $jTable2 = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_cls;
    $jTable3 = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_sub;
    $jTable4 = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tm;
    
    $columns = array();
    $columns = array(
        array('db' => DBCONSTANTS::col_tbk_id,      'dt' => 'sno', 'tb' => $table),
        array('db' => DBCONSTANTS::col_lang_name,   'dt' => 'lng'),
        array('db' => DBCONSTANTS::col_cls_name,    'dt' => 'cls'),
        array('db' => DBCONSTANTS::col_sub_name,    'dt' => 'sub'),
        array('db' => DBCONSTANTS::col_tm_name,     'dt' => 'tm'),
		array('db' => DBCONSTANTS::col_tbk_desp,     'dt' => 'desp'),
        array('db' => DBCONSTANTS::col_tbk_fsnm,    'dt' => 'fdname',
            'formatter' => function( $d, $row ) {
                $base_url = CONFIG::base_url; 
                $image = '<a class="btn-link greyscale" href="javascript:void(0);" data-cls="'.$row[DBCONSTANTS::col_cls_name].'" data-sub="'.$row[DBCONSTANTS::col_sub_name].'" 
                    data-desp="'.$row[DBCONSTANTS::col_tbk_desp].'" data-lang="'.$row[DBCONSTANTS::col_lang_name].'" id="selEpubFile-'.$row[DBCONSTANTS::col_tbk_id].'">
                    <img style="width:20px;" src="dist/img/epub-icon.png" /></a>';
                if($d){
                    $image = '<a href="javascript:void(0);" class="upload-image"><img style="width:20px;" src="dist/img/epub-icon.png" /></a>';
                }
                return $image;
            }
        ),
        array('db' => DBCONSTANTS::col_tbk_pdf,    'dt' => 'pdf',
            'formatter' => function( $d, $row ) {
                $base_url = CONFIG::base_url; 
                $image = '<a class="btn-link greyscale" href="javascript:void(0);" data-cls="'.$row[DBCONSTANTS::col_cls_name].'" data-sub="'.$row[DBCONSTANTS::col_sub_name].'" 
                    data-desp="'.$row[DBCONSTANTS::col_tbk_desp].'" data-lang="'.$row[DBCONSTANTS::col_lang_name].'" id="selFile-'.$row[DBCONSTANTS::col_tbk_id].'">
                    <img style="width:20px;" src="dist/img/pdf-icon.svg" /></a>';
                if($d){
                    $base_url = CONFIG::base_url; 
                    $image = '<a href="javascript:void(0);" class="upload-image"><img style="width:20px;" src="dist/img/pdf-icon.svg" /></a>';
                }
                return $image;
            }
        ),
        array('db' => DBCONSTANTS::col_tbk_fdnm,   'dt' => 'fdname2'),
        array('db' => DBCONSTANTS::col_tbk_fonm,   'dt' => 'fonam'),
        array('db' => DBCONSTANTS::col_tbk_fsnm,   'dt' => 'file'),
        /** array('db' => DBCONSTANTS::col_tbk_fsnm,   'dt' => 'file',
            'formatter' => function( $d, $row ) {
                $image = "-";
                if($d){
                    if($_SERVER['HTTP_HOST'] == "192.168.1.33:8080" || $_SERVER['HTTP_HOST'] == "192.168.1.34" || $_SERVER['HTTP_HOST'] == "192.168.1.45"){
                        $targetPath = $_SERVER['DOCUMENT_ROOT'].'/textbook/uploads/files';
                    }else if($_SERVER['HTTP_HOST'] == "demo.klabstechindia.com"){
                        $targetPath = $_SERVER['DOCUMENT_ROOT'].'/uploads/files';
                    }
                    if(file_exists($targetPath.'/'.$d)){
    					$base_url = CONFIG::base_url; 
                        $image = '<a href="javascript:void(0)" data-src="'.$base_url.'uploads/files/'.$d.'" class="upload-image"><i class="fa fa-download"></i></a>';
                    }
                }
                return $image;
            }
        
        ), */
        array('db' => DBCONSTANTS::col_tbk_id,     'dt' => 'action', 'tb' => $table),
        array('db' => DBCONSTANTS::col_tbk_ss,     'dt' => 'ss', 'tb' => $table),
    ); 
    
     //print_r($columns);die;
    $primaryKey = $table.'.'.DBCONSTANTS::col_tbk_id;
    
    $where = array();
    $where[] = $table.'.'.DBCONSTANTS::col_tbk_ss." <> 'D'";
    
    if($_POST['selclass']){
        $where[] = $table.'.'.DBCONSTANTS::col_tbk_clsid." = '".$_POST['selclass']."'";
    }
    $joinTable = "LEFT JOIN $jTable1 ON $table.".DBCONSTANTS::col_tbk_langgid." = $jTable1.".DBCONSTANTS::col_lang_id."
                  LEFT JOIN $jTable2 ON $table.".DBCONSTANTS::col_tbk_clsid." = $jTable2.".DBCONSTANTS::col_cls_id."
                  LEFT JOIN $jTable3 ON $table.".DBCONSTANTS::col_tbk_subid." = $jTable3.".DBCONSTANTS::col_sub_id."
                  LEFT JOIN $jTable4 ON $table.".DBCONSTANTS::col_tbk_tmid." = $jTable4.".DBCONSTANTS::col_tm_id;
    
    $data = DBUTILS::complexJoin($_POST, $table, $joinTable, $primaryKey, $columns, $where );
    
    //print_r($data);die;
    echo json_encode( $data );
        
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();    
    echo json_encode($response_array);
    exit();
}

?>  