<?php
//print_r($_SERVER);die;
try{
    require_once "../../../classes/utils.class.php";
    header('Content-type: application/json');
    UTILS::default_timezone();
    
    $id = "";
	$dfor = "";
    $dtype = "N";
    if(isset($_POST['hidTBkId'])){
        $id = trim($_POST['hidTBkId']);
		$dfor = trim($_POST['dfor']);
        $dtype = trim($_POST['dtype']);
    }
    $response_array['error'] = false;
    $ui_columns = array();
    $ui_columns = array(
        'hidTBkId'  => DBCONSTANTS::col_tbk_id,
        'dcepub'    => DBCONSTANTS::col_tbk_dcepub,
        'dcpdf'     => DBCONSTANTS::col_tbk_dcpdf,
    );
    //print_r($ui_columns); die;
    
    $searchField_details = array();
    $searchField_details = array(
        'id'  => array('db' => DBCONSTANTS::col_tbk_id,  'val' => $id),
     );
    
    $search_columns = array();
    UTILS::addSearchColumns2($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tbk;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    $query ="SELECT * FROM $table $where ";
    //print_r($query);die;
    
    $response_array['error'] = false;
    $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
    //print_r($data);die;
    if(sizeof($data) > 0){

        $dcepub = $data[0]['dcepub'];
		$dcpdf = $data[0]['dcpdf'];

		if($dfor == "epub"){
			$dcepub = $data[0]['dcepub'] + 1;
		}else if($dfor == "pdf"){
			$dcpdf = $data[0]['dcpdf'] + 1;
		}
        
        $updateField_details = array();
        $updateField_details = array(
            'dcepub'	=> array('db' =>DBCONSTANTS::col_tbk_dcepub,	'op' => DBCONSTANTS::op_eq, 'val' => $dcepub),
			'dcpdf'		=> array('db' =>DBCONSTANTS::col_tbk_dcpdf,		'op' => DBCONSTANTS::op_eq, 'val' => $dcpdf)
        );
        
        $update_columns = array();
        UTILS::updateColumnsCustom($updateField_details, $update_columns);
        //print_r($update_columns);die;
        $update_row = array();
        $update_row = array(
            'txtOptId'  => array('db' =>DBCONSTANTS::col_tbk_id, 'op' => DBCONSTANTS::op_eq, 'val' => $data[0]['hidTBkId'])
        );
        //print_r($update_row);die;
        $update_col = array();
        UTILS::updateColumnsWhere2($update_row, $update_col);
        //print_r($update_col);die;
        if(sizeof($update_col) > 0){
            DBUTILS::exec_updatesql( $table, $update_columns, $update_col);
        }
        
        $ipAddr = UTILS::getIp();
        //$new_arr[]= unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ipAddr));
        //print_r($new_arr);
        $geoIP  = json_decode(file_get_contents("http://freegeoip.net/json/$ipAddr"), true);
        //print_r($geoIP);die;
        if(sizeof($geoIP) > 0){
            $insert_columns = array();
            $db_code = DBCONSTANTS::db_code;
            
            array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_tbklg_tbkid.$db_code,    'val' => $id));
            array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_tbklg_ipadd.$db_code,    'val' => $ipAddr));
            array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_tbklg_lat.$db_code,      'val' => $geoIP['latitude']));
            array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_tbklg_long.$db_code,     'val' => $geoIP['longitude']));
            array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_tbklg_ftp.$db_code,      'val' => $dfor));
            array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_tbklg_fss.$db_code,      'val' => $dtype));
            array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_tbklg_ss.$db_code,       'val' => 'A'));
            array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_tbklg_cdate.$db_code,    'val' => date('Y-m-d H:i:s')));
            array_push($insert_columns,array('db' => $db_code.DBCONSTANTS::col_tbklg_mdate.$db_code,    'val' => date('Y-m-d H:i:s')));
            //print_r($insert_columns);die;
            $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tbklg;
            DBUTILS::exec_insertsql( $table, $insert_columns);
        }
       
    }
    $response_array['error'] = false;
}catch(Exception $e){
    $statusCode = 405;
    $response_array['error'] = true;
    $response_array['data']['msg']  = $e->getMessage();
}
echo json_encode($response_array);
exit();