<?php

ini_set('post_max_size', '2000M');
ini_set('upload_max_filesize', '2000M');

require_once "../../../classes/class.upload.php";
require_once "../../../classes/utils.class.php";
$targetPath = '../../../../tnscert-ebook/download/'; // Relative to the root
//print_r( $_POST );print_r( $_FILES );die;


function rmdir_recursive($dir) {
    foreach(scandir($dir) as $file) {
       if ('.' === $file || '..' === $file) continue;
       if (is_dir("$dir/$file")) rmdir_recursive("$dir/$file");
       else unlink("$dir/$file");
   }
   
   rmdir($dir);
}

if (!empty($_FILES)) {
    // Validate the file type
    $fileTypes = array('epub');
    
    if (!file_exists($targetPath)) {
        mkdir($targetPath);
    }
    
    // File 
    //print_r($_FILES['Filedata']);die;
    $fileParts = pathinfo($_FILES['Filedata']['name']);
    if (in_array(strtolower($fileParts['extension']),$fileTypes)) {
        //echo 'in';die;
        $_FILES['Filedata']['name'] = str_replace(' ', '_', $_FILES['Filedata']['name']);
        /** $str_len = strlen($_FILES['Filedata']['name']);
        if($str_len > 10):
            $path = $_FILES['Filedata']['name'];
            $ext = pathinfo($path, PATHINFO_EXTENSION);
            $photo1 = substr($_FILES['Filedata']['name'],0,5);
            $photo = time()."_".$photo1.'.'.$ext;
        else:
            $photo = time()."_".$_FILES['Filedata']['name'];
        endif;
        
        $photo = str_replace(" ","_",$photo); */
        $new_image_name = trim($_FILES['Filedata']['name']);
        $size =  UTILS::formatSizeUnits( $_FILES['Filedata']['size']);
        
        try {
        //throw exception if can't move the file
            $tempFile = $_FILES['Filedata']['tmp_name'];
            $targetFile = $targetPath."/".$new_image_name;
        	if (!move_uploaded_file( $tempFile, $targetFile )) {
        		$json = array(
                    "result" 	=> 0, 
                    "error"     => $e->getMessage()
                );
        	}
            
            
            $ext = pathinfo($_FILES['Filedata']['name'], PATHINFO_EXTENSION);
            $filename = $_FILES["Filedata"]["name"];
    		$source = $_FILES["Filedata"]["tmp_name"];
    		$type = $_FILES["Filedata"]["type"];
    
    		$name = explode(".", $filename);
    		$accepted_types = array('application/zip', 'application/x-zip-compressed', 'multipart/x-zip', 'application/x-compressed', 'application/epub+zip');
    		foreach($accepted_types as $mime_type) {
    			if($mime_type == $type) {
    				  $okay = true;
    				  break;
    			} 
    		}
    
    		$continue = strtolower($name[1]) == 'zip' ? true : false;
    		if(!$continue) {
    			$message = "The file you are trying to upload is not a .zip file. Please try again.";
    		}
    
    		/* PHP current path */
    		$path = '../../../../reader/bookshelf/';  // absolute path to the directory where zipper.php is in
    		//  $filenoext1 = rename($filename, $filename + '.zip');
            $filename = preg_replace('/\.[^.]+$/','',$filename);
    		$filenoext = basename ($filename, '.zip');  // absolute path to the directory where zipper.php is in (lowercase)
    		$filenoext = basename ($filenoext, '.ZIP');  // absolute path to the directory where zipper.php is in (when uppercase)
    
    		$targetdir = $path . $filenoext; // target directory
    		$targetzip = $path . $filename; // target zip file
    		//echo $targetzip;die;
    		/* create directory if not exists', otherwise overwrite */
    		/* target directory is same as filename without extension */
    
    		if (is_dir($targetdir))  rmdir_recursive ( $targetdir);
    	 
    		 
    		mkdir($targetdir, 0777);
    	  
    		/* here it is really happening */
    		$file_name = $targetzip."/".$filename;
            $file_name = $targetFile;
    		//if(move_uploaded_file($source, $file_name)) {
    			$zip = new ZipArchive();
    			$x = $zip->open($file_name);  // open the zip file to extract
    			if ($x === true) {
    				$zip->extractTo($targetdir); // place in the directory with same name  
    				$zip->close();
    				//unlink($file_name);
    			}
    			$message = "Your .zip file was uploaded and unpacked.";
    		/** } else {      
				//$message = print_r($_FILES);
				$message = "There was a problem with the upload. Please try again.";
    		} */
    	
        
        	$json = array(
                "result" 	=> 1, 
                "fname"     => $new_image_name,
                "fdname"    => $filenoext,
                "ftype"     => $_FILES['Filedata']['type'],
                "oname"     => $_FILES['Filedata']['name'],
                "ext"       => $ext,
                "size"      => UTILS::formatSizeUnits($size)
            );
            
        } catch (Exception $e) {
        	$json = array(
                "result" 	=> 0, 
                "error"     => $e->getMessage()
            );
        }
        
        //print_r($json);die;
        
    } else {
    	$json = array(
            "result" => 0,
            "msg"   => "Invalid File Type"
        );
    }
    
    $encoded = json_encode($json);
    echo $encoded; die;		
}

?>