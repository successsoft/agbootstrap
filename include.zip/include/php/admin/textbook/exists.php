<?php 
try {
    require_once "../../../classes/utils.class.php";
    header('Content-type: application/json');
    
    $tbId = @$_POST['hidTextBook'];
    $searchField_details = array();
	if(isset($tbId)){
        $searchField_details = array(
            'lang'  => array('db' => DBCONSTANTS::col_tbk_langgid,  'op' => DBCONSTANTS::op_eq, 'val' => trim($_POST['selLang'])),
            'cls'   => array('db' => DBCONSTANTS::col_tbk_clsid,    'op' => DBCONSTANTS::op_eq, 'val' => trim($_POST['selClass'])),
            'sub'   => array('db' => DBCONSTANTS::col_tbk_subid,    'op' => DBCONSTANTS::op_eq, 'val' => trim($_POST['selSub'])),
            //'tm'    => array('db' => DBCONSTANTS::col_tbk_tmid,     'op' => DBCONSTANTS::op_eq, 'val' => trim($_POST['selTm'])),
            'Id'    => array('db' => DBCONSTANTS::col_tbk_id,       'op' => DBCONSTANTS::op_nq, 'val' => $_POST['hidTextBook'])
        );
    }else{
        $searchField_details = array(
            'lang'  => array('db' => DBCONSTANTS::col_tbk_langgid,  'op' => DBCONSTANTS::op_eq, 'val' => trim($_POST['selLang'])),
            'cls'   => array('db' => DBCONSTANTS::col_tbk_clsid,    'op' => DBCONSTANTS::op_eq, 'val' => trim($_POST['selClass'])),
            'sub'   => array('db' => DBCONSTANTS::col_tbk_subid,    'op' => DBCONSTANTS::op_eq, 'val' => trim($_POST['selSub'])),
            //'tm'    => array('db' => DBCONSTANTS::col_tbk_tmid,     'op' => DBCONSTANTS::op_eq, 'val' => trim($_POST['selTm']))
        );
        
    }
    $search_columns = array();
    UTILS::addSearchColumns3($searchField_details, $search_columns);
    //print_r($search_columns);
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tbk;
    
    $bindings = array();   
    $where = DBUTILS::filter2($search_columns,$bindings);
    $sql_query ="SELECT * FROM $table $where ";
    //print_r($sql_query);die;
    
    $data = DBUTILS::execute_sql_query($sql_query, $bindings);
    if(sizeof($data) > 0):
    	$response_array = false;
    else:
    	$response_array = true;
    endif;
    echo json_encode($response_array);
    exit();
} catch(PDOException $ex) {
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();
    echo json_encode($response_array);
    exit();
}
?>