<?php

ini_set('post_max_size', '2000M');
ini_set('upload_max_filesize', '2000M');

require_once "../../../classes/utils.class.php";
$targetFile = "../../../../tnscert-ebook/download/";
UTILS::default_timezone();

if (!empty($_FILES)) {
    // Validate the file type
    $fileTypes = array('epub');
    
    //print_r($_FILES['Filedata']);die;
    
    $fileParts = pathinfo($_FILES['Filedata']['name']);
    if (in_array(strtolower($fileParts['extension']),$fileTypes)) {
        $ext = pathinfo($_FILES['Filedata']['name'], PATHINFO_EXTENSION);
    	$size =  UTILS::formatSizeUnits( $_FILES['Filedata']['size']);
    
        $file_name = $_FILES['Filedata']['name'];
    	$temp_name = $_FILES['Filedata']['tmp_name'];
    	try{
            if (!move_uploaded_file( $temp_name, $targetFile.'/'.$file_name )) {
        		$json = array(
                    "result" 	=> 0, 
                    "error"     => $e->getMessage()
                );
            } else{
                $json = array(
    				"result" 	=> 1,
    				"fdname"    => $file_name,
    				"fname"     => $file_name,
    				"ftype"     => $_FILES['Filedata']['type'],
    				"oname"     => $file_name,
    				"ext"       => $ext,
    				"size"      => UTILS::formatSizeUnits($size)
    			);
            }
        }catch(Exception $e){
    		$json = array(
                "result" => 0,
                "msg"   => $e->getMessage()
            );
    	   
    	}
     }else{
        $json = array(
            "result" => 0,
            "msg"   => "Invalid File format"
        );
     }
}
$encoded = json_encode($json);
echo $encoded; die;	
?>