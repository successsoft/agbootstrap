<?php

ini_set('post_max_size', '2000M');
ini_set('upload_max_filesize', '2000M');

require_once "../../../classes/utils.class.php";
require_once "../../../../google-storage/index.php"; 

UTILS::default_timezone();
if (!empty($_FILES)) {
    // Validate the file type
    $fileTypes = array('epub');
    $fileParts = pathinfo($_FILES['Filedata']['name']);
    if (in_array(strtolower($fileParts['extension']),$fileTypes)) {
        //print_r($_FILES['Filedata']);die;
        $ext = pathinfo($_FILES['Filedata']['name'], PATHINFO_EXTENSION);
    	$size =  UTILS::formatSizeUnits( $_FILES['Filedata']['size']);
    
        $file_name = $_FILES['Filedata']['name'];
    	$temp_name = $_FILES['Filedata']['tmp_name'];
    	$type = $_FILES["Filedata"]["type"];
    	$name = explode(".", $file_name);
    	$accepted_types = array('application/zip', 'application/x-zip-compressed', 'multipart/x-zip', 'application/x-compressed', 'application/epub+zip');
    	foreach($accepted_types as $mime_type) {
    		if($mime_type == $type) {
    			  $okay = true;
    			  break;
    		} 
    	}
    
    	$continue = strtolower($name[1]) == 'zip' ? true : false;
    	if(!$continue) {
    		$message = "The file you are trying to upload is not a .zip file. Please try again.";
    	}
    
    	/* PHP current path */
    	$path = '../../../../reader/bookshelf/';  // absolute path to the directory where zipper.php is in
    	$filename = preg_replace('/\.[^.]+$/','',$file_name);
    	$filenoext = basename ($filename, '.zip');  // absolute path to the directory where zipper.php is in (lowercase)
    	$filenoext = basename ($filenoext, '.ZIP');  // absolute path to the directory where zipper.php is in (when uppercase)
    
    	try{
    
    		$object = $bucket->upload(file_get_contents($temp_name), 
    			[ 
    				'name' => "download/".$file_name,
    				'mimeType' => $_FILES['Filedata']['type']
    			]
    		);
    
    		$json = array(
    				"result" 	=> 1, 
                    "fname"     => $_FILES['Filedata']['name'],
                    "fdname"    => $filenoext,
                    "ftype"     => $_FILES['Filedata']['type'],
                    "oname"     => $_FILES['Filedata']['name'],
                    "ext"       => $ext,
                    "size"      => UTILS::formatSizeUnits($size)
    			);
    	}catch(Exception $e){
    		$json = array(
                "result" => 0,
                "msg"   => $e->getMessage()
            );
    	   
    	}
     }else{
        $json = array(
            "result" => 0,
            "msg"   => "Invalid File format"
        );
     }
}
$encoded = json_encode($json);
echo $encoded; die;	
?>