<?php

ini_set('post_max_size', '2000M');
ini_set('upload_max_filesize', '2000M');

require_once "../../../classes/class.upload.php";
require_once "../../../classes/utils.class.php";
$targetPath = '../../../../uploads/pdf-files'; // Relative to the root
//print_r( $_POST );print_r( $_FILES );die;


function rmdir_recursive($dir) {
    foreach(scandir($dir) as $file) {
       if ('.' === $file || '..' === $file) continue;
       if (is_dir("$dir/$file")) rmdir_recursive("$dir/$file");
       else unlink("$dir/$file");
   }
   
   rmdir($dir);
}

if (!empty($_FILES)) {
    // Validate the file type
    $fileTypes = array('pdf');
    
    if (!file_exists($targetPath)) {
        mkdir($targetPath);
    }
    
    // File 
    //print_r($_FILES['Filedata']);die;
    $fileParts = pathinfo($_FILES['Filedata']['name']);
    if (in_array(strtolower($fileParts['extension']),$fileTypes)) {
        //echo 'in';die;
        $_FILES['Filedata']['name'] = str_replace(' ', '_', $_FILES['Filedata']['name']);
        $str_len = strlen($_FILES['Filedata']['name']);
        if($str_len > 10):
            $path = $_FILES['Filedata']['name'];
            $ext = pathinfo($path, PATHINFO_EXTENSION);
            $photo1 = substr($_FILES['Filedata']['name'],0,5);
            $photo = time()."_".$photo1.'.'.$ext;
        else:
            $photo = time()."_".$_FILES['Filedata']['name'];
        endif;
        
        $photo = str_replace(" ","_",$photo);
        $new_image_name = trim($photo);
        $size =  UTILS::formatSizeUnits( $_FILES['Filedata']['size']);
        
        $photo = str_replace(" ","_",$photo);
        $new_image_name = trim($photo);
        $handle = new upload($_FILES['Filedata']);
			
		if($handle->uploaded) {
			$handle->file_auto_rename = true;
			$handle->file_new_name_ext = false;
			$handle->file_new_name_body  = $new_image_name;
            $handle->image_resize         = false; //true
            $handle->process($targetPath);
            if ($handle->processed){
                $size =  $handle->file_src_size;
                $json = array(
                    "result" 	=> 1,
                    "fdname"    => "",
                    "fname"     => "uploads/pdf-files/".$handle->file_dst_name,
                    "ftype"     => $handle->file_src_mime,
                    "oname"     => $handle->file_src_name,
                    "ext"       => $handle->file_src_name_ext,
                    "size"      => UTILS::formatSizeUnits($size)
                );
            }else{
       		   $json = array("result" => 0);
            }
        }
       //print_r($json);die;
        
    } else {
    	$json = array(
            "result" => 0,
            "msg"   => "Invalid File Type"
        );
    }
    
    $encoded = json_encode($json);
    echo $encoded; die;		
}

?>