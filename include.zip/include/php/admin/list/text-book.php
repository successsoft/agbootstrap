<?php
//print_r($_POST);die;
try{
    header('Content-type: application/json');
    if(!isset($req)){
        require_once "../../../classes/utils.class.php"; 
        $epubTgPat = '../../../../tnscert-ebook/download/';
        $bcTgPat = '../../../../uploads/cover/';
        $pdfTgPat = '../../../../tnscert-ebook/pdf-files/';
        $lang = trim($_GET['lang']);
        $cls = trim($_GET['cls']);
        $sub = trim($_GET['sub']);
    }else{
        $epubTgPat = '../reader/bookshelf/';
        $bcTgPat = '../uploads/cover/';
        $pdfTgPat = '../uploads/pdf-files/';
    }
    
    $base_url = CONFIG::base_url;
    
    $ui_columns = array();
    $ui_columns = array(
        'hidTBkId'   => DBCONSTANTS::col_tbk_id,
        'taDesp'    => DBCONSTANTS::col_tbk_desp,
        'fdname'    => DBCONSTANTS::col_tbk_fdnm,
        'oname'     => DBCONSTANTS::col_tbk_fonm,
        'fname'     => DBCONSTANTS::col_tbk_fsnm,
        'ext'       => DBCONSTANTS::col_tbk_ftp,
        'size'      => DBCONSTANTS::col_tbk_fsz,
        'bcfname'   => DBCONSTANTS::col_tbk_bkcv,
        'pdffname'  => DBCONSTANTS::col_tbk_pdf
    );
    //print_r($ui_columns); die;
    
    $searchField_details = array();
    $searchField_details = array(
        'lang'  => array('db' => DBCONSTANTS::col_tbk_langgid,  'val' => $lang),
        'cls'   => array('db' => DBCONSTANTS::col_tbk_clsid,    'val' => $cls),
        'sub'   => array('db' => DBCONSTANTS::col_tbk_subid,    'val' => $sub),
        //'tm'    => array('db' => DBCONSTANTS::col_tbk_tmid,     'val' => $tm),
        'ss'    => array('db' => DBCONSTANTS::col_tbk_ss,       'val' => 'A')
    );
    
    $search_columns = array();
    UTILS::addSearchColumns2($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tbk;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    $query ="SELECT * FROM $table $where ";
    //print_r($query);die;
    
    $response_array['error'] = false;
    $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
    //print_r($data);die;
    if(sizeof($data) > 0){
        $response_array['error']  = false;
        $response_array['msg']  = $data[0];
        foreach($data as $row){
            
            $epub = $row['fdname'];
            $epub = htmlspecialchars_decode($row['fdname'], ENT_QUOTES);
            if($epub){
                if(strlen($epub) > 0){
                    //echo $epubTgPat.$epub;die;
                    if(file_exists($epubTgPat.$epub)){
                        $row['fdname']  = $base_url.'reader/i/?book='.$epub;
                    }else{
                        $row['fdname']  = "";
                    }
                }else{
                    $row['fdname']  = "";
                }
            }else{
                $row['fdname']  = "";
            }
            
            $row['epubdownload']  = "";
            $epub = $row['fname'];
            $epub = htmlspecialchars_decode($row['fname'], ENT_QUOTES);
            if($epub){
                if(strlen($epub) > 0){
                    //echo $epubTgPat.$epub;die;
                    if(file_exists($epubTgPat.$epub)){
                        $row['epubdownload']  = $base_url.'tnscert-ebook/download/'.$epub;
                    }
                }
            }
            
            $bookCover = $row['bcfname'];
            $bookCover = htmlspecialchars_decode($row['bcfname'], ENT_QUOTES);
            if($bookCover){
                if(strlen($bookCover) > 0){
                    //echo $bcTgPat.$bookCover;die;
                    if(file_exists($bcTgPat.$bookCover)){
                        $row['bcfname']  = $base_url.'uploads/cover/'.$bookCover;
                    }else{
                        //$row['bcfname']  = "img/book.png";
						$row['bcfname']  = $base_url."img/book.png";
                    }
                }else{
                    $row['bcfname']  = $base_url."img/book.png";
                }
            }else{
                $row['bcfname']  = $base_url."img/book.png";
            }
            //print_r($row);
            $pdf = htmlspecialchars_decode($row['pdffname'], ENT_QUOTES);
            $pdf = html_entity_decode($pdf,ENT_QUOTES,UTF-8);
            //echo $pdf;die;
            //$pdf = $row['pdffname'];
            if($pdf){
                if(strlen($pdf) > 0){
                    if(file_exists($pdfTgPat.$pdf)){
                        $row['pdffname']  = $base_url.'tnscert-ebook/pdf-files/'.$pdf;
                    }else{
                        //$row['pdffname']  = "";
                        $row['pdffname']  = $base_url.'tnscert-ebook/pdf-files/'.$pdf;
                    }
                }else{
                    $row['pdffname']  = "";
                }
            }else{
                $row['pdffname']  = "";
            }
            $output[] = $row;
        }
        $response_array['msg'] = $output;
    }else{
        $response_array['error']  = true;
    }
    $statusCode = 200;
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();
    $statusCode = 405;
}
if(!isset($req)){
    echo json_encode($response_array);
    exit();
}else{
    
}
