<?php
//print_r($_POST);die;
try{
    header('Content-type: application/json');
    if(!isset($req)){
        require_once "../../../classes/utils.class.php"; 
        
        $epubTgPat = '../../../../tnscert-ebook/download/';
        $bcTgPat = '../../../../uploads/cover/';
        $pdfTgPat = '../../../../tnscert-ebook/pdf-files/';
		
        $lang = trim($_GET['lang']);
        $cls = trim($_GET['cls']);
    }else{
        $epubTgPat = '../reader/bookshelf/';
        $epubDwTgPat = '../reader/download/';
        $bcTgPat = '../uploads/cover/';
        $pdfTgPat = '../uploads/pdf-files/';
    }
    UTILS::default_timezone();
    $base_url = CONFIG::base_url;
    
    
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_sub;
    $ui_columns = array();
    $ui_columns = array(
        'hidSubId'  => DBCONSTANTS::col_sub_id,
        'txtSubNm'  => DBCONSTANTS::col_sub_name
    );
    
    $searchField_details = array();
    $searchField_details = array(
        'lang'  => array('db' => $table.".".DBCONSTANTS::col_sub_langid,    'val' => $lang, 'op' => DBCONSTANTS::op_eq),
        'cls'   => array('db' => $table.".".DBCONSTANTS::col_sub_clsid,     'val' => $cls,  'op' => DBCONSTANTS::op_in),
        'ss'    => array('db' => $table.".".DBCONSTANTS::col_tbk_ss,        'val' => 'A',   'op' => DBCONSTANTS::op_eq)
    );
    
    $search_columns = array();
    UTILS::addSearchColumns4($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    
    $query ="SELECT * FROM $table $where ";
    //print_r($query);die;
    
    $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
    //print_r($data);die;
    if(sizeof($data) > 0){
        $output = array();
        
        foreach($data as $row){
            $sub = $row['hidSubId'];
            $txtSubNm = $row['txtSubNm'];
            $ui_columns = array();
            $ui_columns = array(
                'hidTBkId'   => DBCONSTANTS::col_tbk_id,
                'taDesp'    => DBCONSTANTS::col_tbk_desp,
                'fdname'    => DBCONSTANTS::col_tbk_fdnm,
                'oname'     => DBCONSTANTS::col_tbk_fonm,
                'fname'     => DBCONSTANTS::col_tbk_fsnm,
                'ext'       => DBCONSTANTS::col_tbk_ftp,
                'size'      => DBCONSTANTS::col_tbk_fsz,
                'bcfname'   => DBCONSTANTS::col_tbk_bkcv,
                'pdffname'  => DBCONSTANTS::col_tbk_pdf
            );
            //print_r($ui_columns); die;
            
            $searchField_details = array();
            $searchField_details = array(
                'lang'  => array('db' => DBCONSTANTS::col_tbk_langgid,  'val' => $lang,     'op' => DBCONSTANTS::op_eq),
                'cls'   => array('db' => DBCONSTANTS::col_tbk_clsid,    'val' => $cls,      'op' => DBCONSTANTS::op_eq),
                'sub'   => array('db' => DBCONSTANTS::col_tbk_subid,    'val' => $sub,      'op' => DBCONSTANTS::op_eq),
                'tm'    => array('db' => DBCONSTANTS::col_tbk_desp,     'val' => 'Whole book', 'op' => DBCONSTANTS::op_like),
                'ss'    => array('db' => DBCONSTANTS::col_tbk_ss,       'val' => 'A',       'op' => DBCONSTANTS::op_eq)
            );
            
            $search_columns = array();
            UTILS::addSearchColumns2($searchField_details, $search_columns);
            //print_r($search_columns);die;
            
            $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tbk;
            $bindings = array();
            $where = DBUTILS::filter2( $search_columns,$bindings);
            //print_r($where);die;
            $query ="SELECT * FROM $table $where ";
            //print_r($query);die;
            
            $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
            //print_r($data);die;
            if(sizeof($data) > 0){
                $response_array['error'] = false;
                //$response_array['msg']  = $data[0];
                foreach($data as $row){
                    $epub = htmlspecialchars_decode($row['fdname'], ENT_QUOTES);
                    if($epub){
                        if(strlen($epub) > 0){
                            //echo $epubTgPat.$epub;die;
                            if(file_exists($epubTgPat.$epub)){
                                $row['fdname'] = $base_url.'reader/i/?book='.$epub;
                            }else{
                                $row['fdname'] = "";
                            } 
                        }else{
                            $row['fdname'] = "";
                        }
                    }else{
                        $row['fdname'] = "";
                    }
                    $epub = htmlspecialchars_decode($row['fname'], ENT_QUOTES);
                    if($epub){
                        if(strlen($epub) > 0){
                            if(file_exists($epubDwTgPat.$epub)){
        						$row['epubdownload'] = $base_url.'tnscert-ebook/download/'.$epub;
                            }else{
        						//$row['epubdownload'] = "";
								$row['epubdownload'] = $base_url.'tnscert-ebook/download/'.$epub;
                            }
                        }else{
                            $row['epubdownload'] = "";
                        }
                    }else{
                        $row['epubdownload'] = "";
                    }
                    
                    
                    
                    $bookCover = $row['bcfname'];
                    if($bookCover){
                        if(strlen($bookCover) > 0){
                            //echo $bcTgPat.$bookCover;die;
                            if(file_exists($bcTgPat.$bookCover)){
                                $row['bcfname']  = $base_url.'uploads/cover/'.$bookCover;
                            }else{
                                $row['bcfname'] = $base_url."img/book.png";
                            }
                        }else{
                            $row['bcfname'] = $base_url."img/book.png";
                        }
                    }else{
                        $row['bcfname'] = $base_url."img/book.png";
                    }
                    $pdf = htmlspecialchars_decode($row['pdffname'], ENT_QUOTES);
                    if($pdf){
                        if(strlen($pdf) > 0){
        					if(strlen($pdf) > 0){
								if(file_exists($pdfTgPat.$pdf)){
									$row['pdffname']  = $base_url.'tnscert-ebook/pdf-files/'.$pdf;
								}else{
									//$row['pdffname']  = "";
									$row['pdffname']  = $base_url.'tnscert-ebook/pdf-files/'.$pdf;
								}
							}else{
								$row['pdffname']  = "";
							}
                        }else{
                            $row['pdffname'] = "";
                        }
                    }else{
                        $row['pdffname'] = "";
                    }
                    $row['txtSubNm'] = $txtSubNm;
                    $output[] = $row;
                }
                $response_array['msg'] = $output;
            }else{
                $response_array['error'] = false;
                $ui_columns = array();
                $ui_columns = array(
                    'hidTBkId'   => DBCONSTANTS::col_tbk_id,
                    'taDesp'    => DBCONSTANTS::col_tbk_desp,
                    'fdname'    => DBCONSTANTS::col_tbk_fdnm,
                    'oname'     => DBCONSTANTS::col_tbk_fonm,
                    'fname'     => DBCONSTANTS::col_tbk_fsnm,
                    'ext'       => DBCONSTANTS::col_tbk_ftp,
                    'size'      => DBCONSTANTS::col_tbk_fsz,
                    'bcfname'   => DBCONSTANTS::col_tbk_bkcv,
                    'pdffname'  => DBCONSTANTS::col_tbk_pdf
                );
                //print_r($ui_columns); die;
                
                $searchField_details = array();
                $searchField_details = array(
                    'lang'  => array('db' => DBCONSTANTS::col_tbk_langgid,  'val' => $lang,     'op' => DBCONSTANTS::op_eq),
                    'cls'   => array('db' => DBCONSTANTS::col_tbk_clsid,    'val' => $cls,      'op' => DBCONSTANTS::op_eq),
                    'sub'   => array('db' => DBCONSTANTS::col_tbk_subid,    'val' => $sub,      'op' => DBCONSTANTS::op_eq),
                    'ss'    => array('db' => DBCONSTANTS::col_tbk_ss,       'val' => 'A',       'op' => DBCONSTANTS::op_eq)
                );
                
                $search_columns = array();
                UTILS::addSearchColumns2($searchField_details, $search_columns);
                //print_r($search_columns);die;
                
                $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tbk;
                $bindings = array();
                $where = DBUTILS::filter2( $search_columns,$bindings);
                //print_r($where);die;
                $query ="SELECT * FROM $table $where LIMIT 0,1";
                //print_r($query);die;
                
                $response_array['error'] = false;
                $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
                if(sizeof($data) > 0){
                    $response_array['error'] = false;
                    //$response_array['msg']  = $data[0];
                    foreach($data as $row){
                        $epub = $row['fdname'];
                        if($epub){
                            if(strlen($epub) > 0){
                                //echo $epubTgPat.$epub;die;
                                if(file_exists($epubTgPat.$epub)){
                                    $row['fdname'] = $base_url.'reader/i/?book='.$epub;
                                }else{
                                    $row['fdname'] = "";
                                } 
                                
                                
                            }else{
                                $row['fdname'] = "";
                            }
                        }else{
                            $row['fdname'] = "";
                        }
                        $epub = $row['fname'];
                        if($epub){
                            if(strlen($epub) > 0){
                                //echo $epubTgPat.$epub;die;
                                if(file_exists($epubDwTgPat.$epub)){
            						$row['epubdownload'] = $base_url.'reader/download/'.$epub;
                                }else{
            						$row['epubdownload'] = "";
                                }
                                
                                
                            }else{
                                $row['epubdownload'] = "";
                            }
                        }else{
                            $row['epubdownload'] = "";
                        }
                        
                        
                        
                        $bookCover = $row['bcfname'];
                        if($bookCover){
                            if(strlen($bookCover) > 0){
                                //echo $bcTgPat.$bookCover;die;
                                if(file_exists($bcTgPat.$bookCover)){
                                    $row['bcfname']  = $base_url.'uploads/cover/'.$bookCover;
                                }else{
                                    $row['bcfname'] = "";
                                }
                            }else{
                                $row['bcfname'] = "";
                            }
                        }else{
                            $row['bcfname'] = "";
                        }
                        $pdf = htmlspecialchars_decode($row['pdffname'], ENT_QUOTES);
						if($pdf){
							if(strlen($pdf) > 0){
								if(strlen($pdf) > 0){
									if(file_exists($pdfTgPat.$pdf)){
										$row['pdffname']  = $base_url.'tnscert-ebook/pdf-files/'.$pdf;
									}else{
										//$row['pdffname']  = "";
										$row['pdffname']  = $base_url.'tnscert-ebook/pdf-files/'.$pdf;
									}
								}else{
									$row['pdffname']  = "";
								}
							}else{
								$row['pdffname'] = "";
							}
						}else{
							$row['pdffname'] = "";
						}
                        $row['txtSubNm'] = $txtSubNm;
                        $output[] = $row;
                    }
                    $response_array['msg'] = $output;
                }
            }
        }
    }else{
        
        $response_array['error']  = true;
        
    }
    $statusCode = 200;
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();
    $statusCode = 405;
}
if(!isset($req)){
    echo json_encode($response_array);
    exit();
}else{
    
}
