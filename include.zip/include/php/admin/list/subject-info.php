<?php
//print_r($_POST);die;
try{
    header('Content-type: application/json');
    
    $sub_id = "";
    if(!isset($req)){
        require_once "../../../classes/utils.class.php";
        if(isset($_GET['sub_id'])){
            $sub_id = $_GET['sub_id'];
        }
    }else{
        $sub_id = $cls_id;
    }
    $base_url = CONFIG::base_url;
    
    $ui_columns = array();
    $ui_columns = array(
        'hidSub'    => DBCONSTANTS::col_sub_id,
        'txtTitle'  => DBCONSTANTS::col_sub_name,
        'cifname'   => DBCONSTANTS::col_sub_cimg
    );
    //print_r($ui_columns); die;
    
    $searchField_details = array();
    $searchField_details = array(
        'ss'    => array('db' => DBCONSTANTS::col_sub_ss, 'val' => 'A', 'op' => DBCONSTANTS::op_eq),
        'id'    => array('db' => DBCONSTANTS::col_sub_id, 'val' => $sub_id, 'op' => DBCONSTANTS::op_field_set)
    );
    
    $search_columns = array();
    UTILS::addSearchColumns4($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_sub;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    $query ="SELECT * FROM $table $where ";
    //print_r($query);die;
    
    $response_array['error'] = false;
    $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
    //print_r($data);die;
    if(sizeof($data) > 0){
        $response_array['error']  = false;
        $response_array['msg']  = $data[0];
        $bookCover = $data[0]['cifname'];
        if($bookCover){
            if(strlen($bookCover) > 0){
                $ciTgPat = '../../../../uploads/cover/';
                //echo $ciTgPat.$bookCover;die;
                if(file_exists($ciTgPat.$bookCover)){
                    $response_array['msg']['cifnamepath']  = $base_url.'uploads/cover/'.$bookCover;
                }else{
                    $response_array['msg']['cifnamepath'] = $base_url."img/book.png";
                }
            }else{
                 $response_array['msg']['cifnamepath'] = $base_url."img/book.png";
            }
        }else{
             $response_array['msg']['cifnamepath'] = $base_url."img/book.png";
        }
    }else{
        $response_array['error']  = true;
    }
    $statusCode = 200;
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();
    $statusCode = 405;
}
if(!isset($req)){
    echo json_encode($response_array);
    exit();
}else{
    
}