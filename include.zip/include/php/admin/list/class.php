<?php
//print_r($_POST);die;
try{
    header('Content-type: application/json');
    if(!isset($req)){
        require_once "../../../classes/utils.class.php";    
    }
    
    $ui_columns = array();
    $ui_columns = array(
        'hidClass'   => DBCONSTANTS::col_cls_id,
        'txtTitle'  => DBCONSTANTS::col_cls_name,
    );
    //print_r($ui_columns); die;
    
    $searchField_details = array();
    $searchField_details = array(
        'ss'    => array('db' => DBCONSTANTS::col_cls_ss, 'val' => 'A')
    );
    
    $search_columns = array();
    UTILS::addSearchColumns2($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_cls;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    $query ="SELECT * FROM $table $where ";
    //print_r($query);die;
    
    $response_array['error'] = false;
    $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
    //print_r($data);die;
    if(sizeof($data) > 0){
        $response_array['error']  = false;
        $response_array['msg']  = $data;
    }else{
        $response_array['error']  = true;
    }
    $statusCode = 200;
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();
    $statusCode = 405;
}
if(!isset($req)){
    echo json_encode($response_array);
    exit();
}else{
    
}