<?php
//print_r($_POST);die;
try{
    header('Content-type: application/json');
    $selval = "";
    $langid = "";
    if(!isset($req)){
        require_once "../../../classes/utils.class.php";
        if(isset($_GET['selval'])){
            $selval = $_GET['selval'];
        }
        if(isset($_GET['lang'])){
            $langid = $_GET['lang'];
        }
    }else{
        $selval = $cls_id;
    }
    
    
    $ui_columns = array();
    $ui_columns = array(
        'hidSub'   => DBCONSTANTS::col_sub_id,
        'txtTitle'  => DBCONSTANTS::col_sub_name,
    );
    //print_r($ui_columns); die;
    
    $searchField_details = array();
    $searchField_details = array(
        'ss'    => array('db' => DBCONSTANTS::col_sub_ss, 'val' => 'A', 'op' => DBCONSTANTS::op_eq),
        'clsid' => array('db' => DBCONSTANTS::col_sub_clsid, 'val' => $selval, 'op' => DBCONSTANTS::op_field_set),
        'langid' => array('db' => DBCONSTANTS::col_sub_langid, 'val' => $langid, 'op' => DBCONSTANTS::op_eq)
    );
    
    $search_columns = array();
    UTILS::addSearchColumns4($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_sub;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    $query ="SELECT * FROM $table $where ORDER BY ".DBCONSTANTS::col_sub_name;
    //print_r($query);die;
    
    $response_array['error'] = false;
    $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
    //print_r($data);die;
    if(sizeof($data) > 0){
        $response_array['error']  = false;
        $response_array['msg']  = $data;
    }else{
        $response_array['error']  = true;
    }
    $statusCode = 200;
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();
    $statusCode = 405;
}
if(!isset($req)){
    echo json_encode($response_array);
    exit();
}else{
    
}