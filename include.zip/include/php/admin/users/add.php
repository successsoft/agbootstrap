<?php
//print_r($_POST);die;
try{
    require_once "../../../classes/utils.class.php";
    require_once "../../../classes/users.class.php";
    
    header('Content-type: application/json');
    
    $response_array['error'] = false;
    $formFieldDetails  = array();
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_us;
    $formFieldDetails = QUSFORMUTILS::getFormFields();
    
    $response_array = QUSFORMUTILS::saveForm( $table, $formFieldDetails);
    
   
}catch(Exception $e){
    $statusCode = 405;
    $response_array['error'] = true;
    $response_array['data']['msg']  = $e->getMessage();
}
echo json_encode($response_array);
exit();