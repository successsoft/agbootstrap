<?php
try{
    require_once "../../../classes/utils.class.php";
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_us;
    $columns = array(
        array('db' => DBCONSTANTS::col_us_id,    'dt' => 'sno', 'tb' => $table),
        array('db' => "CONCAT(".DBCONSTANTS::col_us_fname.",' ',".DBCONSTANTS::col_us_lname.")", 'dt' => 'uname', 'as' => 'uname'),
        array('db' => DBCONSTANTS::col_us_mobile,'dt' => 'mbno'),
        array('db' => DBCONSTANTS::col_us_rid,   'dt' => 'rfinfo',
            'formatter' => function( $d, $row ) {
                $ui_columns =  array();
                $ui_columns = array(
                    'affname'   => array('db' =>  "CONCAT(".DBCONSTANTS::col_us_fname.",' ',".DBCONSTANTS::col_us_lname.")"),
                    'mbno'      => array('db' =>  DBCONSTANTS::col_us_mobile),
                );
                $searchField_details = array();
                $searchField_details = array(
                    'txtBkid' => array('db' => DBCONSTANTS::col_us_id, 'op' => DBCONSTANTS::op_eq, 'val' => $row[DBCONSTANTS::col_us_urid]),
                );
                
                $search_columns = array();
                UTILS::addSearchColumns4($searchField_details, $search_columns);
                //print_r($search_columns);die;
                
                $bindings = array();
                $where = DBUTILS::filter2( $search_columns,$bindings);
                
                //print_r($where);die;
                $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_us;
                 //print_r($where);die;
                $implode_column = array();
                UTILS::implodeColumn($ui_columns, $implode_column);
                
                $query ="SELECT ".implode(", ",$implode_column)." FROM $table $where";
            	//print_r($query);die;
                
                $data = DBUTILS::execute_column_query_array( $ui_columns, $bindings, $query);
                //print_r($data);die;
                if(sizeof($data) > 0){
                    return $data[0]['affname'].", ".$data[0]['mbno'];    
                }else{
                    return $d;
                }
           }
        ),
        array('db' => DBCONSTANTS::col_us_arid,   'dt' => 'advaff',
            'formatter' => function( $d, $row ) {
                $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_atree;
                $jTable1  = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_us;
                                
                $ui_columns =  array();
                $ui_columns = array(
                    'affname'   => array('db' =>  "CONCAT(".DBCONSTANTS::col_us_fname.",' ',".DBCONSTANTS::col_us_lname.")"),
                    'mbno'      => array('db' =>  DBCONSTANTS::col_us_mobile),
                    'postion'   => array('db' =>  "CASE WHEN ".DBCONSTANTS::col_atree_pos." = 0 THEN 'Left' ELSE 'Right' END"),
                    
                );
                $searchField_details = array();
                $searchField_details = array(
                    'node' => array('db' => DBCONSTANTS::col_atree_uid, 'op' => DBCONSTANTS::op_eq, 'val' => $d),
                );
                
                $search_columns = array();
                UTILS::addSearchColumns4($searchField_details, $search_columns);
                //print_r($search_columns);die;
                
                $bindings = array();
                $where = DBUTILS::filter2( $search_columns,$bindings);
                
                //print_r($where);die;
                
                 //print_r($where);die;
                $implode_column = array();
                UTILS::implodeColumn($ui_columns, $implode_column);
                
                $joinTable = "LEFT JOIN $jTable1 ON $table.".DBCONSTANTS::col_atree_pid." = $jTable1.".DBCONSTANTS::col_us_arid;
                
                $query = "SELECT ".implode(", ",$implode_column)." FROM $table $joinTable $where";
            	//print_r($query);die;
                
                $data = DBUTILS::execute_column_query_array( $ui_columns, $bindings, $query);
                //print_r($data);die;
                if(sizeof($data) > 0){
                    return $data[0]['affname'].", ".$data[0]['mbno']." - ".$data[0]['postion'];    
                }else{
                    return $d;
                }
           }
        ),
        array('db' => DBCONSTANTS::col_us_ppts,  'dt' => 'pvpts'),
        array('db' => DBCONSTANTS::col_us_dt,    'dt' => 'dt',
            'formatter' => function( $d, $row ) {
                return date("d-M-Y",strtotime($d));
           }
        ),
        array('db' => DBCONSTANTS::col_us_id,    'dt' => 'action', 'tb' => $table),
        array('db' => DBCONSTANTS::col_us_ss,    'dt' => 'ss', 'tb' => $table),
        array('db' => DBCONSTANTS::col_us_urid,  'dt' => 'rfid'),
    ); 
    
     //print_r($columns);die;
    $primaryKey = $table.'.'.DBCONSTANTS::col_us_id;
    $data = DBUTILS::simple($_POST, $table, $primaryKey, $columns );
    
    //print_r($data);die;
    echo json_encode( $data );
        
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();    
    echo json_encode($response_array);
    exit();
}

?>  