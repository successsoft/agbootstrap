<?php
//print_r($_POST);die;
try{
    header('Content-type: application/json');
    require_once "../../../classes/utils.class.php";
    require_once "../../../classes/users.class.php";
    
    $searchField_details = array();
    $searchField_details = array(
        'editId'      => DBCONSTANTS::col_us_id,
    );
    
    $ui_columns =  array();
    $ui_columns = USERSUTILS::getFormFields();
    //print_r($ui_columns); die;
     
    $search_columns = array();
    UTILS::PostData($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_us;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    $query ="SELECT * FROM $table $where ";
    //print_r($query);die;
    
    $response_array['error'] = false;
    $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
    //print_r($data);die;
    if(sizeof($data) > 0){
        $response_array['error']  = false;
        $response_array['msg']  = $data[0];
        if($data[0]['txtDOB'] != '0000-00-00' && $data[0]['txtDOB'] != '1970-01-01'){
            $response_array['msg']['txtDOB']  = date("d-M-Y",strtotime($data[0]['txtDOB']));    
        }else{
            $response_array['msg']['txtDOB']  = "";
        }
        
        if($data[0]['regjoinDat'] != '0000-00-00' && $data[0]['regjoinDat'] != '1970-01-01'){
            $response_array['msg']['regjoinDat']  = date("d-M-Y",strtotime($data[0]['regjoinDat']));    
        }else{
            $response_array['msg']['regjoinDat']  = "";
        }
    }else{
        $response_array['error']  = true;
    }
    echo json_encode($response_array);
    exit();
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = "Invalid data";    
    echo json_encode($response_array);
    exit();
}

  
?>