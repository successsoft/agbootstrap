<?php
try{
    require_once "../../../classes/utils.class.php";
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_sub;
    $jTable1 = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_cls;
    $jTable2 = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_lang;
    
    $columns = array();
    $columns = array(
        array('db' => DBCONSTANTS::col_sub_id,     'dt' => 'sno', 'tb' => $table),
        array('db' => DBCONSTANTS::col_sub_name,   'dt' => 'tit'),
        array('db' => DBCONSTANTS::col_lang_name,   'dt' => 'lang'),
        array('db' => "GROUP_CONCAT( $jTable1.".DBCONSTANTS::col_cls_name." )", 'dt' => 'cls', 'as' => 'cls' ),
        array('db' => DBCONSTANTS::col_sub_cimg,    'dt' => 'img',
            'formatter' => function( $d, $row ) {
                $base_url = CONFIG::base_url; 
                $image = '<img style="width:140px;" src="dist/img/book.png" />';
                if($d){
                    if($_SERVER['HTTP_HOST'] == "192.168.1.33:8080" || $_SERVER['HTTP_HOST'] == "192.168.1.34" || $_SERVER['HTTP_HOST'] == "192.168.1.45"){
                        $targetPath = $_SERVER['DOCUMENT_ROOT'].'/textbook/uploads/cover';
                    }else if($_SERVER['HTTP_HOST'] == "demo.klabstechindia.com"){
                        $targetPath = $_SERVER['DOCUMENT_ROOT'].'/textbook/uploads/cover';
                    }else if($_SERVER['HTTP_HOST'] == "104.198.73.189"){
                        $targetPath = '../../../../uploads/cover';
                    }
                    //echo $targetPath.'/'.$d;die;
                    if(file_exists($targetPath.'/'.$d)){
    					$image = '<img style="width:140px;" src="'.$base_url.'uploads/cover/'.$d.'" />';
                    }
                }
                return $image;
            }
        ),
        array('db' => DBCONSTANTS::col_sub_id,     'dt' => 'action', 'tb' => $table),
        array('db' => DBCONSTANTS::col_sub_ss,     'dt' => 'ss', 'tb' => $table),
    ); 
    
     //print_r($columns);die;
    $primaryKey = $table.'.'.DBCONSTANTS::col_sub_id;
    $joinTable = "LEFT JOIN $jTable1 ON FIND_IN_SET(  $jTable1.".DBCONSTANTS::col_cls_id." ,  $table.".DBCONSTANTS::col_sub_clsid.")
                  LEFT JOIN $jTable2 ON $table.".DBCONSTANTS::col_sub_langid." = $jTable2.".DBCONSTANTS::col_lang_id;
    
    $group_by = "GROUP BY $table.".DBCONSTANTS::col_sub_id;
    $where[] = "$table.".DBCONSTANTS::col_sub_ss." <> 'D'";
    if($_POST['selclass']){
        $where[] = " FIND_IN_SET( '".$_POST['selclass']."', $table.".DBCONSTANTS::col_sub_clsid." ) ";
    }
    $data = DBUTILS::complexJoin($_POST, $table, $joinTable, $primaryKey, $columns, $where, '', $group_by );
    
    //print_r($data);die;
    echo json_encode( $data );
        
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();    
    echo json_encode($response_array);
    exit();
}

?>  