<?php
//print_r($_POST);die;
try{
    require_once "../../../classes/utils.class.php";
    require_once "../../../classes/subject.class.php";
    
    header('Content-type: application/json');
    
    $response_array['error'] = false;
    $formFieldDetails  = array();
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_sub;
    $formFieldDetails = SUBUTILS::getFormFields();
    
    $response_array = SUBUTILS::saveForm( $table, $formFieldDetails);
    
    if(isset($_POST['removeUpFiles'])){
        if(strlen($_POST['removeUpFiles'])){
            $removeUpFiles = explode(",",$_POST['removeUpFiles']);
            $arraycheck = is_array($removeUpFiles) ? 'yes' : 'no';
            if($arraycheck == 'yes'){
                foreach($removeUpFiles as $row){
                    UTILS::default_timezone();
                    $date = date('Y-m-d H:i:s');
                    $updateField_details = array();
                    
                    if($row == 'image'){
                        $updateField_details = array(
                            'txtOpt'    => array('db' =>DBCONSTANTS::col_sub_cimg,   'op' => DBCONSTANTS::op_eq, 'val' =>''),
                            'txtMDate'  => array('db' =>DBCONSTANTS::col_sub_mdate,  'op' => DBCONSTANTS::op_eq, 'val' => $date)
                        );
                    }else{
                        $updateField_details = array(
                            'txtMDate'  => array('db' =>DBCONSTANTS::col_sub_mdate,  'op' => DBCONSTANTS::op_eq, 'val' => $date)
                        );
                    }
                    
                    
                    UTILS::updateColumnsCustom($updateField_details, $update_columns);
                    //print_r($update_columns);die;
                    $update_row = array();
                    $update_row = array(
                        'hidSub'  => array('db' =>DBCONSTANTS::col_sub_id, 'op' => DBCONSTANTS::op_eq, 'val' => $_POST['hidSub'])
                    );
                    //print_r($update_row);die;
                    $update_col = array();
                    UTILS::updateColumnsWhere2($update_row, $update_col);
                    //print_r($update_col);die;
                    if(sizeof($update_col) > 0){
                        $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_sub;
                        DBUTILS::exec_updatesql( $table, $update_columns, $update_col);
                    }
                }
            }
        }
    }
}catch(Exception $e){
    $statusCode = 405;
    $response_array['error'] = true;
    $response_array['data']['msg']  = $e->getMessage();
}
echo json_encode($response_array);
exit();