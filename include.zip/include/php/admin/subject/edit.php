<?php
//print_r($_POST);die;
try{
    header('Content-type: application/json');
    require_once "../../../classes/utils.class.php";
    require_once "../../../classes/subject.class.php";
    $base_url = CONFIG::base_url;
    $searchField_details = array();
    $searchField_details = array(
        'editId'      => DBCONSTANTS::col_sub_id,
    );
    
    $ui_columns =  array();
    $ui_columns = SUBUTILS::getFormFields();
    //print_r($ui_columns); die;
     
    $search_columns = array();
    UTILS::PostData($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_sub;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    $query ="SELECT * FROM $table $where ";
    //print_r($query);die;
    
    $response_array['error'] = false;
    $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
    //print_r($data);die;
    if(sizeof($data) > 0){
        $response_array['error']  = false;
        $response_array['msg']  = $data[0];
        $bookCover = $data[0]['cifname'];
        if($bookCover){
            if(strlen($bookCover) > 0){
                $ciTgPat = '../../../../uploads/cover/';
                //echo $ciTgPat.$bookCover;die;
                if(file_exists($ciTgPat.$bookCover)){
                    $response_array['msg']['cifnamepath']  = $base_url.'uploads/cover/'.$bookCover;
                }else{
                    $response_array['msg']['cifname'] = "";
                }
            }else{
                 $response_array['msg']['cifname'] = "";
            }
        }else{
             $response_array['msg']['cifname'] = "";
        }
    }else{
        $response_array['error']  = true;
    }
    echo json_encode($response_array);
    exit();
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = "Invalid data";    
    echo json_encode($response_array);
    exit();
}

  
?>