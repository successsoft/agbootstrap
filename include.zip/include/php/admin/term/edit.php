<?php
//print_r($_POST);die;
try{
    header('Content-type: application/json');
    require_once "../../../classes/utils.class.php";
    require_once "../../../classes/term.class.php";
    
    $searchField_details = array();
    $searchField_details = array(
        'editId'      => DBCONSTANTS::col_tm_id,
    );
    
    $ui_columns =  array();
    $ui_columns = TERMUTILS::getFormFields();
    //print_r($ui_columns); die;
     
    $search_columns = array();
    UTILS::PostData($searchField_details, $search_columns);
    //print_r($search_columns);die;
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tm;
    $bindings = array();
    $where = DBUTILS::filter2( $search_columns,$bindings);
    //print_r($where);die;
    $query ="SELECT * FROM $table $where ";
    //print_r($query);die;
    
    $response_array['error'] = false;
    $data = DBUTILS::execute_column_query( $ui_columns, $bindings, $query);
    //print_r($data);die;
    if(sizeof($data) > 0){
        $response_array['error']  = false;
        $response_array['msg']  = $data[0];
        
    }else{
        $response_array['error']  = true;
    }
    echo json_encode($response_array);
    exit();
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = "Invalid data";    
    echo json_encode($response_array);
    exit();
}

  
?>