<?php
try{
    require_once "../../../classes/utils.class.php";
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_tm;
    $columns = array();
    $columns = array(
        array('db' => DBCONSTANTS::col_tm_id,     'dt' => 'sno', 'tb' => $table),
        array('db' => DBCONSTANTS::col_tm_name,   'dt' => 'tit'),
        array('db' => DBCONSTANTS::col_tm_id,     'dt' => 'action', 'tb' => $table),
        array('db' => DBCONSTANTS::col_tm_ss,     'dt' => 'ss', 'tb' => $table),
    ); 
    
     //print_r($columns);die;
    $primaryKey = $table.'.'.DBCONSTANTS::col_tm_id;
    $data = DBUTILS::simple($_POST, $table, $primaryKey, $columns );
    
    //print_r($data);die;
    echo json_encode( $data );
        
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();    
    echo json_encode($response_array);
    exit();
}

?>  