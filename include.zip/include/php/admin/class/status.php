<?php

try{
    require_once "../../../classes/utils.class.php";
    header('Content-type: application/json');
    
    $row_id= trim($_POST['row_id']);
    //print_r($_POST);die;
    $status= $_POST['status'];
    if($status == 'A'){
        $status = 'I';
    }else{
        $status = 'A';
    }
    $update_columns = array();
    UTILS::default_timezone();
    $date = date('Y-m-d H:i:s');
    $updateField_details = array();
    $updateField_details = array(
        'status' => array('db' => DBCONSTANTS::col_cls_ss,   'val' => $status, 'op' => DBCONSTANTS::op_eq),
        'mdate' => array('db'  => DBCONSTANTS::col_cls_mdate,'val' => date('Y-m-d H:i:s'),'op' => DBCONSTANTS::op_eq)
    );
    UTILS::updateColumnsCustom($updateField_details, $update_columns);
    //print_r($update_columns);die;
    $update_row = array(
        'row_id'      => DBCONSTANTS::col_cls_id,
    );
    //print_r($update_row);die;
    $update_col = array();
    UTILS::addSearchColumns($update_row, $update_col);
    //print_r($update_col);die;
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_cls;
    if(sizeof($update_col) > 0){
        DBUTILS::exec_updatesql( $table, $update_columns, $update_col);
    }
    
    $response_array['error'] = false;
    $response_array['msg']  = "Status Updated successfully";
    
    echo json_encode($response_array);
    exit();
}catch(Exception $e){
    $response_array['error'] = true;
    //print_r($e->getMessage());
      $response_array['msg']  = $e->getMessage();    
   echo json_encode($response_array);
   exit();
}
  
?>