<?php
try{
    require_once "../../../classes/utils.class.php";
    
    $table = DBCONSTANTS::tbl_prefiex.DBCONSTANTS::tbl_cls;
    $columns = array();
    $columns = array(
        array('db' => DBCONSTANTS::col_cls_id,     'dt' => 'sno', 'tb' => $table),
        array('db' => DBCONSTANTS::col_cls_name,   'dt' => 'tit'),
        array('db' => DBCONSTANTS::col_cls_id,     'dt' => 'action', 'tb' => $table),
        array('db' => DBCONSTANTS::col_cls_ss,     'dt' => 'ss', 'tb' => $table),
    ); 
    
     //print_r($columns);die;
    $primaryKey = $table.'.'.DBCONSTANTS::col_cls_id;
    $where[] = $table.'.'.DBCONSTANTS::col_tbk_ss." <> 'D'";
    $data = DBUTILS::complexJoin($_POST, $table, "", $primaryKey, $columns, $where );
    
    //print_r($data);die;
    echo json_encode( $data );
        
}catch(Exception $e){
    $response_array['error'] = true;
    $response_array['msg']  = $e->getMessage();    
    echo json_encode($response_array);
    exit();
}

?>  