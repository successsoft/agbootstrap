<?php

$image=$_GET['i'];
$width=$_GET['w'];
$stamp = imagecreatefrompng('./assets/images/logo.png');

function imagecreatefromfile($image_path) {
  // retrieve the type of the provided image file
  list($width, $height, $image_type) = getimagesize($image_path);
  
  switch ($image_type)
  {
    case IMAGETYPE_GIF:
	$image = imagecreatefromgif($image_path);
	break;
    case IMAGETYPE_JPEG: $image=imagecreatefromjpeg($image_path); break;
    case IMAGETYPE_PNG: $image=imagecreatefrompng($image_path); break;
    default: $image='';
  }
  
  return array('i'=>$image,'w'=>$width,'h'=>$height);
}
$im = imagecreatefromfile("uploads/user/".$image);


if($im['i']!=''){
	
	$stamp_x =  imagesx($im['i']) - imagesx($stamp) - 10;
	$stamp_y = imagesy($im['i']) - imagesy($stamp) - 10;
	
	$imageWidth = imagesx($im['i']);
	$desired_height = floor($height * ($width / $imageWidth));
	//imagecopy($im['i'], $stamp,  $stamp_x, $stamp_y, 0, 0, imagesx($stamp), imagesy($stamp));
	
	header('Content-type: image/jpeg');
	imagejpeg($im['i'],NULL,100);
	imagedestroy($im['i']);
	imagedestroy($stamp);/**/
}

/*
$watermark_pos_x = imagesx($image) - imagesx($watermark) - 8;
$watermark_pos_y = imagesy($image) - imagesy($watermark) - 10;

imagecopy($image, $watermark,  $watermark_pos_x, $watermark_pos_y, 0, 0,
imagesx($watermark), imagesy($watermark));

header('Content-Type: image/jpeg');
imagejpeg($image, NULL, 100);

imagedestroy($image);
imagedestroy($watermark);*/