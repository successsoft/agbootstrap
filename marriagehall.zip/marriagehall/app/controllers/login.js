app.controller('loginCtrl',function($scope,$rootScope,$http,$cookies,$location){
    $scope.d={loginAs:'user'};
    $scope.login = function(d){
        d.action='login';
        $http.post('api/post',d).then(function(r){
            if(r.data.m===true){
                alert('You are successfully Login');
                $cookies.putObject('userInfo',r.data.user);
                $rootScope.isUserLoged=r.data.user;
                $rootScope.appUser=r.data.dbData;

                switch(d.loginAs){
                    case "user": $location.path("/profile"); break;
                    case "agent": $location.path("/agent"); break;
                    default:  $location.path("/advertiser");
                }
                if(d.loginAs==''){  }
                else if(d.loginAs=='agent'){ $location.path("/agent"); }


            }else{
                alert(r.data.m);
            }
        });
    };
});