app.controller('signUpCtrl',function($scope,$rootScope,$http,$interval,$cookies,$window,$location,WizardHandler,options){
$scope.finishedWizard = function(arg){
		arg.action='userSignUp';
        $http.post('api/post',arg).then(function(r){
            if(r.data.m==true){
                $scope.sign=$rootScope.signup;
                $cookies.remove("signUpFormStat");
                alert('You are successfully signed');
                $location.path(r.data.redirect);
            }else{ alert(r.data.m); console.log(r.data.m); }
        });
	};
	
	$scope.sign = $cookies.getObject('signUpFormStat') || $rootScope.signup;
    $interval(function(){
        var isCookieDefined = angular.isDefined( $cookies.getObject('signUpFormStat') );
        if( (isCookieDefined && !angular.equals($scope.sign,$cookies.getObject('signUpFormStat'))) || !isCookieDefined){
            $cookies.putObject('signUpFormStat',$scope.sign);
            console.log('stateSave');
        }
    },10000);/**/

    $scope.options = options;
    //--------------
    var height = ['Dont Know','Below 4 feet'];
    for(var i=4; i<=6; i++){height.push(i+' feet');for(var j=1; j<=11; j++){height.push(i+' feet '+j+' inches');}}
    height.push('7 feet','Above 7 feet');
    $scope.height_array=height;
    //--------------
    var weight = []; for(var w=41; w<=140; w++){ weight.push(w); }
    $scope.weight_array=weight;
    //--------------
    $scope.loadCaste = function(c,d){
        var religion_id = $(c+' option:selected').data('id');
        var castes = $rootScope.castes;
        var opts = $(d).children('optgroup');
        opts.html('');
        castes.map(function(item){
            if(religion_id === item.parent){ opts.append('<option>'+item.label+'</option>'); }
        });
    };

    $scope.age_range=[];
    for(var a=18; a<=75; a++){$scope.age_range.push(a);}

    /*Looking For*/
    $scope.LFor = {'Unmarried':true, 'Widow/Widower':false, 'Divorced':false};
    $scope.toggleSelection = function(n,s) {
        $scope.LFor[n] = s?false:true;
        var i = $rootScope.sign.looking.indexOf(n);
        if(s){ $rootScope.sign.looking.splice(i,1); }else{ $rootScope.sign.looking.push(n); }
    };
})
.controller('SignUpCtrl',function($scope,$http,$cookies,$interval,$window){
    $scope.isInValid=true;
    //$scope.pageAction='';
    //$scope.d= $cookies.getObject('agentSignUp') || {};
    $scope.d={};
    $scope.$watch('signUpForm.$valid',function(n){$scope.isInValid=!n;});

    /*$interval(function(){
        var isCookieDefined = angular.isDefined( $cookies.getObject('agentSignUp') );
        if( (isCookieDefined && !angular.equals($scope.d,$cookies.getObject('agentSignUp'))) || !isCookieDefined){
            $cookies.putObject('agentSignUp',$scope.d);
            console.log('stateSave');
        }
    },10000);*/

    $scope.signUp=function(d){
        d.action=$scope.pageAction;
        $http.post('api/post',d).then(function(r){
            if(r.data.m==true){
                $scope.d={};
                alert('You are successfully reqistered');
                //$window.location.assign("#/login");
            }else{ alert(r.data.m); console.log(r.data.m); }
        });
    };
});