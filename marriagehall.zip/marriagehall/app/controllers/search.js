app.controller('searchCtrl',function($scope, $rootScope, $http, $cookies, $location, $uibModal, $timeout, $compile, fancyboxService, options){
    $("html, body").animate({ scrollTop: 0 }, "slow");
    
    $scope.searchData = false;
    $scope.nosearchData = false;
    
    
    var reachedLast = false;
	$scope.slData = [];
	$scope.loadmore = "Loading more data...";

	var NextpageNumber = 1;//next page is made it zeero on starting
    var limit = 3;
	$scope.listData = function(servicename = '') {
		if(reachedLast)
			return false;
        
        $scope.url = 'api/post';
        
        if(angular.isDefined($scope.servicename)){
            servicename = $scope.servicename
        }
		$http.post($scope.url, {action:'searchService',  service: servicename, page: NextpageNumber, limit: limit}).then(function(r, status) {
            console.log('working')
			$scope.status = status;
			$scope.data = data;
			var currentpage = NextpageNumber;//taking current pagenumber
			var lastpage = data.pagination.lastpage; //setting last page numbervar 
            var currpage = data.pagination.currpage;
			NextpageNumber = data.pagination.nextpage;

			if((currentpage == NextpageNumber) ){
				return false;
			}

			if((currentpage == lastpage)){
				//reached at the bottom
				reachedLast = true;
				$scope.loadmore = "Reached at bottom";
				//$scope.$apply();
			}
            if(data.error == false){
                if( currpage == 1){
                    $scope.slData = data.result; 
                }else{
                    $scope.slData = $scope.slData.concat(data.result);
                }
                
                
                $scope.nosearchData = false;
                $scope.searchData = true;
            }else{
                $scope.searchData = false;
                $scope.nosearchData = true;
            }
			
		}).error(function(data, status) {
			$scope.data = data || "Request failed";
			$scope.status = status;
		});
	};
	
    
    if(angular.isUndefined($rootScope.sresult)){
        $scope.listData();// loading initial content
    }
    
    $scope.searchService =function(d){
        d.action = 'searchService';
        d.NextpageNumber = 1;
        console.log(d)
        //$scope.listData( d );
    }
    
    if(angular.isDefined($rootScope.searchresult)){ 
        if($rootScope.searchresult == false){
            $scope.searchData = false;
            $scope.nosearchData = true;
        }else{
            $scope.nosearchData = false;
            $scope.searchData = true;
        }
    }
    
    $scope.clickService = function(servicename){
        NextpageNumber = 1;
        $scope.servicename = servicename;
        $scope.listData(servicename);
    }
    
    $scope.sendEnquiry = function(id){
        var modalInstance = $uibModal.open({
            templateUrl: 'app/tpls/sendenquiry.html',
            controller: 'sendEnquiryCtrl',
            size:'md',
            resolve:{items:function(){return id;}}
        });

        modalInstance.result.then(function(){

        },function(){});
    };
    
    $scope.postComments = function(id){
        var modalInstance = $uibModal.open({
            templateUrl: 'post-comments.html',
            controller: 'postCommentsCtrl',
            size: 'md',
            resolve:{items:function(){return id;}}
        });

        modalInstance.result.then(function(){

        },function(){});
    };
    
});

app.controller('sendEnquiryCtrl',function($scope, $rootScope, $http, $uibModalInstance, items) {
    $scope.isInValid=true;
    $scope.d={};
    $scope.$watch('sendEnquiryForm.$valid',function(n){$scope.isInValid=!n;});
    
    if(angular.isDefined($rootScope.searchArea)){
        var searchArea = $rootScope.searchArea
    }else{
        var searchArea = '';
    }
    if(angular.isDefined($rootScope.searchPin)){
        var searchPin = $rootScope.searchPin
    }else{
        var searchPin = '';
    }
    $scope.sendEnquiry=function(d){
        d.action = $scope.pageAction;
        d.ad_id = items;
        d.area = searchArea;
        d.pincode = searchPin; 
        d.eq_for = 'E';
        $http.post('api/post',d).then(function(r){
            $scope.d.eq_name = '';
            $scope.d.eq_email_id = '';
            $scope.d.eq_comment = '';
            if(r.data.m==true){
                $('#alert-msg').removeClass('alert-danger');
                $('#alert-msg').addClass('alert-success');
                
                $scope.strongMsg = "Success: ";
                $scope.spanMsg = "Your enquiry submitted successfully...";
                $scope.alertMsg = true
                 
            }else{
                $('#alert-msg').removeClass('alert-success');
                $('#alert-msg').addClass('alert-danger');
                
                $scope.strongMsg = "Error: ";
                $scope.spanMsg = "Enquiry submition failed. Please trt again or try after some time...";
                $scope.alertMsg = true
            }
        }); 
    };
    
    $scope.close = function () {
        $scope.alertMsg = false
    };
    
    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
    
});

app.controller('postCommentsCtrl',function($scope, $rootScope, $http, $uibModalInstance, items) {
    $scope.close = function () {
        $scope.alertMsg = false
    };
    
    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
    
    $scope.isInValid=true;
    $scope.d={};
    $scope.$watch('postCommentsForm.$valid',function(n){$scope.isInValid=!n;});
    
     $scope.postComments=function(d){
        d.action = $scope.pageAction;
        d.ad_id = items;
        d.eq_for = 'C';
        $http.post('api/post',d).then(function(r){
            $scope.d.eq_name = '';
            $scope.d.eq_email_id = '';
            $scope.d.eq_mobile_no = '';
            $scope.d.eq_comment = '';
            if(r.data.m==true){
                $('#alert-msg').removeClass('alert-danger');
                $('#alert-msg').addClass('alert-success');
                
                $scope.strongMsg = "Success: ";
                $scope.spanMsg = "Your enquiry submitted successfully...";
                $scope.alertMsg = true
                 
            }else{
                $('#alert-msg').removeClass('alert-success');
                $('#alert-msg').addClass('alert-danger');
                
                $scope.strongMsg = "Error: ";
                $scope.spanMsg = "Enquiry submition failed. Please trt again or try after some time...";
                $scope.alertMsg = true
            }
        }); 
    };
});
app.directive('onErrorSrc', function() {
  return {
    link: function(scope, element, attrs) {
      element.bind('error', function() {
        if (attrs.src != attrs.onErrorSrc) {
          attrs.$set('src', attrs.onErrorSrc);
        }
      });
    }
  }
});

app.directive('onlyDigits', function () {
    return {
      require: 'ngModel',
      restrict: 'A',
      link: function (scope, element, attr, ctrl) {
        function inputValue(val) {
          if (val) {
            var digits = val.replace(/[^0-9]/g, '');

            if (digits !== val) {
              ctrl.$setViewValue(digits);
              ctrl.$render();
            }
            return parseInt(digits,10);
          }
          return undefined;
        }            
        ctrl.$parsers.push(inputValue);
      }
    };
});
