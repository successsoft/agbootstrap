app.controller('searchCtrl',function($scope, $rootScope, $http, $cookies, $location, $uibModal, $timeout, $compile, fancyboxService, options){
    $("html, body").animate({ scrollTop: 0 }, "slow");
    var page = 1;
    var limit = 5;
    
    $scope.searchData = false;
    $scope.nosearchData = false;
    if(angular.isUndefined($rootScope.sresult)){
        $http.post('api/post',{action:'searchService', page: page, limit: limit }).then(function(r){
            var data = r.data;
            if(r.data.error == false){
                //console.log(data.result)
                $scope.sresult = data.result;
                $rootScope.sresult = data.result;
                $location.path('/search');
                $scope.nosearchData = false;
                $scope.searchData = true;
                
                $scope.ajaxpagination = data.pagination;
            }else{
                $scope.searchData = false;
                $scope.nosearchData = true;
            }
        });
        
        $scope.searchService =function(d){
            //console.log(d)
            d.action = 'searchService';
            d.page = page;
            d.limit = limit;
            $http.post('api/post',d).then(function(r){
                var data = r.data;
                if(r.data.error == false){
                    //console.log(data.result)
                    $scope.sresult = data.result;
                    $rootScope.sresult = data.result;
                    $location.path('/search');
                    $scope.nosearchData = false;
                    $scope.searchData = true;
                }else{
                    $scope.searchData = false;
                    $scope.nosearchData = true;
                }
            })
        }
    }else{
        $scope.searchService =function(d){
            //console.log(d)
            d.action = 'searchService';
            d.page = page;
            d.limit = limit;
            $http.post('api/post',d).then(function(r){
                var data = r.data;
                if(r.data.error == false){
                    //console.log(data.result)
                    $scope.sresult = data.result;
                    $rootScope.sresult = data.result;
                    $location.path('/search');
                    $scope.nosearchData = false;
                    $scope.searchData = true;
                }else{
                    $scope.searchData = false;
                    $scope.nosearchData = true;
                }
            })
        }
    }
    
    if(angular.isDefined($rootScope.searchresult)){ 
        if($rootScope.searchresult == false){
            $scope.searchData = false;
            $scope.nosearchData = true;
        }else{
            $scope.nosearchData = false;
            $scope.searchData = true;
        }
    }
    
    $scope.clickService = function(servicename){
        $http.post('api/post',{action:'searchService', service: servicename, page: page, limit: limit}).then(function(r){
            var data = r.data;
            if(data.error == false){
                //console.log(data.result)
                $scope.sresult = data.result;
                $rootScope.sresult = data.result;
                $location.path('/search');
                $scope.nosearchData = false;
                $scope.searchData = true;
            }else{
                $scope.searchData = false;
                $scope.nosearchData = true;
            }
        })
    }
    
    $scope.example_group={
        'titleShow'     : false,
        'transitionIn'	: 'none',
        'transitionOut'	: 'none',
    };
    
    $scope.sendEnquiry = function(id){
        var modalInstance = $uibModal.open({
            templateUrl: 'app/tpls/sendenquiry.html',
            controller: 'sendEnquiryCtrl',
            size:'md',
            resolve:{items:function(){return id;}}
        });

        modalInstance.result.then(function(){

        },function(){});
    };
    
    $scope.postComments = function(id){
        var modalInstance = $uibModal.open({
            templateUrl: 'post-comments.html',
            controller: 'postCommentsCtrl',
            size: 'md',
            resolve:{items:function(){return id;}}
        });

        modalInstance.result.then(function(){

        },function(){});
    };
    
    /** console.log( $scope.searchArea )
    console.log( $scope.searchPin ) */
    
    
});

app.controller('sendEnquiryCtrl',function($scope, $rootScope, $http, $uibModalInstance, items) {
    $scope.isInValid=true;
    $scope.d={};
    $scope.$watch('sendEnquiryForm.$valid',function(n){$scope.isInValid=!n;});
    
    if(angular.isDefined($rootScope.searchArea)){
        var searchArea = $rootScope.searchArea
    }else{
        var searchArea = '';
    }
    if(angular.isDefined($rootScope.searchPin)){
        var searchPin = $rootScope.searchPin
    }else{
        var searchPin = '';
    }
    $scope.sendEnquiry=function(d){
        d.action = $scope.pageAction;
        d.ad_id = items;
        d.area = searchArea;
        d.pincode = searchPin; 
        d.eq_for = 'E';
        $http.post('api/post',d).then(function(r){
            $scope.d.eq_name = '';
            $scope.d.eq_email_id = '';
            $scope.d.eq_comment = '';
            if(r.data.m==true){
                $('#alert-msg').removeClass('alert-danger');
                $('#alert-msg').addClass('alert-success');
                
                $scope.strongMsg = "Success: ";
                $scope.spanMsg = "Your enquiry submitted successfully...";
                $scope.alertMsg = true
                 
            }else{
                $('#alert-msg').removeClass('alert-success');
                $('#alert-msg').addClass('alert-danger');
                
                $scope.strongMsg = "Error: ";
                $scope.spanMsg = "Enquiry submition failed. Please trt again or try after some time...";
                $scope.alertMsg = true
            }
        }); 
    };
    
    $scope.close = function () {
        $scope.alertMsg = false
    };
    
    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
    
});

app.controller('postCommentsCtrl',function($scope, $rootScope, $http, $uibModalInstance, items) {
    $scope.close = function () {
        $scope.alertMsg = false
    };
    
    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
    
    $scope.isInValid=true;
    $scope.d={};
    $scope.$watch('postCommentsForm.$valid',function(n){$scope.isInValid=!n;});
    
     $scope.postComments=function(d){
        d.action = $scope.pageAction;
        d.ad_id = items;
        d.eq_for = 'C';
        $http.post('api/post',d).then(function(r){
            $scope.d.eq_name = '';
            $scope.d.eq_email_id = '';
            $scope.d.eq_mobile_no = '';
            $scope.d.eq_comment = '';
            if(r.data.m==true){
                $('#alert-msg').removeClass('alert-danger');
                $('#alert-msg').addClass('alert-success');
                
                $scope.strongMsg = "Success: ";
                $scope.spanMsg = "Your enquiry submitted successfully...";
                $scope.alertMsg = true
                 
            }else{
                $('#alert-msg').removeClass('alert-success');
                $('#alert-msg').addClass('alert-danger');
                
                $scope.strongMsg = "Error: ";
                $scope.spanMsg = "Enquiry submition failed. Please trt again or try after some time...";
                $scope.alertMsg = true
            }
        }); 
    };
});
app.directive('onErrorSrc', function() {
  return {
    link: function(scope, element, attrs) {
      element.bind('error', function() {
        if (attrs.src != attrs.onErrorSrc) {
          attrs.$set('src', attrs.onErrorSrc);
        }
      });
    }
  }
});

app.directive('onlyDigits', function () {
    return {
      require: 'ngModel',
      restrict: 'A',
      link: function (scope, element, attr, ctrl) {
        function inputValue(val) {
          if (val) {
            var digits = val.replace(/[^0-9]/g, '');

            if (digits !== val) {
              ctrl.$setViewValue(digits);
              ctrl.$render();
            }
            return parseInt(digits,10);
          }
          return undefined;
        }            
        ctrl.$parsers.push(inputValue);
      }
    };
});
