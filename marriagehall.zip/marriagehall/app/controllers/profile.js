app.controller('profileCtrl',function($scope,$http,$rootScope,userLabel){
    $scope.userLabel = userLabel;
    $scope.userLabel={
        left:{
            'Basic Informations':userLabel['Basic Informations'],
            'Socio Religious Attributes':userLabel['Socio Religious Attributes'],
            'Education and Occupation':userLabel['Education and Occupation'],
            'Physical Attributes':userLabel['Physical Attributes'],
            'Contact Details':userLabel['Contact Details']
        },
        right:{
            'Family Details':userLabel['Family Details'],
            "Father's Details":userLabel["Father's Details"],
            "Mother's Details":userLabel["Mother's Details"],
            'Profile Details':userLabel['Profile Details'],
            'Partner Preference':userLabel['Partner Preference'],
            'Hobbies and Interests':userLabel['Hobbies and Interests']
        }
    };
    //var user = $rootScope.isUserLoged;
    if(angular.isDefined($rootScope.appUser)){
        $scope.dbDatas=$rootScope.appUser;
    }else{
        $http.post('api/get',{action:'getMemberInfo'}).then(function(r){
            $rootScope.appUser = r.data;
            $scope.dbDatas = r.data;
        });
    }
});