app.controller('homeCtrl',function($scope, $rootScope, $http, $cookies, $location, $compile, options){
    $scope.back = false;
    $scope.flipSearch =function(){
        $scope.back = $scope.back?false:true;
    };
    
    $scope.options = options;
    
    $scope.age_range=[];
    for(var a=18; a<=75; a++){$scope.age_range.push(a);}
    
    $scope.loadCaste = function(c){
        var religion_id = $(c+' option:selected').data('id');
        var castes = $rootScope.castes;
        $scope.casteList = castes.map(function(item){
            if(religion_id==item.parent){return item.label;}
        });
    };
    
    $scope.searchService = function(d){
        //console.log(d)
        if(d === undefined){
            $rootScope.searchresult = false;
            $location.path('/search');
        }else{
            $rootScope.searchArea = $scope.sService.area;
            $rootScope.searchPin = $scope.sService.pin;
            d.action='searchService';
            $http.post('api/post',d).then(function(r){
                var data = r.data;
                if(data.error == false){
                    //console.log(data.result)
                    $scope.sresult = data.result;
                    $rootScope.sresult = data.result;
                    $rootScope.searchresult = true;
                    $location.path('/search');
                }else{
                    $rootScope.searchresult = false;
                    $location.path('/search');
                    
                }
            })
        }
    }
    
    $http.post('api/get',{action:'getService'}).then(function(r){
        var data = r.data;
        $rootScope.servicesList = data;
    });
    
    if(angular.isUndefined($rootScope.statelist)){
        $http.post('api/get',{action:'getState'}).then(function(r){
            var data = r.data;
            if(data.error == false){
                $rootScope.statelist = data.msg;  
                $scope.statelist = data.msg;  
            }
        });
    }else{
        $scope.statelist = $rootScope.statelist;  
    }

    $scope.clickService = function(servicename){
        $http.post('api/post',{action:'searchService', service: servicename}).then(function(r){
            var data = r.data;
            if(data.error == false){
                $scope.sresult = data.result;
                $rootScope.sresult = data.result;
                $rootScope.searchresult = true;
                $location.path('/search');
            }else{
                $rootScope.searchresult = false;
                $location.path('/search');
            }
        })
    }
    
    $scope.mydisabled1=true;
    $scope.$watch('sService.service', function (newValue) {
        
        if(newValue !== undefined && $scope.sService.state !== undefined){
            var txtState = $scope.sService.state
            if (newValue.length > 0 && txtState.length > 0) {
                $scope.mydisabled1=false; 
            }else{
                $scope.mydisabled1=true;
            }
        }
    });
    $scope.$watch('sService.state', function (newValue) {
        
        if(newValue !== undefined && $scope.sService.service !== undefined){
            var selService = $scope.sService.service
            if (newValue.length > 0 && selService.length > 0) {
                $scope.mydisabled1=false; 
            }else{
                $scope.mydisabled1=true;
            }
        }
    });
    
    $scope.mydisabled2=true;
    $scope.$watch('sService.drc', function (newValue) {
        if(newValue !== undefined && $scope.sService.service !== undefined && $scope.sService.state !== undefined){
            var selService = $scope.sService.service
            var txtState = $scope.sService.state
            if (newValue.length > 0 && selService.length > 0 && txtState.length > 0) {
                $scope.mydisabled2=false; 
            }else{
                $scope.mydisabled2=true;
            }
        }
    });
    
    $scope.mydisabled3=true;
    $scope.$watch('sService.area', function (newValue) {
        if(newValue !== undefined && $scope.sService.service !== undefined && $scope.sService.state !== undefined && $scope.sService.drc !== undefined){
            var selService = $scope.sService.service
            var txtState = $scope.sService.state
            var txtDC = $scope.sService.drc
            if (newValue.length > 0 && selService.length > 0 && txtState.length > 0 && txtDC.length > 0) {
                $scope.mydisabled3=false; 
            }else{
                $scope.mydisabled3=true;
            }
        }
    });
    
    $scope.mydisabled4=true;
    $scope.$watch('sService.pin', function (newValue) {
        if(newValue !== undefined && $scope.sService.service !== undefined && $scope.sService.state !== undefined && $scope.sService.drc !== undefined && $scope.sService.area !== undefined){
            var selService = $scope.sService.service
            var txtState = $scope.sService.state
            var txtDC = $scope.sService.drc
            var txtArea = $scope.sService.area
            if (newValue.length > 0 && selService.length > 0 && txtState.length > 0 && txtDC.length > 0 && txtArea.length > 0) {
                $scope.mydisabled4=false; 
            }else{
                $scope.mydisabled4=true;
            }
        }
    });
    
    $scope.myDC = {
        options: {
            minLength: 1,
            onlySelectValid: true,
            outHeight: 50,
            source: function (request, response) {
                var selService = $scope.sService.service
                var txtState = $scope.sService.state
                $http.post('api/auto-dc',{term: request.term, selService: selService, txtState: txtState}).then(function(r){
                    var data = r.data;
                    if (!data.length) {
                        data.push({label: 'not found', value: null});
                        response(data);
                    }else{
                        var result = [];
                        angular.forEach(data, function(s) {
                            //console.log(s)
                            result.push({label: s.city, value:s.city});
                        });
                        response(result);
                    }
                })
            }
        },
        events: {
            change: function (event, ui) {
                //console.log('change', event, ui);
            },
            select: function (event, ui) {
                //console.log('select', event, ui);
            }
        }
    };
    
    $scope.myArea = {
        options: {
            minLength: 1,
            onlySelectValid: true,
            outHeight: 50,
            source: function (request, response) {
                var selService = $scope.sService.service;
                var txtState = $scope.sService.state;
                var txtDC = $scope.sService.txtDC
                $http.post('api/auto-area',{term: request.term, selService: selService, txtState: txtState, txtDC: txtDC}).then(function(r){
                    var data = r.data;
                    if (!data.length) {
                        data.push({label: 'not found', value: null});
                        response(data);
                    }else{
                        var result = [];
                        angular.forEach(data, function(s) {
                            //console.log(s)
                            result.push({label: s.area, value:s.area, pin:s.pin});
                        });
                        response(result);
                    }
                })
            }
        },
        events: {
            change: function (event, ui) {
                //console.log('change', event, ui);
            },
            select: function (event, ui) {
                //console.log(ui)
                var pin = ui.item.pin
                $scope.sService.pin = pin;
            }
        }
    };
    
});

app.directive('onErrorSrc', function() {
  return {
    link: function(scope, element, attrs) {
      element.bind('error', function() {
        if (attrs.src != attrs.onErrorSrc) {
          attrs.$set('src', attrs.onErrorSrc);
        }
      });
    }
  }
});

app.directive('uiEvent', ['$parse',
    function ($parse) {
        return function ($scope, elm, attrs) {
          var events = $scope.$eval(attrs.uiEvent);
          angular.forEach(events, function (uiEvent, eventName) {
            var fn = $parse(uiEvent);
            elm.bind(eventName, function (evt) {
              var params = Array.prototype.slice.call(arguments);
              //Take out first paramater (event object);
              params = params.splice(1);
              fn($scope, {$event: evt, $params: params});
              if (!$scope.$$phase) {
                $scope.$apply();
              }
            });
          });
        };
    }
]);

