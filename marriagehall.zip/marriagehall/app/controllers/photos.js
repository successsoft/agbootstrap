app.controller('photosCtrl',function($scope,$rootScope,$http,$timeout,Upload){
    if(angular.isDefined($rootScope.appUser)){
        $scope.dbDatas=$rootScope.appUser;
    }else{
        $http.post('api/get',{action:'getMemberInfo'}).then(function(r){
            $rootScope.appUser = r.data;
            $scope.dbDatas = r.data;
        });
    }
    $scope.deleteImg = function(fileName,i){
        $http.post('api/delete',{action:'deleteUserImage',id:i,file:fileName}).then(function(r){
            if(r.data.m===true){
                $rootScope.appUser['photo'+i]='';
                $rootScope.appUser['photo'+i+'a']='0';
                $scope.dbDatas['photo'+i]='';
                $scope.dbDatas['photo'+i+'a']='0';
            }else{alert(r.data.m)}
        });
    };
    //$cookies.getObject('userInfo',r.data.user);

	$scope.$watch('img1', function () { $scope.uploadFiles($scope.img1,1); });
    $scope.$watch('img2', function () { $scope.uploadFiles($scope.img2,2); });
    $scope.$watch('img3', function () { $scope.uploadFiles($scope.img3,3); });

	$scope.uploadFiles = function(file,count) {
        $scope.f = file;
        //$scope.errFile = errFiles && errFiles[0];
        if (file) {
            jQuery('#upProgress').show();
            file.upload=Upload.upload({url:'api/upload',data:{file:file,action:'uploadUserPicture',count:count}});

            file.upload.then(function (response) {
                if(response.data.m===true){
                    var img = response.data.img;
                    $rootScope.appUser['photo'+count]=img;
                    $rootScope.appUser['photo'+count+'a']='0';
                    $scope.dbDatas['photo'+count]=img;
                    $scope.dbDatas['photo'+count+'a']='0';
                }
                $timeout(function(){
                    jQuery('#upProgress').hide();
                },1000);
            }, function (response) {
                if (response.status > 0)
                    $scope.errorMsg = response.status + ': ' + response.data;
            }, function (evt) {
                file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
            });
        }   
    }
});