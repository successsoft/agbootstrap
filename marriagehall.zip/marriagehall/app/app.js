var app = angular.module('matrimony',['ngRoute','ui.bootstrap','ngCookies','ngSanitize','bootstrap.angular.validation','mgo-angular-wizard','ngFileUpload', 'ui.autocomplete', 'fancyboxplus', 'lazy-scroll'])
.config(function($routeProvider, $httpProvider, bsValidationConfigProvider){
    bsValidationConfigProvider.global.addSuccessClass = false;

    $httpProvider.interceptors.push(function () {
        
        return {
            request:function(config){ if(config.url != "api/auto-dc" && config.url != "api/auto-area"){ jQuery('#loader').addClass('show'); } return config; },
            response:function(response){ jQuery('#loader').removeClass('show'); return response; },
            requestError:function(reqErr){ jQuery('#loader').removeClass('show'); return reqErr; },
            responseError:function(resErr){ jQuery('#loader').removeClass('show'); return resErr; }
        };
    });

    $routeProvider.caseInsensitiveMatch = true;
    $routeProvider
        .when("/",{redirectTo:"/home"})
        .when("/home",{
            title: 'Home',
            templateUrl:'app/tpls/index.html',
            controller:'homeCtrl'
        })
        .when("/signup",{
            title: 'Signup',
            templateUrl:'app/tpls/signup.html',
            controller:'signUpCtrl'
        })
        .when("/login",{
            title: 'Signup',
            templateUrl:'app/tpls/login.html',
            controller:'loginCtrl'
        })
		.when("/agent",{
            title: 'Agents',
            templateUrl:'app/tpls/agents.html',
            controller:'agentCtrl'})
        .when('/agentSignUp',{
            title: 'Agent SignUp',
            templateUrl:'app/tpls/agentSignUp.html',
            controller:'SignUpCtrl'})
        .when('/advertiserSignUp',{
            title: 'Advertiser Signup',
            templateUrl:'app/tpls/vilambarm.html',
            controller:'SignUpCtrl'
            })
        .when('/advertiser',{
            title: 'Advertiser',
            templateUrl:'app/tpls/advhome.html'
            //controller:'SignUpCtrl'
        })
        .when('/profile',{
            title:'Profile',
            templateUrl:'app/tpls/profile.html',
            controller:'profileCtrl'
        })
        .when('/photos',{
            title:'Photos',
            templateUrl:'app/tpls/photos.html',
            controller:'photosCtrl'
        })
        .when('/search',{
            title:'Category search Result',
            templateUrl:'app/tpls/search.html',
            controller:'searchCtrl'
        })
        .when('/services',{
            title:'All Services',
            templateUrl:'app/tpls/services.html',
            controller:'serviceCtrl'
        })
        .otherwise({
            //redirectTo:"/home"
        });
})
.run(function($rootScope, $location, $http, $cookies){
    
    $rootScope.$on('$routeChangeSuccess', function (event, current, previous) {
        $rootScope.title = current.$$route.title;
    });
    
    $rootScope.isUserLoged = $cookies.getObject('userInfo') || false;
    $rootScope.$on('$locationChangeStart', function(){
        var secured=['/profile','/photos'];
        if(secured.indexOf( $location.path() )>=0 && $rootScope.isUserLoged===false){
            $location.path('/home');
        }
    });

    $rootScope.signup = {
        name:'',gender:'Male',dob:'',maritalStatus:'Unmarried',
        noOChildren:'0', cls:'Not Living with me',
        language:'', religion:'', caste:'', subCaste:'', createdBy:'My Self', reference:'Advertisements',
        email:'',password:'',password2:'',
        star:'',moonsign:'',gothram:'',horosmatch:'Yes',manglik:'No',pob:'',tob:'',
        education:'',educationInfo:'',annualIncome:'',occupation:'',occupationInfo:'',employedIn:'',
        currentCountry:'',height:'',weight:'',blood:'',complexion:'Fair',bodyType:'Average',diet:'Vegetarian',smoke:'No',drink:'No',
        address:'',country:'',state:'',district:'',phone:'',mobile:'',residencyAs:'Citizen',
        familyDetails:'',familyValues:'Traditional',familyType:'Separate Family',familyStatus:'Middle Class',familyOrigin:'',
        cLocation:'',noOfBro:0,noOfSis:0,noOfBro_m:0,noOfSis_m:0,
        fatherName:'',dadLiveStat:'Alive',fOccupation:'',
        motherName:'',momLiveStat:'Alive',mOccupation:'',
        profile:'',looking:['Unmarried'],peFromAge:'18',peToAge:'24',pExpectations:'',peCountry:'India',peHeight:'0',
        peComplexion:'Any',peEducation:'Any',peReligion:'Any',peCaste:'Any',peResident:'Any',peIncome:0,hobbies:[],otherHobbies:'',
        interests:[],otherInterests:''
    };
})
.directive('calendar', function () {
    return {
        require:'ngModel',
        link: function (scope, el, attr, ngModel) {
            $(el).datepicker({
                dateFormat:'yy-mm-dd',changeMonth:true,changeYear:true,
                minDate:attr.mindate,maxDate:attr.maxdate,nextText:'',prevText:'',
                onSelect:function(dateText){scope.$apply(function(){ngModel.$setViewValue(dateText);});}
            });
        }
    };
}).
controller('appCtrl',function($scope,$rootScope,$http,$cookies,$location){
    $http.post('api/get',{action:'getData'}).then(function(r){
        var data = r.data;
        $rootScope.languages = data.language;
        $rootScope.religions = data.religion;
        $rootScope.castes = data.caste;
        $rootScope.services = data.services;
    });
    
    $http.post('api/get',{action:'getState'}).then(function(r){
        var data = r.data;
        if(data.error == false){
            $rootScope.statelist = data.msg;  
            $scope.statelist = data.msg;  
        }
    });
    
    $scope.logout = function(){
        $http.post('api/post',{action:'logout'}).then(function(r){
            if(r.data.m){
                $cookies.remove('userInfo');
                $rootScope.isUserLoged=false;
                $location.path('/home');
            }
        });
    }
});