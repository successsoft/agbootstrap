-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2016 at 02:17 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `marriagehall`
--
CREATE DATABASE IF NOT EXISTS `marriagehall` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `marriagehall`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `advertisers`
--

CREATE TABLE IF NOT EXISTS `advertisers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `company` varchar(40) NOT NULL,
  `service` varchar(50) NOT NULL,
  `address` varchar(75) NOT NULL,
  `area` varchar(100) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `pin` varchar(8) NOT NULL,
  `email` varchar(75) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `password` varchar(15) NOT NULL,
  `description` varchar(500) NOT NULL,
  `description1` text NOT NULL,
  `description2` text NOT NULL,
  `description3` text NOT NULL,
  `title1` varchar(200) NOT NULL,
  `title2` varchar(200) NOT NULL,
  `title3` varchar(200) NOT NULL,
  `approved` tinyint(1) NOT NULL,
  `photo1` varchar(100) NOT NULL,
  `photo2` varchar(50) NOT NULL,
  `photo3` varchar(50) NOT NULL,
  `photo1a` tinyint(4) NOT NULL DEFAULT '0',
  `photo2a` tinyint(4) NOT NULL DEFAULT '0',
  `photo3a` tinyint(4) NOT NULL DEFAULT '0',
  `payment` enum('CA','CQ','N') NOT NULL DEFAULT 'N' COMMENT 'Cash, Cheque, None',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `advertisers`
--

INSERT INTO `advertisers` (`id`, `name`, `company`, `service`, `address`, `area`, `city`, `state`, `pin`, `email`, `contact`, `password`, `description`, `description1`, `description2`, `description3`, `title1`, `title2`, `title3`, `approved`, `photo1`, `photo2`, `photo3`, `photo1a`, `photo2a`, `photo3a`, `payment`, `created`, `modified`) VALUES
(1, 'Manojkumar', 'Havit Co', 'Photographers and Videographers', 'This is my contact address', '', 'Chennai', 'Tamil Nadu', '600099', 'to@manojkumar.in', '9790271598', 'asdfasdf', 'company description', '', '', '', '', '', '', 0, '', '', '', 0, 0, 0, 'CA', '2016-09-12 13:00:42', '2016-09-12 13:00:42'),
(2, 'Murali Krishnan', 'Samsung Electronics', 'Bands', '#123, 4th street, Kolathur', '', 'Chennai', 'Tamil Nadu', '600099', 'email.rmanojkumar@gmail.com', '9790271598, 04443853131', 'asdf123', 'Daemonite''s Material UI is a fully responsive, cross-platform, front-end interface based on Google Material Design. This lightweight framework is built in HTML5 using Bootstrap, JS and CSS.', '', '', '', '', '', '', 0, '', '', '', 0, 0, 0, 'CA', '2016-09-12 13:00:42', '2016-09-12 13:00:42'),
(3, 'Sundar', 'Sundar Josiyam', 'Bands', 'this is my address', '', 'Chennai', 'Tamil Nadu', '600099', 'sundar@gmail.com', '9790271598', 'asdfasdf', 'Good Jadagam, astrologer', '', '', '', '', '', '', 0, '', '', '', 0, 0, 0, 'CA', '2016-09-12 13:00:42', '2016-09-12 13:00:42'),
(4, 'Ramesh', 'Ramesh', 'Bands', 'Chennai', 'xxx', 'chennai', 'Tamil nadu', '600048', 'ramesh1989jy11@gmail.com', '9874563210', '123456', 'Wroking on DJ for pass 2 years', 'Sree Balaji Hall A/c (Capacity - 200, Dinning - 60, 2 A/c rooms) and Sree Balaji Mini Hall A/c (Capacity- 100, Dinning - 27, 1 A/c Room, 1 non A/c Room) in Chamiers road, Nandanam is best suitable for all your auspicious functions like Ayush Homam, Birthday, Upanayanam, Engagement / Betrothal, Marriage reception', 'Sree Balaji Hall A/c (Capacity - 200, Dinning - 60, 2 A/c rooms) and Sree Balaji Mini Hall A/c (Capacity- 100, Dinning - 27, 1 A/c Room, 1 non A/c Room) in Chamiers road, Nandanam is best suitable for all your auspicious functions like Ayush Homam, Birthday, Upanayanam, Engagement / Betrothal, Marriage reception', 'Sree Balaji Hall A/c (Capacity - 200, Dinning - 60, 2 A/c rooms) and Sree Balaji Mini Hall A/c (Capacity- 100, Dinning - 27, 1 A/c Room, 1 non A/c Room) in Chamiers road, Nandanam is best suitable for all your auspicious functions like Ayush Homam, Birthday, Upanayanam, Engagement / Betrothal, Marriage reception', 'DJ 1', 'DJ 2', 'DJ 3', 1, '8cea5a1b1.jpg', '8cea5a1b2.png', '8cea5a1b3.png', 0, 0, 0, 'CA', '2016-09-12 13:00:42', '2016-09-12 13:00:42'),
(5, 'Test', 'Test Company', 'Bands', 'xxx', 'yyy', 'zzz', 'TN', '600032', 'test@gmail.com', '9874563201', '123456', 'test Company Description', '', '', '', '', '', '', 1, '', '443f44702.png', '443f44703.png', 0, 0, 0, 'CA', '2016-09-12 13:00:42', '2016-09-12 13:00:42'),
(6, 'test Payment', 'payment', 'Bands', 'address 1', 'Area 1', 'Chennai', 'Tamil nadu', '600032', 'payment@gmai.com', '9874563210', '', 'payment', 'test description 1', 'test description 2', 'test description 3', 'test title 1', 'test title 2', 'test title 3', 0, '', '', '', 0, 0, 0, 'N', '2016-09-14 12:17:39', '2016-09-14 12:17:39'),
(7, 'Payment', 'Payment compangy', 'Bands', 'Addresss 1', 'Area 1', 'Chennai', 'Tamil Nadu', '600032', 'payment@gmail.com', '9874563210', '', 'Payment description', 'test description 1', 'test description 2', 'test description 3', 'Title 1', 'Title 2', 'Title 3', 0, '', '', '', 0, 0, 0, 'CQ', '2016-09-14 12:19:46', '2016-09-14 12:19:46');

-- --------------------------------------------------------

--
-- Table structure for table `agent`
--

CREATE TABLE IF NOT EXISTS `agent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `address` varchar(150) NOT NULL,
  `contact` varchar(150) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(20) NOT NULL,
  `agentid` varchar(10) NOT NULL,
  `approved` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `agent`
--

INSERT INTO `agent` (`id`, `name`, `address`, `contact`, `email`, `password`, `agentid`, `approved`) VALUES
(1, 'Ravi Bhaskar', 'this is my contact address', '9551662773', 'basamnet@gmail.com', 'asdfasdf', '', 0),
(2, 'Ravi Bhaskar', 'this is my contact address', '9551662773', 'ravibaskar@gmail.com', 'asdfasdf', '', 0),
(3, 'MKDD Mahall', 'Kallikuppam', '+919789453453', 'murugesan.msan@gmail.com', 'abcd12345', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE IF NOT EXISTS `contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` varchar(50) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `page`, `content`) VALUES
(1, 'About', '&lt;h2&gt;What is OEM Ipsum?&lt;/h2&gt;\n\n&lt;p&gt;Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&amp;#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.&lt;/p&gt;\n'),
(2, 'Services', 'service content'),
(3, 'Membership Plans', '&lt;p&gt;Membership Plans&lt;/p&gt;\n'),
(4, 'Payment Options', ''),
(5, 'Contact Us', '');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE IF NOT EXISTS `enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ad_id` int(11) NOT NULL,
  `eq_name` varchar(100) NOT NULL,
  `eq_email_id` varchar(100) NOT NULL,
  `eq_mobile_no` bigint(20) NOT NULL,
  `eq_comment` text NOT NULL,
  `area` varchar(250) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `eq_for` enum('E','C','N') NOT NULL DEFAULT 'N' COMMENT 'Enquiry, Comments, None',
  `status` enum('V','NV') NOT NULL DEFAULT 'NV' COMMENT 'Viewed, Not Viewed',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`id`, `ad_id`, `eq_name`, `eq_email_id`, `eq_mobile_no`, `eq_comment`, `area`, `pincode`, `eq_for`, `status`, `created`, `modified`) VALUES
(1, 3, 'test', 'test@gmail.com', 0, 'test comment', '', '', 'E', 'NV', '2016-09-09 17:30:03', '2016-09-09 17:30:03'),
(2, 1, 'ate', 're@gmail.com', 0, 'kdjf', '', '', 'E', 'V', '2016-09-09 17:52:11', '2016-09-09 17:52:11'),
(3, 4, 'test', 'test@am.com', 0, 'test', '', '', 'E', 'NV', '2016-09-09 19:30:24', '2016-09-09 19:30:24'),
(4, 4, 'xxxx', 'xxxx@gmail.com', 0, 'kjdjfk', 'xxx', '600048', 'E', 'NV', '2016-09-12 18:50:30', '2016-09-12 18:50:30'),
(5, 4, 'Test', 'test@gmail.com', 9874563210, 'test', '', '', 'C', 'NV', '2016-09-13 13:09:06', '2016-09-13 13:09:06');

-- --------------------------------------------------------

--
-- Table structure for table `formdata`
--

CREATE TABLE IF NOT EXISTS `formdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `parent` varchar(50) NOT NULL DEFAULT '0',
  `value` varchar(200) NOT NULL,
  `photo` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=112 ;

--
-- Dumping data for table `formdata`
--

INSERT INTO `formdata` (`id`, `name`, `parent`, `value`, `photo`) VALUES
(1, 'religion', '0', 'Hindu', ''),
(2, 'religion', '0', 'muslim', ''),
(5, 'language', '0', 'Awadhi', ''),
(6, 'language', '0', 'Bengali', ''),
(7, 'language', '0', 'Bhojpuri', ''),
(8, 'language', '0', 'Bhutia', ''),
(9, 'language', '0', 'Chatlisgarhi', ''),
(10, 'language', '0', 'Chinese', ''),
(11, 'language', '0', 'Dogri', ''),
(12, 'language', '0', 'French', ''),
(13, 'language', '0', 'Garhwali', ''),
(14, 'language', '0', 'Garo', ''),
(15, 'language', '0', 'Gujarati', ''),
(16, 'language', '0', 'Haryanvi', ''),
(17, 'language', '0', 'Kakbarak', ''),
(18, 'language', '0', 'Kanauji', ''),
(19, 'language', '0', 'Kannada', ''),
(20, 'language', '0', 'Kashmiri', ''),
(21, 'language', '0', 'Khandesi', ''),
(22, 'language', '0', 'Khasi', ''),
(23, 'language', '0', 'Konkani', ''),
(24, 'language', '0', 'Koshali', ''),
(25, 'language', '0', 'Kumoani', ''),
(26, 'language', '0', 'Kutchi', ''),
(27, 'language', '0', 'Lepcha', ''),
(28, 'language', '0', 'Magahi', ''),
(29, 'language', '0', 'Maithili', ''),
(30, 'language', '0', 'Malay', ''),
(31, 'language', '0', 'Malayalam', ''),
(32, 'language', '0', 'Marathi', ''),
(33, 'language', '0', 'Marwari', ''),
(34, 'language', '0', 'Miji', ''),
(35, 'language', '0', 'Mizo', ''),
(36, 'language', '0', 'Monpa', ''),
(37, 'language', '0', 'Nepali', ''),
(38, 'language', '0', 'Oriya', ''),
(39, 'language', '0', 'Other', ''),
(40, 'language', '0', 'Persian', ''),
(41, 'language', '0', 'Punjabi', ''),
(42, 'language', '0', 'Rajasthani', ''),
(43, 'language', '0', 'Russian', ''),
(44, 'language', '0', 'Sanskrit', ''),
(45, 'language', '0', 'Santhali', ''),
(46, 'language', '0', 'Sindhi', ''),
(47, 'language', '0', 'Sindhi1', ''),
(48, 'language', '0', 'Spanish', ''),
(49, 'language', '0', 'Swedish', ''),
(50, 'language', '0', 'Tagalog', ''),
(51, 'language', '0', 'Tamil', ''),
(52, 'language', '0', 'Telugu', ''),
(53, 'language', '0', 'Tulu', ''),
(54, 'language', '0', 'Urdu', ''),
(55, 'caste', '1', 'Adi Dravida', ''),
(59, 'religion', '0', 'Christian', ''),
(60, 'caste', '1', 'Gowder', ''),
(61, 'caste', '59', 'Katholik', ''),
(62, 'caste', '1', 'Vanniyar', ''),
(63, 'caste', '1', 'Thevar', ''),
(64, 'caste', '1', 'Naidu', ''),
(65, 'caste', '1', 'Chettiyar', ''),
(66, 'caste', '1', 'Mudaliyar', ''),
(67, 'services', '0', 'Astrologers', ''),
(69, 'services', '0', 'Bands', 'ed5f045d.jpg'),
(70, 'services', '0', 'Banquets', '45b53fec.jpg'),
(71, 'language', '0', 'blabal', ''),
(72, 'services', '0', 'Beauty Parlours', ''),
(73, 'services', '0', 'Boutiques', ''),
(74, 'services', '0', 'Caterers', '75bfb0f2.jpg'),
(75, 'services', '0', 'Choreographers', '0f278291.jpg'),
(76, 'services', '0', 'Confectionary and Chocolates', ''),
(77, 'services', '0', 'Cooking Classes', ''),
(78, 'services', '0', 'Decorators', 'd0dee200.jpg'),
(79, 'services', '0', 'Detective Services', ''),
(80, 'services', '0', 'Dieticians and Nutritionists', ''),
(81, 'services', '0', 'Discotheques', ''),
(82, 'services', '0', 'DJ', ''),
(83, 'services', '0', 'Event Management Companies', ''),
(84, 'services', '0', 'Fashion Designers', ''),
(85, 'services', '0', 'Fireworks and Crackers', ''),
(86, 'services', '0', 'Florists', ''),
(87, 'services', '0', 'Groom Wear', '9a0c5641.jpg'),
(88, 'services', '0', 'Gym', ''),
(89, 'services', '0', 'Hotels', ''),
(90, 'services', '0', 'Invitation Cards', ''),
(91, 'services', '0', 'Jewellery', '13b64a74.jpg'),
(92, 'services', '0', 'Lehenga And Sherwani On Rent', ''),
(93, 'services', '0', 'Lingerie Shops', ''),
(94, 'services', '0', 'Live Performers', ''),
(95, 'services', '0', 'Luxury Cars on Rent', ''),
(96, 'services', '0', 'Makeup Artists', 'af698669.jpg'),
(97, 'services', '0', 'Matrimonial Bureau', ''),
(98, 'services', '0', 'Mehndi Artists', 'f360a7b7.jpg'),
(99, 'services', '0', 'Nail Art Studios', ''),
(100, 'services', '0', 'Pandits', ''),
(101, 'services', '0', 'Personality Development Classes', ''),
(102, 'services', '0', 'Photographers and Videographers', '3b3b5755.jpg'),
(103, 'services', '0', 'Slimming Beauty and Cosmetology', ''),
(104, 'services', '0', 'Spa', ''),
(105, 'services', '0', 'Taxi Services', ''),
(106, 'services', '0', 'Tent House', ''),
(107, 'services', '0', 'Travel Agents', ''),
(108, 'services', '0', 'Wedding Accessories', ''),
(109, 'services', '0', 'Wedding Gifts', ''),
(110, 'services', '0', 'Wedding Lehnga and Sarees', '38a6f232.jpg'),
(111, 'services', '0', 'Wedding Planners', '48703456.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matid` varchar(25) NOT NULL,
  `paymode` varchar(25) NOT NULL,
  `activationDate` date NOT NULL,
  `plan` varchar(25) NOT NULL,
  `duration` date NOT NULL,
  `amount` varchar(10) NOT NULL,
  `bank` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `matid`, `paymode`, `activationDate`, `plan`, `duration`, `amount`, `bank`, `description`) VALUES
(1, 'WM1', 'Cash', '2016-08-22', 'Silver', '2017-08-22', '2500', 'Icici Bank, Ambathur Branch', 'Some description about the payment transaction');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) NOT NULL,
  `state_name` varchar(50) NOT NULL,
  `status` enum('A','I') NOT NULL DEFAULT 'A',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `country_id`, `state_name`, `status`, `created`) VALUES
(1, 99, 'Andaman & Nicobar Islands', 'A', '2016-09-16 14:25:42'),
(2, 99, 'Andhra Pradesh', 'A', '2016-09-16 14:25:42'),
(3, 99, 'Arunachal Pradesh', 'A', '2016-09-16 14:25:42'),
(4, 99, 'Assam', 'A', '2016-09-16 14:25:42'),
(5, 99, 'Bihar', 'A', '2016-09-16 14:25:42'),
(6, 99, 'Chandigarh', 'A', '2016-09-16 14:25:42'),
(7, 99, 'Chhattisgarh', 'A', '2016-09-16 14:25:42'),
(8, 99, 'Dadra & Nagar Haveli', 'A', '2016-09-16 14:25:42'),
(9, 99, 'Daman & Diu', 'A', '2016-09-16 14:25:42'),
(10, 99, 'Delhi', 'A', '2016-09-16 14:25:42'),
(11, 99, 'Goa', 'A', '2016-09-16 14:25:42'),
(12, 99, 'Gujarat', 'A', '2016-09-16 14:25:42'),
(13, 99, 'Haryana', 'A', '2016-09-16 14:25:42'),
(14, 99, 'Himachal Pradesh', 'A', '2016-09-16 14:25:42'),
(15, 99, 'Jammu & Kashmir', 'A', '2016-09-16 14:25:42'),
(16, 99, 'Jharkhand', 'A', '2016-09-16 14:25:42'),
(17, 99, 'Karnataka', 'A', '2016-09-16 14:25:42'),
(18, 99, 'Kerala', 'A', '2016-09-16 14:25:42'),
(19, 99, 'Lakshadweep', 'A', '2016-09-16 14:25:42'),
(20, 99, 'Madhya Pradesh', 'A', '2016-09-16 14:25:42'),
(21, 99, 'Maharashtra', 'A', '2016-09-16 14:25:42'),
(22, 99, 'Manipur', 'A', '2016-09-16 14:25:42'),
(23, 99, 'Meghalaya', 'A', '2016-09-16 14:25:42'),
(24, 99, 'Mizoram', 'A', '2016-09-16 14:25:42'),
(25, 99, 'Nagaland', 'A', '2016-09-16 14:25:42'),
(26, 99, 'Odisha', 'A', '2016-09-16 14:25:42'),
(27, 99, 'Puducherry', 'A', '2016-09-16 14:25:42'),
(28, 99, 'Punjab', 'A', '2016-09-16 14:25:42'),
(29, 99, 'Rajasthan', 'A', '2016-09-16 14:25:42'),
(30, 99, 'Sikkim', 'A', '2016-09-16 14:25:42'),
(31, 99, 'Tamil Nadu', 'A', '2016-09-16 14:25:42'),
(32, 99, 'Telangana', 'A', '2016-09-16 14:25:42'),
(33, 99, 'Tripura', 'A', '2016-09-16 14:25:42'),
(34, 99, 'Uttar Pradesh', 'A', '2016-09-16 14:25:42'),
(35, 99, 'Uttarakhand', 'A', '2016-09-16 14:25:42'),
(36, 99, 'West Bengal', 'A', '2016-09-16 14:25:42');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matid` varchar(13) NOT NULL,
  `name` varchar(30) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `dob` date NOT NULL,
  `age` int(3) NOT NULL,
  `maritalStatus` varchar(15) NOT NULL,
  `noOChildren` varchar(7) NOT NULL,
  `cls` varchar(20) NOT NULL,
  `language` varchar(30) NOT NULL,
  `religion` varchar(15) NOT NULL,
  `caste` varchar(30) NOT NULL,
  `subCaste` varchar(30) NOT NULL,
  `createdBy` varchar(10) NOT NULL,
  `agentid` varchar(10) NOT NULL,
  `reference` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(25) NOT NULL,
  `star` varchar(20) NOT NULL,
  `moonsign` varchar(12) NOT NULL,
  `gothram` varchar(25) NOT NULL,
  `horosmatch` varchar(15) NOT NULL,
  `manglik` varchar(15) NOT NULL,
  `pob` varchar(50) NOT NULL,
  `tob` varchar(10) NOT NULL,
  `education` varchar(75) NOT NULL,
  `educationInfo` varchar(100) NOT NULL,
  `annualIncome` int(11) NOT NULL,
  `occupation` varchar(75) NOT NULL,
  `occupationInfo` varchar(100) NOT NULL,
  `employedIn` varchar(13) NOT NULL,
  `currentCountry` varchar(50) NOT NULL,
  `height` varchar(18) NOT NULL,
  `weight` varchar(10) NOT NULL,
  `blood` varchar(10) NOT NULL,
  `complexion` varchar(15) NOT NULL,
  `bodyType` varchar(8) NOT NULL,
  `diet` varchar(20) NOT NULL,
  `smoke` varchar(12) NOT NULL,
  `drink` varchar(12) NOT NULL,
  `address` varchar(150) NOT NULL,
  `country` varchar(30) NOT NULL,
  `state` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `residencyAs` varchar(20) NOT NULL,
  `familyDetails` varchar(150) NOT NULL,
  `familyValues` varchar(12) NOT NULL,
  `familyType` varchar(15) NOT NULL,
  `familyStatus` varchar(20) NOT NULL,
  `familyOrigin` varchar(50) NOT NULL,
  `cLocation` varchar(30) NOT NULL,
  `noOfBro` varchar(2) NOT NULL,
  `noOfSis` varchar(2) NOT NULL,
  `noOfBro_m` varchar(2) NOT NULL,
  `noOfSis_m` varchar(2) NOT NULL,
  `fatherName` varchar(30) NOT NULL,
  `dadLiveStat` varchar(10) NOT NULL,
  `fOccupation` varchar(50) NOT NULL,
  `motherName` varchar(30) NOT NULL,
  `momLiveStat` varchar(10) NOT NULL,
  `mOccupation` varchar(50) NOT NULL,
  `profile` varchar(1000) NOT NULL,
  `looking` varchar(35) NOT NULL,
  `peFromAge` tinyint(2) NOT NULL,
  `peToAge` tinyint(2) NOT NULL,
  `pExpectations` varchar(100) NOT NULL,
  `peCountry` varchar(30) NOT NULL,
  `peHeight` varchar(15) NOT NULL,
  `peComplexion` varchar(15) NOT NULL,
  `peEducation` varchar(50) NOT NULL,
  `peReligion` varchar(25) NOT NULL,
  `peCaste` varchar(50) NOT NULL,
  `peResident` varchar(18) NOT NULL,
  `peIncome` varchar(15) NOT NULL,
  `hobbies` varchar(300) NOT NULL,
  `otherHobbies` varchar(100) NOT NULL,
  `interests` varchar(300) NOT NULL,
  `otherInterests` varchar(100) NOT NULL,
  `registered` date NOT NULL,
  `expire` date NOT NULL,
  `photoProtect` tinyint(1) NOT NULL,
  `lastlogin` date NOT NULL,
  `approved` tinyint(1) NOT NULL,
  `membership` varchar(15) NOT NULL DEFAULT 'Free',
  `photo1` varchar(100) NOT NULL,
  `photo2` varchar(15) NOT NULL,
  `photo3` varchar(15) NOT NULL,
  `photo1a` tinyint(4) DEFAULT '0',
  `photo2a` tinyint(4) DEFAULT '0',
  `photo3a` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `matid`, `name`, `gender`, `dob`, `age`, `maritalStatus`, `noOChildren`, `cls`, `language`, `religion`, `caste`, `subCaste`, `createdBy`, `agentid`, `reference`, `email`, `password`, `star`, `moonsign`, `gothram`, `horosmatch`, `manglik`, `pob`, `tob`, `education`, `educationInfo`, `annualIncome`, `occupation`, `occupationInfo`, `employedIn`, `currentCountry`, `height`, `weight`, `blood`, `complexion`, `bodyType`, `diet`, `smoke`, `drink`, `address`, `country`, `state`, `district`, `phone`, `mobile`, `residencyAs`, `familyDetails`, `familyValues`, `familyType`, `familyStatus`, `familyOrigin`, `cLocation`, `noOfBro`, `noOfSis`, `noOfBro_m`, `noOfSis_m`, `fatherName`, `dadLiveStat`, `fOccupation`, `motherName`, `momLiveStat`, `mOccupation`, `profile`, `looking`, `peFromAge`, `peToAge`, `pExpectations`, `peCountry`, `peHeight`, `peComplexion`, `peEducation`, `peReligion`, `peCaste`, `peResident`, `peIncome`, `hobbies`, `otherHobbies`, `interests`, `otherInterests`, `registered`, `expire`, `photoProtect`, `lastlogin`, `approved`, `membership`, `photo1`, `photo2`, `photo3`, `photo1a`, `photo2a`, `photo3a`) VALUES
(1, 'WM1', 'Manojkumar R', 'Male', '1998-08-19', 18, 'Unmarried', '0', 'Not Living with me', 'Tamil', 'Hindu', 'Adi Dravida', 'Theriyadhu', 'My Self', '', 'Others', 'ramesh.s@lobaasoft.com', '123456', 'Punarpusam', 'key', 'Siva', 'Does not matter', 'Does not matter', 'Chinnamanur', '10:55 am', 'B.C.A', 'Bachelor of Computer Application', 500000, 'Designer - IT & Engineering', 'Occupation details', 'Business', 'India', '5 feet 8 inches', '65 Kgs', 'O+', 'Fair', 'Average', 'Vegetarian', 'No', 'No', 'This is my contact address', 'India', 'Tamil Nadu', 'Theni', '9790271598', '9790271598', 'Citizen', 'dfg', 'Liberal', 'Joint Family', 'Middle Class', 'Theriyadhu', 'Chennai', '0', '1', '0', '0', 'Raj Kumar', 'Not Alive', 'Father Father Father', 'Savitha', 'Alive', 'House Wife', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.', 'Unmarried', 18, 25, 'Good Girl with small mouth', 'India', '5 feet 4 inches', 'Fair', 'M.C.A', 'Hindu', 'Adi Dravida', 'Citizen', '10000', 'Acting,Astronomy,Astrology,Collectibles', 'Learning', 'Politics,Reading,Social service', 'I dont know', '2016-08-21', '2017-08-22', 0, '2016-08-21', 1, 'Silver', '6ff128ae1.jpg', '6ff128ae2.jpg', '', 1, 0, 0),
(2, 'WM2', 'Saravanan Vignesh', 'Male', '1998-08-02', 18, 'Unmarried', '0', 'Not Living with me', 'Tamil', 'Hindu', 'Adi Dravida', 'Some sub caste', 'My Self', '', 'Advertisements', 'saravanavignesh@live.com', 'asdfasdf', 'Krithigai', 'Libra', 'Shiva', 'Does not matter', 'Does not matter', 'Odaipatti', '10:10 AM', 'BA', 'Some Education', 500000, 'Administrative Professional', 'Occapation Details', 'Private secto', 'India', '5 feet 11 inches', '56 Kgs', 'O+', 'Fair', 'Average', 'Vegetarian', 'No', 'No', 'This is my address', 'India', 'Tamil Nadu', 'Theni', '9790271598', '9876543210', 'Citizen', 'dsfsadf1', 'Traditional', 'Separate Family', 'Middle Class', 'This is my family orgin', 'Chinnamnur', '0', '1', '0', '1', 'Rajendran', 'Alive', 'Retired Sales tax officer', 'Vani', 'Alive', 'House Wife', 'You could enter details about you or a brief description about yourself, Maximum 1000 characters. (If Profile contains any details about your contact informations like e-mail ,phone number, etc. Your profile will be rejected)', 'Unmarried', 24, 27, 'This is my expectation', 'India', '5 feet 11 inche', 'Any', 'Any', 'Hindu', 'Adi Dravida', 'Citizen', '0', 'Palmistry,Pets,Photography', 'this is other hobbies', '', 'this is other intrest', '0000-00-00', '2016-08-21', 0, '2016-08-21', 1, 'Free', '', '', '', 0, 0, 0),
(3, 'WM3', 'Another name', 'Male', '1998-08-02', 18, 'Unmarried', '0', 'Not Living with me', 'Tamil', 'Hindu', 'Adi Dravida', 'Some sub caste', 'My Self', '', 'Advertisements', 'saravanavignesh@ilinks.com', 'asdfasdf', 'Krithigai', 'Libra', 'Shiva', 'Does not matter', 'Does not matter', 'Odaipatti', '10:10 AM', 'BA', 'Some Education', 500000, 'Administrative Professional', 'Occapation Details', 'Private secto', 'India', '5 feet 11 inches', '56 Kgs', 'O+', 'Fair', 'Average', 'Vegetarian', 'No', 'No', 'This is my address', 'India', 'Tamil Nadu', 'Theni', '9790271598', '9876543210', 'Citizen', 'dsfsadf1', 'Traditional', 'Separate Family', 'Middle Class', 'This is my family orgin', 'Chinnamnur', '0', '1', '0', '1', 'Rajendran', 'Alive', 'Retired Sales tax officer', 'Vani', 'Alive', 'House Wife', 'You could enter details about you or a brief description about yourself, Maximum 1000 characters. (If Profile contains any details about your contact informations like e-mail ,phone number, etc. Your profile will be rejected)', 'Unmarried', 24, 27, 'This is my expectation', 'India', '5 feet 11 inche', 'Any', 'Any', 'Hindu', 'Adi Dravida', 'Citizen', '0', 'Palmistry,Pets,Photography', 'this is other hobbies', 'Computer games,Health & fitness,Internet,Learning new languages', 'this is other intrest', '0000-00-00', '2016-08-21', 0, '2016-08-21', 0, 'Free', '', '', '', 0, 0, 0),
(4, 'WM4', 'Manojkumar', 'Male', '1998-08-11', 18, 'Unmarried', '0', 'Not Living with me', 'Tamil', 'Hindu', 'Adi Dravida', 'My subcaste', 'My Self', '', 'Advertisements', 'email.rmanojkumar@gmail.com', 'asdfasdf', 'Bharani', 'Leo', 'Vishnu', 'Does not matter', 'No', 'chinnamanur', '10:45 AM', 'Aeronautical Engineering', 'My Education', 10000, 'Supervisor', 'My occupation', 'Private secto', 'United States', '5 feet 4 inches', '57 Kgs', 'O+', 'Fair', 'Average', 'Vegetarian', 'No', 'No', 'this is my address', 'India', 'Tamil Nadu', 'Theni', '', '9790271598', 'Permanent Resident', 'This is my family details', 'Moderate', 'Separate Family', 'Middle Class', 'My family orgin', 'Current Location', '1', '0', '1', '0', 'appa name', 'Alive', 'appa work', 'amma name', 'Alive', 'amma work', 'Please enter at least 150 characters.\nYou could enter details about you or a brief description about yourself, Maximum 1000 characters. (If Profile contains any details about your contact informations like e-mail ,phone number, etc. Your profile will be rejected)', 'Unmarried', 18, 24, 'this is my expectaiton', 'India', '0', 'Any', 'Any', 'Hindu', 'Any', 'Any', '0', 'Astrology,Collectibles,Cooking,Crosswords', '', 'Internet,Learning new languages,Movies', '', '0000-00-00', '2016-08-21', 0, '2016-08-21', 0, 'Free', '', '', '', 0, 0, 0),
(5, 'WM5', 'Vidhya', 'Female', '1998-08-01', 18, 'Unmarried', '0', 'Not Living with me', 'Tamil', 'Hindu', 'Adi Dravida', 'Theriyadhu', 'My Self', '', 'Advertisements', 'vidhyarajendran@gmail.com', 'asdfasdf', 'Bharani', 'Cancer', 'Siva', 'Yes', 'No', 'Chinnamanur', '10:57 am', 'M.C.A', 'Edu detail', 800000, 'Manager', 'My Occupation', 'Private secto', 'India', '5 feet 4 inches', '55 Kgs', 'O+', 'Fair', 'Average', 'Vegetarian', 'No', 'No', 'address blabla', 'India', 'Tamil Nadu', 'Theni', '04443853131', '9551662773', 'Citizen', 'My family is a good family', 'Traditional', 'Separate Family', 'Middle Class', 'Orginal', 'Chinnamanu', '1', '0', '0', '0', 'Rajendran', 'Alive', 'Government Employee', 'Vani', 'Alive', 'Homemaker', 'A visual language for our users that synthesizes the classic principles of good design with the innovation and possibility of technology and science. This is material design.', 'Unmarried', 24, 29, 'my expectation', 'India', '0', 'Any', 'Any', 'Hindu', 'Adi Dravida', 'Citizen', '0', 'Astrology,Collectibles,Cooking,Crosswords', 'My other hobbies', 'Computer games,Health & fitness,Internet,Learning new languages,Movies', 'other intrestsss', '2016-08-22', '0000-00-00', 0, '0000-00-00', 0, 'Free', '', '', '', 0, 0, 0),
(6, 'WM6', 'Manojkumar', 'Male', '1989-05-10', 27, 'Unmarried', '0', 'Not Living with me', 'Tamil', 'Christian', 'Gowder', 'a subcaste', 'Agent', '1', 'Advertisements', 'email@gmail.com', 'asdfasdf', 'Punarpusam', 'Gemini', 'Shiva', 'Yes', 'No', 'Chinnamanur', '10:00 AM', 'B.C.A', 'BCA Completed', 50000, 'Human Resources Professional', 'Working in a company', 'Private secto', 'India', '5 feet 11 inches', '51 Kgs', 'O+', 'Fair', 'Average', 'Vegetarian', 'No', 'No', 'this is my address', 'India', 'Tamil Nadu', 'Theni', '', '9790271598', 'Citizen', 'This is my family details', 'Traditional', 'Separate Family', 'Middle Class', 'family orgin', '', '0', '0', '0', '0', '', 'Alive', '', '', 'Alive', '', '', 'Unmarried', 18, 24, '', 'India', '0', 'Any', 'Any', 'Any', 'Any', 'Any', '0', 'Collectibles, Cooking', '', 'Computer games, Health & fitness, Internet, Learning new languages', '', '2016-08-26', '0000-00-00', 0, '0000-00-00', 0, 'Free', '', '', '', 0, 0, 0),
(7, 'WM7', 'Manojkumar', 'Male', '1989-05-10', 27, 'Unmarried', '0', 'Not Living with me', 'Tamil', 'Christian', 'Gowder', 'a subcaste', 'Agent', '1', 'Advertisements', 'email1@gmail.com', 'asdfasdf', 'Punarpusam', 'Gemini', 'Shiva', 'Yes', 'No', 'Chinnamanur', '10:00 AM', 'B.C.A', 'BCA Completed', 50000, 'Human Resources Professional', 'Working in a company', 'Private secto', 'India', '5 feet 11 inches', '51 Kgs', 'O+', 'Fair', 'Average', 'Vegetarian', 'No', 'No', 'this is my address', 'India', 'Tamil Nadu', 'Theni', '', '9790271598', 'Citizen', 'This is my family details', 'Traditional', 'Separate Family', 'Middle Class', 'family orgin', '', '0', '0', '0', '0', '', 'Alive', '', '', 'Alive', '', '', 'Unmarried', 18, 24, '', 'India', '0', 'Any', 'Any', 'Any', 'Any', 'Any', '0', 'Film-making, Fishing, Gardening/ landscaping, Graphology', '', 'Writing, Yoga, Alternative healing / medicine', '', '2016-08-26', '0000-00-00', 0, '0000-00-00', 0, 'Free', '', '', '', 0, 0, 0),
(8, 'WM8', 'bhaskartest', 'Male', '1998-08-10', 18, 'Unmarried', '0', 'Not Living with me', 'Tamil', 'Hindu', 'Mudaliyar', 'agamudiyar', 'My Self', '', 'Friends', 'basamnet@gmail.com', 'test123', 'Krithigai', 'Cancer', '', 'Yes', 'No', 'arcot', '09.00', 'B.E/B.Tech', 'BE', 1200000, 'Manager', 'MANAGAER', 'Private secto', 'India', '4 feet 10 inches', '56 Kgs', 'AB-', 'Wheatish', 'Slim', 'Eggetarian', 'No', 'No', 'KOLATHUR', 'India', 'TAMILNADU', 'CHENNAI', '9884466822', '9551808888', 'Citizen', '1', 'Traditional', 'Separate Family', 'Middle Class', 'ARCOTT', 'CHENNAI', '1', '1', '0', '0', 'RAVITEST', 'Alive', 'SUPERVISOR', 'MALATEST', 'Alive', 'HOUSEWIVES', 'Tamil cinema la Police na Captain..\nCaptain na Police..\nHappy Birthday Captain VijayakanthTamil cinema la Police na Captain..\nCaptain na Police..\nHappy Birthday Captain VijayakanthTamil cinema la Police na Captain..\nCaptain na Police..\nHappy Birthday Captain VijayakanthTamil cinema la Police na Captain..\nCaptain na Police..\nHappy Birthday Captain VijayakanthTamil cinema la Police na Captain..\nCaptain na Police..\nHappy Birthday Captain Vijayakanth', 'Unmarried', 18, 24, 'ENGINEER', 'India', '5 feet 1 inches', 'Wheatish', 'Any', 'Hindu', 'Any', 'Citizen', '1300000', 'Cooking, Crosswords, Dancing', 'TESTHOBBI', 'Book clubs, Computer games, Health & fitness, Internet, Learning new languages, Movies', 'OTHERHOBBI', '2016-08-26', '0000-00-00', 0, '0000-00-00', 0, 'Free', '25a060171.jpg', '25a060172.jpg', '25a060173.jpg', 0, 0, 0),
(9, 'WM9', 'MURUGESAN', 'Male', '1998-08-04', 18, 'Unmarried', '0', 'Not Living with me', 'Tamil', 'Hindu', 'Thevar', 'Yadav', 'Parents', '', 'Others', 'murugesan.msan@gmail.com', 'abcd12345', 'Kettai', 'Scorpio', '', 'Yes', 'Yes', 'Kalaiyarkoil', '5.20', 'B.C.A', 'Bca', 5, 'Manager', '', 'Private secto', 'India', '5 feet 6 inches', '58 Kgs', 'B+', 'Fair', 'Average', 'Non-Veg', 'No', 'No', 'Kallikuppam,vpc Nagar, 1st st,9.', 'India', 'Tamil Nadu', 'Tiruvallur', '+919789453453', '+919789453453', 'Citizen', '', 'Traditional', 'Separate Family', 'Middle Class', '', '', '0', '0', '0', '0', '', 'Alive', '', '', 'Alive', '', '', 'Unmarried', 18, 24, 'Fair', 'India', '5 feet 4 inches', 'Fair', 'Any', 'Hindu', 'Any', 'Citizen', '0', '', '', '', '', '2016-08-28', '0000-00-00', 0, '0000-00-00', 0, 'Free', '', '', '', 0, 0, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
