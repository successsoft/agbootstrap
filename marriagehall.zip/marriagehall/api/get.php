<?php
session_start();
include"../config.php";
include"functions.php";

if($action=='getData'){
	op(getPageDatas('all'));
}
if($action=='getMemberInfo'){
	$table = $_SESSION['userloged']['type'];
	$email = $_SESSION['userloged']['email'];
	op(getMember($table,$email));
}

if($action=='getService'){
	op(getServicesData('services'));
}

if($action=='getAllService'){
	op(getServicesData('all'));
}

if($action=='getState'){
	op(getStateData('states'));
}