<?php 
session_start();
include"../config.php";
include"functions.php";

$arr = array();
if(isset($service)){
    if(!empty($service)){
        $condd = "service LIKE '%".trim($service)."%'";
        array_push($arr,$condd);
    }
}
if(isset($state)){
    if(!empty($state)){
        $condd = "state LIKE '%".trim($state)."%'";
        array_push($arr,$condd);
    }
}

if(isset($txtDC)){
    if(!empty($txtDC)){
        $condd = "city LIKE '%".trim($txtDC)."%'";
        array_push($arr,$condd);
    }
}

if(isset($term)){
    if(!empty($term)){
        $condd = "area LIKE '%".trim($term)."%'";
        array_push($arr,$condd);
    }
}
if(empty($arr)){
    array_push($arr,1); 
}
$query = "SELECT distinct(area), pin FROM advertisers WHERE ".implode(" AND ",$arr); 
$sql = mysql_query($query) or die(mysql_error());

$output = array();
if(mysql_num_rows($sql) > 0){
    while( $row=mysql_fetch_assoc($sql) ){
        //print_r($row);die;
        $output[] = $row;
    }
    $error = false;
}else{
    $error = true;
}
echo json_encode($output);die;

?>