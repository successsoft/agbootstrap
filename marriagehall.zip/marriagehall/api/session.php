<?php
session_start();
foreach($_SESSION['userloged'] as $k=>$v){
	echo "$k = $v<br>";
};