<?php
session_start();
include"../config.php";
include"functions.php";

if(!isset($_SESSION['userloged'])){ op('Invalid Access'); }

$email = $_SESSION['userloged']['email'];
//$filehash = hash("crc32b",$email);
$userDir="../uploads/user/";

if($action=='deleteUserImage'){
	unlink($userDir.$file);
	if(mysql_query("update user set photo{$id}='', photo{$id}a='0' where email='$email'")){
		$m=true; $i="photo".$id;
	}else{ $m=mysql_error(); }
	op(array('m'=>$m));
}