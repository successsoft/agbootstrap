<?php
session_start();
include"../config.php";
include"functions.php";
if($action=='login'){
	$select='*';
	$check="='$name' and password='$password'";
	$output='Invalid Username or Password';
	$user=''; $dbData=NULL;
	function userExist($table,$col,$where=''){
		if($where!=''){ $where='where '.$where; }
		$qry=mysql_query("select $col from $table $where") or mysql_error();
		if(mysql_num_rows($qry)>='1'){
			$row = mysql_fetch_assoc($qry);
			unset($row['password']);
			return array( 'valid'=>true, 'dbrow'=>$row, 'name'=>$row['name'], 'email'=>$row['email']);			
		}else{ return array('valid'=>false); };
	};
	$ue = userExist($loginAs,$select,"email".$check);
	
	if($loginAs=='user' and $ue['valid']===false){
		$ue = userExist($loginAs,$select,"matid".$check);
	}	
	if( $ue['valid'] ){
		$appid = $loginAs=='user' ? $ue['dbrow']['matid'] : $ue['dbrow']['id'];		
		$_SESSION['userloged'] = $user = array('type'=>$loginAs,'email'=>$ue['email'],'name'=>$ue['name'],'appid'=>$appid);
		$output=true; $dbData = $ue['dbrow'];
	}
	op(array('m'=>$output,'user'=>$user,'dbData'=>$dbData));
}
elseif($action=='logout'){
	$_SESSION['userloged']='';
	unset($_SESSION['userloged']);
	op(array('m'=>true));
}
elseif($action=='userSignUp'){
	$table='user';
	$inValidEmail = emailExist($table,$email);
	
	$passwordUnMatched = $password!=$password2;	
	if($passwordUnMatched and $inValidEmail){
		op(array('m'=>'Password not matched, Email already exist'));
	}elseif($passwordUnMatched){op(array('m'=>'Password not matched'));}
	elseif($inValidEmail){op(array('m'=>'Email already exist'));}
	
	foreach(array('looking','hobbies','interests') as $key){
		if(sizeof($$key)>0){ $$key = implode(', ',$$key); }else{ $$key=''; }
	}	
	
	$post=array('name','gender','dob','maritalStatus','noOChildren','cls','language','religion','caste','subCaste','createdBy','reference','email','password','star','moonsign','gothram','horosmatch','manglik','pob','tob','education','educationInfo','annualIncome','occupation','occupationInfo','employedIn','currentCountry','height','weight','blood','complexion','bodyType','diet','smoke','drink','address','country','state','district','phone','mobile','residencyAs','familyDetails','familyValues','familyType','familyStatus','familyOrigin','cLocation','noOfBro','noOfSis','noOfBro_m','noOfSis_m','fatherName','dadLiveStat','fOccupation','motherName','momLiveStat','mOccupation','profile','looking','peFromAge','peToAge','pExpectations','peCountry','peHeight','peComplexion','peEducation','peReligion','peCaste','peResident','peIncome','hobbies','otherHobbies','interests','otherInterests');
	
	$redirect='/login';
	if($_SESSION['userloged']['type']=='agent'){
		array_push($post,'agentid');
		$agentid  = $_SESSION['userloged']['appid'];
		$createdBy= 'Agent';
		$redirect='/agent';
	}
	$CVs = generateInsert($post);
	
	$registered=date("Y-m-d");
	
	$cols = $CVs['c'].",registered";
	$vals = $CVs['v'].",'$registered'";

	$qry=insert($table,$cols,$vals);
	if($qry===true){
		$qry = mysql_query("update $table set matid=concat('WM',id),age=(YEAR(CURDATE())-YEAR(dob)) - (RIGHT(CURDATE(),5)<RIGHT(dob,5))")?true:
		'Update Error: '.mysql_error();
	}
	op(array('m'=>$qry,'redirect'=>$redirect));
}

elseif(in_array($action,array('agentSignUp','advertiserSignUp')) ){	
	$table='advertisers';
	//$post=array('name','company','description','service','address','area','city','state','pin','email','contact','password','description1');
    $post = array('name','company','description','service','address','area','city','state','pin','email','contact','description1','description2','description3','title1','title2','title3','payment','created','modified');
	
	if($action=='agentSignUp'){
		$table = 'agent';
		$post = array('name','address','email','contact','password');
	}	
	emailExist($table,$email) ? op(array('m'=>'Email Already Exist. Try new email (or) Login with '.$email)):'';	
	
	$CVs = generateInsert($post);	
	$cols=$CVs['c']; $vals=$CVs['v'];
	op(array( 'm'=>insert($table,$cols,$vals) ));
}

elseif(in_array($action,array('sendEnquiry')) ){	
    $table='enquiry';
	$post = array('ad_id','eq_name','eq_email_id','eq_comment','area','pincode','eq_for','created','modified');
	$CVs = generateInsert($post);
    $cols=$CVs['c']; 
    $vals=$CVs['v'];
	op(array( 'm'=>insert($table,$cols,$vals) ));
}

elseif(in_array($action,array('postComments')) ){	
    $table='enquiry';
	$post = array('ad_id','eq_name','eq_email_id','eq_mobile_no','eq_comment','eq_for','created','modified');
	$CVs = generateInsert($post);
    $cols=$CVs['c']; 
    $vals=$CVs['v'];
	op(array( 'm'=>insert($table,$cols,$vals) ));
}

elseif($action=='searchService'){
    //echo $service;
    $arr = array();
    if(isset($service)){
        if(!empty($service)){
            $condd = "service LIKE '%".trim($service)."%'";
            array_push($arr,$condd);
        }
    }
    if(isset($state)){
        if(!empty($state)){
            $condd = "state LIKE '%".trim($state)."%'";
            array_push($arr,$condd);
        }
    }
    if(isset($drc)){
        if(!empty($drc)){
            $condd = "( city LIKE '%".trim($drc)."%')";
            array_push($arr,$condd);
        }
    }
    if(isset($area)){
        if(!empty($area)){
            $condd = "area LIKE '%".trim($area)."%'";
            array_push($arr,$condd);
        }
    }
    if(isset($pin)){
        if(!empty($pin)){
            $condd = "pin LIKE '%".trim($pin)."%'";
            array_push($arr,$condd);
        }
    }
    
    if(empty($arr)){
        array_push($arr,1); 
    }
    
    $start_point = ($limit * $page) - $limit;
    $query = "SELECT * FROM advertisers WHERE ".implode(" AND ",$arr)." LIMIT $start_point, $limit"; 
    //print_r($query);die;
    $sql = mysql_query($query) or die(mysql_error());
    
    $output = array();
    $dataPagination = '';
    if(mysql_num_rows($sql) > 0){
        while( $row=mysql_fetch_assoc($sql) ){
            //print_r($row);die;
            $output[] = $row;
        }
        
        include 'pagination.php';
        $pagination = new pagination;
        $where = implode(" AND ",$arr);
        $dataPagination = $pagination->infinitescroll('advertisers', $where, $limit, $page);
        
        //print_r($dataPagination);die;
        $error = false;
    }else{
        $error = true;
    }
    $response_array['error'] = $error;
    $response_array['result'] = $output;
    $response_array['pagination'] = $dataPagination;
    echo json_encode($response_array);die;
}