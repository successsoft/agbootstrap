<?php 
CLASS pagination {
    function page($table, $where, $per_page = 50 ,$page = 1, $url = '?'){
        $sql_query = "SELECT COUNT(*) as count FROM $table WHERE $where";
        $sql = mysql_query($sql_query) or die(mysql_error());
        $row = mysql_fetch_assoc($sql);
        //print_r( $row );die;
        
        $total = $row['count'];

        $adjacents = "2";

        $page = ($page == 0 ? 1 : $page);
        $start = ($page - 1) * $per_page;

        $firstPage = 1;

        $prev = $page - 1;
        $next = $page + 1;
        $lastpage = ceil($total/$per_page);
        $lpm1 = $lastpage - 1;

        $pagination = "";
        if($lastpage > 1)  {
            $pagination .= "<ul class='pagination'>";
            $pagination .= "<li class='details'>Page $page of $lastpage</li>";
            $prev = ($page == 1)?1:$page - 1;
            //$pagination = '';
            if ($page == 1) {
                $pagination.= "<li><a class='current' title='current'>First</a></li>";
                $pagination.= "<li><a class='current' title='current'>Prev</a></li>";
            } else {
                $pagination.= "<li><a ng-click='setPage($firstPage)' title='$firstPage'>First</a></li>";
                $pagination.= "<li><a ng-click='setPage($prev)' title='$prev'>Prev</a></li>";
            }
            if ($lastpage < 7 + ($adjacents * 2)) {
                for ($counter = 1; $counter <= $lastpage; $counter++) {
                    if ($counter == $page)
                        $pagination.= "<li class='li-page'><a id='$counter' class='current' title='current'>$counter</a></li>";
                    else
                        $pagination.= "<li class='li-page'><a id='$counter' ng-click='setPage($counter)' title='$counter'>$counter</a></li>";
                }
            } elseif($lastpage > 5 + ($adjacents * 2)) {
                if($page < 1 + ($adjacents * 2)) {
                    for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++) {
                        if ($counter == $page)
                            $pagination.= "<li class='li-page'><a id='$counter' class='current' title='current'>$counter</a></li>";
                        else
                            $pagination.= "<li class='li-page'><a id='$counter' ng-click='setPage($counter)' title='$counter'>$counter</a></li>";
                    }
                    $pagination.= "<li class='dot'>...</li>";
                    $pagination.= "<li class='li-page'><a id='$lpm1' ng-click='setPage($lpm1)' title='$lpm1'>$lpm1</a></li>";
                    $pagination.= "<li class='li-page'><a id='$lastpage' ng-click='setPage($lastpage)' title='$lastpage'>$lastpage</a></li>";
                } elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2)) {
                    $pagination.= "<li class='li-page'><a id='1' ng-click='setPage(1)' title='1'>1</a></li>";
                    $pagination.= "<li class='li-page'><a id='2' ng-click='setPage(2)' title='2'>2</a></li>";
                    $pagination.= "<li class='dot'>...</li>";
                    for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++) {
                        if ($counter == $page)
                            $pagination.= "<li class='li-page'><a id='$counter' class='current' title='current'>$counter</a></li>";
                        else
                            $pagination.= "<li class='li-page'><a id='$counter' ng-click='setPage($counter)' title='$counter'>$counter</a></li>";
                    }
                    $pagination.= "<li class='dot'>..</li>";
                    $pagination.= "<li class='li-page'><a id='$lpm1' ng-click='setPage($lpm1)'  title='$lpm1'>$lpm1</a></li>";
                    $pagination.= "<li class='li-page'><a id='$lastpage' ng-click='setPage($lastpage)' title='$lastpage'>$lastpage</a></li>";
                } else {
                    $pagination.= "<li class='li-page'><a id='1' ng-click='setPage(1)' title='1'>1</a></li>";
                    $pagination.= "<li class='li-page'><a id='2' ng-click='setPage(2)' title='2'>2</a></li>";
                    $pagination.= "<li class='dot'>..</li>";
                    for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++) {
                        if ($counter == $page)
                            $pagination.= "<li class='li-page'><a id='$counter' class='current' title='current'>$counter</a></li>";
                        else
                            $pagination.= "<li class='li-page'><a id='$counter' ng-click='setPage($counter)' title='$counter'>$counter</a></li>";
                    }
                }
            }

            if ($page < $counter - 1){
                $pagination.= "<li><a ng-click='setPage($lastpage)' title='$next'>Next</a></li>";
                $pagination.= "<li><a ng-click='setPage($lastpage)' title='$lastpage'>Last</a></li>";
            }else{
                $pagination.= "<li><a class='current' title='current'>Next</a></li>";
                $pagination.= "<li><a class='current' title='current'>Last</a></li>";
            }
            $pagination.= "</ul>\n";
        }

        return $pagination;
    }
    
    function infinitescroll($table, $where, $per_page = 50 ,$page = 1, $url = '?'){
        $sql_query = "SELECT COUNT(*) as count FROM $table WHERE $where";
        $sql = mysql_query($sql_query) or die(mysql_error());
        $row = mysql_fetch_assoc($sql);
        //print_r( $row );die;
        
        $total = $row['count'];

        $page = ($page == 0 ? 1 : $page);
        $start = ($page - 1) * $per_page;

        $firstPage = 1;

        $pagination['prevpage'] = $page - 1;
        $pagination['currpage'] = $page;
        $pagination['nextpage'] = $page + 1;
        $pagination['lastpage'] = ceil($total/$per_page);
        $lastpage = ceil($total/$per_page);
        $pagination['lpm1page'] = $lastpage - 1;
        
        return $pagination;
    }
}

?>