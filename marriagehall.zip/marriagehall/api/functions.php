<?php
function sanitize($input,$parentKey=null){
    foreach($input as $var=>$val) {
        if(!is_array($val)){
            $value=mysql_real_escape_string($val);
			if($parentKey==null){$GLOBALS[$var]=$value;}
			else{$GLOBALS[$parentKey][$var]=$value;}
        }else{sanitize($val,$var);}
    }
}
function op($a){ die(json_encode($a)); }
function getPageDatas($data){
	$religion=$caste=$language=$services=array();	
	$where="";
	if($data!='all'){$where="where name='$data'";}
	
	$qry=mysql_query("select * from formdata $where order by value");
	while( $row=mysql_fetch_assoc($qry) ){
		if($row['name']=='caste'){
			array_push($$row['name'],array('label'=>$row['value'], 'parent'=>(int)$row['parent']));
		}else{
			array_push($$row['name'],array('label'=>$row['value'], 'id'=>(int) $row['id'], 'photo'=>$row['photo']));
		}
	}
	
	if($data=='all'){
		return array('religion'=>$religion,'language'=>$language,'caste'=>$caste,'services'=>$services);
	}
	return $$data;
}

function getServicesData($data){
	$services=array();	
	$where="";
    if($data!='all'){
        $where = "where name='$data' AND photo <> ''";    
    }else{
        $where = "where name='services'";  
    }       
 
	$sqlquery = "select * from formdata $where order by value";
	                 
	$qry=mysql_query($sqlquery) or die(mysql_error());
	while( $row=mysql_fetch_assoc($qry) ){
		array_push($$row['name'],array('label'=>$row['value'], 'id'=>(int) $row['id'], 'photo'=>$row['photo']));
	}
    
	return $services;
}

function getStateData($data){
    $sqlquery = "select * from states WHERE status = 'A'  order by state_name";
	$qry = mysql_query($sqlquery) or die(mysql_error());
    if(mysql_num_rows($qry) > 0){
        $error = false;
        while($row = mysql_fetch_assoc($qry)){
            $result['id'] = $row['id'];
            $result['state_name'] = $row['state_name'];
            $output[] = $result;
        }
        $response_array['msg'] = $output; 
    }else{
        $error = true;
    }
    $response_array['error'] = $error;
    return $response_array;
}

function generateInsert($array){
	$cols=$vals=array();	
	foreach($array as $key){
        if($key == 'created' || $key == "modified" ){
            date_default_timezone_set("Asia/Kolkata");
        	array_push($cols,$key);
            array_push($vals, "'".date('Y-m-d H:i:s')."'");
        }else{
            if($GLOBALS[$key]!=''){
    			array_push($cols,$key);
    			array_push($vals,"'".$GLOBALS[$key]."'");
    		}
        } 
	}
	$cols=implode(',',$cols);
	$vals=implode(',',$vals);
	return ['c'=>$cols, 'v'=>$vals];
}
function getMember($table,$email){
	$qry=mysql_query("select * from $table where email='$email'");
	$row = mysql_fetch_assoc($qry);
	unset($row['password']);
	return $row;
}
function emailExist($table,$email){
	$qry=mysql_query("select email from $table where email='$email'");
	return mysql_num_rows($qry)>='1';
}
function insert($t,$c,$v){
	return mysql_query("insert into $t ($c) values ($v)")?true:mysql_error();
}
if(strtolower($_SERVER['CONTENT_TYPE'])=='application/json;charset=utf-8'){	
	$jsInput=json_decode(file_get_contents("php://input"),1);sanitize($jsInput);}
else{sanitize($_POST);}