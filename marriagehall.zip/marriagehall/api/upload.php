<?php
session_start();
if(!isset($_SESSION['userloged'])){ die('Invalid Access'); }

include"../config.php";
include"imageEditor.php";
include"functions.php";

//print_r($_SESSION);die;
if($action=='uploadUserPicture'){
    //[type] => user [type] => advertisers
    
	$email=$_SESSION['userloged']['email'];
	
	$file_name = $_FILES['file']['name'];
	$file_tmp = $_FILES['file']['tmp_name'];
	
	$ext = pathinfo($file_name, PATHINFO_EXTENSION);
	$newfilename = hash("crc32b",$email).$count.".$ext";
    if($_SESSION['userloged']['type'] == 'user'){
        $location='../uploads/user/'.$newfilename;
    	if(move_uploaded_file($file_tmp,$location)){		
    		img_resize($location,$location,'400','400',$ext);
    		if(mysql_query("update user set photo$count='$newfilename', photo".$count."a='0' where email='$email'")){
    			op(array('m'=>true,'img'=>$newfilename));
    		}else{ op(array('m'=>mysql_error())); }
    	}
    }else if($_SESSION['userloged']['type'] == 'advertisers'){
        $location='../uploads/advertisers/'.$newfilename;
    	if(move_uploaded_file($file_tmp,$location)){		
    		img_resize($location,$location,'400','400',$ext);
    		if(mysql_query("update advertisers set photo$count='$newfilename', photo".$count."a='0' where email='$email'")){
    			op(array('m'=>true,'img'=>$newfilename));
    		}else{ op(array('m'=>mysql_error())); }
    	}
    }else{
        
    }
}