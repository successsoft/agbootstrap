<?php
require 'phpmailer/PHPMailerAutoload.php';

$se = sndEmail('','manoz.cumar.6@gmail.com','Manoj','Test Subject','This is the HTML message body <b>in bold!</b>','');
if($se===true){
	echo "mail sent";
}else{ echo $se; }

function sndEmail($fromName,$to,$to_user_name,$subject,$body,$alt_body,$attachment=false,$settings=false){
	
	if($settings==false){
		//$settings = array('SMTPhost'=>'localhost', 'SMTPport'=>'25', 'SMTPuser'=>'to@.in', 'SMTPpass'=>'2@mk.in');
		$settings = array('SMTPhost'=>'localhost', 'SMTPport'=>'587', 'SMTPuser'=>'to@.in', 'SMTPpass'=>'2@mk.in');
	}
	
	$mail = new PHPMailer;
	//$mail->SMTPDebug = 2;
	$mail->CharSet = 'UTF-8';
	$mail->addCustomHeader('mailed-by','.in');
	$mail->addCustomHeader('signed-by','jpss.in');
	
	$mail->isSMTP();
	$mail->SMTPAuth = true;	
	$mail->SMTPSecure = 'tls';
	$mail->Host = $settings['SMTPhost'];
	$mail->Port = $settings['SMTPport'];//TCP port to connect,tls=587, ssl=465
	$mail->Username = $settings['SMTPuser'];
	$mail->Password = $settings['SMTPpass'];
	
	$mail->From = 'to@.in';
	$mail->FromName = $fromName;	
	
	$mail->addReplyTo('noreply@.in', 'Information');
	$mail->isHTML(true);
	$mail->Subject = $subject;
	$mail->Body    = $body;
	$mail->AltBody = $alt_body;
	
	if(is_array($to)){ foreach($to as $to2){$mail->addAddress("$to2"); }
	}else{ $mail->addAddress("$to", "$to_user_name"); }
	if($attachment!=false){
		foreach($attachment as $attach){
			$mail->addAttachment("$attach");
		}
	}	
	return $mail->send()?true:'Mailer Error: '.$mail->ErrorInfo;
}