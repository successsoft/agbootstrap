<?php
session_start();
include"../../config.php";

function sanitize($input,$parentKey=null){
    foreach($input as $var=>$val) {
        if(!is_array($val)){
            $value=mysql_real_escape_string($val);
			if($parentKey==null){$GLOBALS[$var]=$value;}
			else{$GLOBALS[$parentKey][$var]=$value;}
        }else{sanitize($val,$var);}
    }
}
function op($a){ die(json_encode($a)); }
function getPageDatas($data){
	$religion=$caste=$language=$services=array();	
	$where="";
	if($data!='all'){$where="where name='$data'";}
	
	$qry=mysql_query("select * from formdata $where order by value");
	while( $row=mysql_fetch_assoc($qry) ){
		if($row['name']=='caste'){
			array_push($$row['name'],array('label'=>$row['value'], 'parent'=>(int)$row['parent']));
		}else{
			array_push($$row['name'],array('label'=>$row['value'], 'id'=>(int) $row['id'], 'photo'=>$row['photo']));
		}
	}	
	if($data=='all'){
		return array('religion'=>$religion,'language'=>$language,'caste'=>$caste,'services'=>$services);
	}
	return $$data;
}
if(strtolower($_SERVER['CONTENT_TYPE'])=='application/json;charset=utf-8'){	
	$jsInput=json_decode(file_get_contents("php://input"),1);sanitize($jsInput);}
else{sanitize($_POST);}

if($action=='login'){	
	$op=false;
	$qry = mysql_query("select username, password from admin where username='$username' and password='$password'");
	if(mysql_num_rows($qry)=='1'){
		$_SESSION['userloged']=$op=true;
	}
	op(array('op'=>$op));
}

//if(!$_SESSION['userloged']){die(op(array('userLoged'=>false)));}

if($action=='getPageDatas'){op(getPageDatas('all'));}
elseif( in_array($action, array('addLanguage','addReligion','addCaste','addService')) ){
	if(!isset($parent)){ $parent=0; }	
	if(mysql_query("insert into formdata (name,value,parent) values ('$data','$value','$parent')")){
		op(array('m'=> ucfirst($data).' Added', "$data"=>getPageDatas($data)));
	}else{ op(array('m'=>mysql_error())); }
}
elseif( in_array($action, array('delLanguage','delReligion','delService')) ){
	if(mysql_query("delete from formdata where name='$data' and value='$value'")){
		op(array('m'=> ucfirst($data).' Deleted', "$data"=>getPageDatas($data)));
	}else{ op(array('m'=>mysql_error())); }
}
elseif( in_array($action, array('updLanguage','updReligion','updService')) ){
	if(mysql_query("update formdata set value='$value' where name='$data' and value='$oldValue' ")){
		op(array('m'=> ucfirst($data).' Updated', "$data"=>getPageDatas($data)));
	}else{ op(array('m'=>mysql_error()));	}
}
elseif($action=='loadContent'){
	$result = mysql_query("SELECT content FROM contents WHERE id='$id'");
	@mysql_query("SET NAMES 'utf8'",1);
	if($row = mysql_fetch_array($result)){
		$returnValue = htmlspecialchars_decode( $row["content"] , ENT_QUOTES);
		op(array('m'=>$returnValue));
	}
}
elseif($action=='updateContent'){
	$htmlcontent  = htmlspecialchars($content);
	@mysql_query("SET NAMES 'utf8'",$id);
	$msg=mysql_query("UPDATE contents SET content='$htmlcontent' WHERE id='$id'")?'Content Updated':mysql_error();
	op(array('m'=>$msg));
}
elseif($action=='getMemberInfo'){
	$qry=mysql_query("select * from user where id='$userId'");
	op(mysql_fetch_assoc($qry));
}
elseif($action=='getAdvertisersInfo'){
	$qry=mysql_query("select * from advertisers where id='$advId'");
	op(mysql_fetch_assoc($qry));
}
elseif($action=='getEnquiryList'){
    
    $msg=mysql_query("UPDATE enquiry SET status='V' WHERE ad_id='$advId' AND eq_for = 'E'")?'Content Updated':mysql_error();
    $qry=mysql_query("select * from enquiry where ad_id = '$advId' AND eq_for = 'E'");
	if(mysql_num_rows($qry) > 0){
        while( $row = mysql_fetch_assoc($qry)){
            $result['id'] = $row['id'];
            $result['eq_name'] = $row['eq_name'];
            $result['eq_email_id'] = $row['eq_email_id'];
            $result['eq_mobile_no'] = $row['eq_mobile_no'];
            $result['eq_comment'] = $row['eq_comment'];
            $result['area'] = $row['area'];
            $result['pincode'] = $row['pincode'];
            $result['date'] = date('d-M-Y',strtotime($row['created']));
            $output[] = $result;
        }
        $response_array['error'] = false;
        $response_array['msg'] = $output;
	}else{
	   $response_array['error'] = true;
	}
    op($response_array);
}
elseif($action=='getCommentList'){
    $msg=mysql_query("UPDATE enquiry SET status='V' WHERE ad_id='$advId' AND eq_for = 'C'")?'Content Updated':mysql_error();
    $qry=mysql_query("select * from enquiry where ad_id = '$advId' AND eq_for = 'C'");
	if(mysql_num_rows($qry) > 0){
        while( $row = mysql_fetch_assoc($qry)){
            $result['id'] = $row['id'];
            $result['eq_name'] = $row['eq_name'];
            $result['eq_email_id'] = $row['eq_email_id'];
            $result['eq_mobile_no'] = $row['eq_mobile_no'];
            $result['eq_comment'] = $row['eq_comment'];
            $result['eq_mobile_no'] = $row['eq_mobile_no'];
            $result['date'] = date('d-M-Y',strtotime($row['created']));
            $output[] = $result;
        }
        $response_array['error'] = false;
        $response_array['msg'] = $output;
	}else{
	   $response_array['error'] = true;
	}
    op($response_array);
} 
elseif($action=='membershipUpdate'){	
	$array=array('matid','paymode','activationDate','plan','duration','amount','bank','description');
	$cols =implode(',',$array);
	$vals=array();	
	$duration = date('Y-m-d', strtotime('+'.$duration.' days'));
	foreach($array as $key){ array_push($vals,"'".$$key."'"); }
	$vals=implode(',',$vals);
	if(mysql_query("insert into payments ($cols) values ($vals)")){
		if(mysql_query("update user set membership='$plan', expire='$duration', approved=1 where matid='$matid'")){
			$op='Membership Updated';
		}else{ $op=mysql_error(); }
	}else{ $op=mysql_error(); }
	op(array('m'=>$op));
}
?>