<?php
	include'config.php';
	$languages = explode(',',file_get_contents('languages.json'));
	foreach($languages as $language){
		mysql_query("insert into formdata (name,parent,value) VALUES ('language','0','$language')");
	}
?>