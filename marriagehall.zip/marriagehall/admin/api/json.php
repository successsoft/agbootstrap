<?php
require( '../../config.php' ); 
require( 'ssp.class.php' );
if(isset($_POST['action'])){
	$primaryKey = 'id';
	if($_POST['action']=='members'){
		$table = 'user';
		$columns = array(
			array('db'=>'id', 'dt'=>'id', 'formatter'=>function($d,$row){return '<a class="btn_icon _vm"><i class="mdi mdi-plus"></i></a>';}),			
			array('db'=>'matid', 'dt'=>'matId'),
			array('db'=>'name', 'dt'=>'name'),
			array('db'=>'email', 'dt'=>'email'),
			array('db'=>'gender', 'dt'=>'gender'),
			array('db'=>'registered', 'dt'=>'registered'),
			array('db'=>'membership', 'dt'=>'membership'),
			array('db'=>'approved', 'dt'=>'status','formatter'=>function($d,$row){
			    $id = $row['id'];
				$label='Active'; $cls='label-success';
				if($d=='0'){ $label='Not Active'; $cls='label-danger';}
				return '<a ng-click="statusClick('.$id.','.$d.')" class="label '.$cls.'">'.$label.'</a>';
				
			}),
			array('db'=>'id', 'dt'=>'action',
				'formatter' => function( $d, $row ) {
					return '
					<a ng-click="deleteMember('.$d.')" class="btn_icon"><i class="mdi mdi-delete-forever"></i></a>
					<a ng-click="viewMore('.$d.')" class="btn_icon"><i class="mdi mdi-dots-vertical"></i></a>';
				})
		);
		
		echo json_encode( SSP::simple($_POST, $sql_details, $table, $primaryKey, $columns));
	}	
	elseif($_POST['action']=='advertisers'){
		$table = 'advertisers';
		$columns = array(
			array('db'=>'id', 'dt'=>'id', 'formatter'=>function($d,$row){return '<a class="btn_icon _vm"><i class="mdi mdi-plus"></i></a>';}, 'tb' => $table),			
			array('db'=>'name', 'dt'=>'name'),
			array('db'=>'company', 'dt'=>'company'),
			array('db'=>'service', 'dt'=>'service'),
			array('db'=>'city', 'dt'=>'city'),
			array('db'=>'pin', 'dt'=>'pin'),
			array('db'=>'payment', 'dt'=>'payment','formatter'=>function($d, $row){
                if($d=='CA'){ return 'Cash'; }
				elseif($d=='CQ'){ return 'Cheque'; }
                else{ return '-';}
			}),
            array('db'=>'approved', 'dt'=>'status','formatter'=>function($d, $row){
                $id = $row['id'];
                $label='Active'; $cls='label-success';
				if($d=='0'){ $label='Not Active'; $cls='label-danger';}
				return '<a ng-click="statusClick('.$id.','.$d.')" class="label '.$cls.'">'.$label.'</a>';
			}),
			array('db'=>'id', 'dt'=>'action','formatter'=>function($d, $row){
                $action = '<a ng-click="deleteAdv('.$d.')" class="btn_icon"><i class="mdi mdi-delete-forever"></i></a>';
                
                $textmore = '';
                if($row['enquiryCount'] != 0 && $row['enquiryCount'] != null){
                    $textmore = 'text-warning';
                }
                $action .= '<a ng-click="viewMore('.$d.')" class="btn_icon"><i class="mdi mdi-eye '.$textmore.'"></i></a>';
                $textComment = '';
                if($row['commentCount'] != 0 && $row['commentCount'] != null){
                    $textComment = 'text-warning';
                }
                $action .= '<a ng-click="viewComments('.$d.')" class="btn_icon"><i class="mdi mdi-comment-text '.$textComment.'"></i></a>';
                $action .= '<a ng-click="viewImage('.$d.')" class="btn_icon"><i class="mdi mdi-dots-vertical"></i></a>';
                return $action;
			}, 'tb' => $table),
			array('db'=>'address', 'dt'=>'address'),
            array('db'=>'area', 'dt'=>'area' , 'tb' => $table),
			array('db'=>'state', 'dt'=>'state'),
			array('db'=>'email', 'dt'=>'email'),
			array('db'=>'contact', 'dt'=>'contact'),
            array('db'=>'description',  'dt'=>'description'),
            array('db'=>'title1', 'dt'=>'title1'),
            array('db'=>'description1', 'dt'=>'description1'),
            array('db'=>'title2', 'dt'=>'title2'),
            array('db'=>'description2', 'dt'=>'description2'),
            array('db'=>'title3', 'dt'=>'title3'),
            array('db'=>'description3', 'dt'=>'description3'),
            array('db'=>'photo1', 'dt'=>'photo1'),
            array('db'=>'photo2', 'dt'=>'photo2'),
            array('db'=>'photo3', 'dt'=>'photo3'),
            array('db'=>'photo1a', 'dt'=>'photo1a'),
            array('db'=>'photo2a', 'dt'=>'photo2a'),
            array('db'=>'photo3a', 'dt'=>'photo3a'),
            array('db'=>'created', 'dt'=>'created', 'tb' => $table),
            array('db'=>'SUM( eq_for =  "C" )', 'dt'=>'commentCount', 'as'=>'commentCount'),
            array('db'=>'SUM( eq_for =  "E" )', 'dt'=>'enquiryCount', 'as'=>'enquiryCount')
		);
		
		//echo json_encode( SSP::simple($_POST, $sql_details, $table, $primaryKey, $columns));
        
        $joinTable = "LEFT JOIN  `enquiry` ON  `advertisers`.id =  `enquiry`.ad_id AND STATUS =  'NV'";
        $groupBy = "GROUP BY  `advertisers`.id";
        
        $primaryKey = "advertisers.id";
        echo json_encode( SSP::simpleJoin($_POST, $sql_details, $table, $joinTable, $primaryKey, $columns, $groupBy));
	}	
	elseif($_POST['action']=='agents'){
		$table = 'agent';
		$columns = array(
			array('db'=>'id', 'dt'=>'agentid', 'formatter'=>function($d,$row){ return 'AG'.$d;}),			
			array('db'=>'name', 'dt'=>'name'),
			array('db'=>'address', 'dt'=>'address'),
			array('db'=>'contact', 'dt'=>'contact'),
			array('db'=>'email', 'dt'=>'email'),			
			array('db'=>'approved', 'dt'=>'status','formatter'=>function($d,$row){
				$id = $row['id'];
                $label='Active'; $cls='label-success';
				if($d=='0'){ $label='Not Active'; $cls='label-danger';}
				return '<a ng-click="statusClick('.$id.','.$d.')" class="label '.$cls.'">'.$label.'</a>';
			}),
			array('db'=>'id', 'dt'=>'action','formatter'=>function($d,$row){
				return '
				<a ng-click="deleteAgent('.$d.')" class="btn_icon"><i class="mdi mdi-delete-forever"></i></a>
				<a ng-click="viewMore('.$d.')" class="btn_icon"><i class="mdi mdi-dots-vertical"></i></a>';
			}),
			
		);
		
		echo json_encode( SSP::simple($_POST, $sql_details, $table, $primaryKey, $columns));
	}
	elseif($_POST['action']=='comments'){
		$table = 'enquiry';
		$columns = array(
			array('db'=>'eq_name', 'dt'=>'eq_name'),
			array('db'=>'eq_email_id', 'dt'=>'eq_email_id'),
			array('db'=>'eq_mobile_no', 'dt'=>'eq_mobile_no'),
            array('db'=>'eq_comment', 'dt'=>'eq_comment'),				
			array('db'=>'status', 'dt'=>'status','formatter'=>function($d,$row){
				if($d=='V'){ 
				    return 'Viewed';
                }else{
                    return 'Not Viewed';
                }
			}),
			array('db'=>'id', 'dt'=>'action','formatter'=>function($d,$row){
				return '
				<a ng-click="deleteAgent('.$d.')" class="btn_icon"><i class="mdi mdi-delete-forever"></i></a>
				<a ng-click="viewMore('.$d.')" class="btn_icon"><i class="mdi mdi-dots-vertical"></i></a>';
			}, 'tb' => $table),
            array('db'=>'name', 'dt'=>'name'),
            array('db'=>'company', 'dt'=>'company'),
			
		);
		
		$joinTable = "LEFT JOIN  `advertisers` ON  `enquiry`.ad_id = `advertisers`.id";
        $primaryKey = "enquiry.id";
        $where = "eq_for = 'C'";
        echo json_encode( SSP::simpleJoin($_POST, $sql_details, $table, $joinTable, $primaryKey, $columns, '', $where));
	}
	elseif($_POST['action']=='enquiry'){
		$table = 'enquiry';
		$columns = array(
			array('db'=>'eq_name', 'dt'=>'eq_name'),
			array('db'=>'eq_email_id', 'dt'=>'eq_email_id'),
			array('db'=>'eq_mobile_no', 'dt'=>'eq_mobile_no'),
            array('db'=>'eq_comment', 'dt'=>'eq_comment'),				
			array('db'=>'status', 'dt'=>'status','formatter'=>function($d,$row){
				if($d=='V'){ 
				    return 'Viewed';
                }else{
                    return 'Not Viewed';
                }
			}),
			array('db'=>'id', 'dt'=>'action','formatter'=>function($d,$row){
				return '
				<a ng-click="deleteAgent('.$d.')" class="btn_icon"><i class="mdi mdi-delete-forever"></i></a>
				<a ng-click="viewMore('.$d.')" class="btn_icon"><i class="mdi mdi-dots-vertical"></i></a>';
			}, 'tb' => $table),
            array('db'=>'name', 'dt'=>'name'),
            array('db'=>'company', 'dt'=>'company'),
			
		);
		
		$joinTable = "LEFT JOIN  `advertisers` ON  `enquiry`.ad_id = `advertisers`.id";
        $primaryKey = "enquiry.id";
        $where = "eq_for = 'E'";
        echo json_encode( SSP::simpleJoin($_POST, $sql_details, $table, $joinTable, $primaryKey, $columns, '', $where));
	}
	else{
		echo json_encode(array('Invalid'));
	}		
}
else{
	echo json_encode(array('Invalid'=>'Invalid'));
}
?>