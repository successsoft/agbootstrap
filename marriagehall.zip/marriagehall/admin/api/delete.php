<?php
session_start();
include"../../config.php";
include"functions.php";
if($action=='uploadUserPicture'){
    //$filehash = hash("crc32b",$email);
    $userDir="../uploads/user/";
    if($action=='deleteUserImage'){
    	unlink($userDir.$file);
    	if(mysql_query("update user set photo{$id}='', photo{$id}a='0' where email='$email'")){
    		$m=true; $i="photo".$id;
    	}else{ $m=mysql_error(); }
    	op(array('m'=>$m));
    }
}else if($action=='deletAdvertisersImage'){
    $userDir="../../uploads/advertisers/";
    unlink($userDir.$file);
	if(mysql_query("update advertisers set photo{$id}='', photo{$id}a='0' where id='$advId'")){
		$m=true; $i="photo".$id;
	}else{ $m=mysql_error(); }
	op(array('m'=>$m));
    
}else if($action=='deletAdvertisersImage'){
    $userDir="../../uploads/services/";
    unlink($userDir.$file);
	if(mysql_query("update formdata set photo='' where photo='$file'")){
		$m=true; $i="photo".$id;
	}else{ $m=mysql_error(); }
	op(array('m'=>$m));
    
}else if($action=='deleteMember'){
    if(mysql_query("delete from user where id = '$id'")){
		$m=false;
	}else{ $m=true; }
	op(array('m'=>$m));
}else if($action=='deleteAgent'){
    if(mysql_query("delete from agent where id = '$id'")){
		$m=false;
	}else{ $m=true; }
	op(array('m'=>$m));
}else{
    
}