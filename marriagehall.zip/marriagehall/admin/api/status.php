<?php
session_start();
include"../../config.php";
include"functions.php";
if($action=='advertisers'){
    $query = mysql_query("update advertisers set approved = '$status' where id='$advId'") or die(mysql_error()); 
    if($query){
		$m = false;
	}else{ 
	   $m = true; 
    }
	op(array('m'=>$m));
}elseif($action=='members'){
    $query = mysql_query("update user set approved = '$status' where id='$Id'") or die(mysql_error()); 
    if($query){
		$m = false;
	}else{ 
	   $m = true; 
    }
	op(array('m'=>$m));
}elseif($action=='agent'){
    $query = mysql_query("update agent set approved = '$status' where id='$Id'") or die(mysql_error()); 
    if($query){
		$m = false;
	}else{ 
	   $m = true; 
    }
	op(array('m'=>$m));
}else{
    
}
?>
