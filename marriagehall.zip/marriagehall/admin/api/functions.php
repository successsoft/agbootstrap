<?php
function sanitize($input,$parentKey=null){
    foreach($input as $var=>$val) {
        if(!is_array($val)){
            $value=mysql_real_escape_string($val);
			if($parentKey==null){$GLOBALS[$var]=$value;}
			else{$GLOBALS[$parentKey][$var]=$value;}
        }else{sanitize($val,$var);}
    }
}
function op($a){ die(json_encode($a)); }
function getPageDatas($data){
	$religion=$caste=$language=$services=array();	
	$where="";
	if($data!='all'){$where="where name='$data'";}
	
	$qry=mysql_query("select * from formdata $where order by value");
	while( $row=mysql_fetch_assoc($qry) ){
		if($row['name']=='caste'){
			array_push($$row['name'],array('label'=>$row['value'], 'parent'=>(int)$row['parent']));
		}else{
			array_push($$row['name'],array('label'=>$row['value'], 'id'=>(int) $row['id']));
		}
	}
	
	if($data=='all'){
		return array('religion'=>$religion,'language'=>$language,'caste'=>$caste,'services'=>$services);
	}
	return $$data;
}
function generateInsert($array){
	$cols=$vals=array();	
	foreach($array as $key){
		if($GLOBALS[$key]!=''){
			array_push($cols,$key);
			array_push($vals,"'".$GLOBALS[$key]."'");
		}
	}
	$cols=implode(',',$cols);
	$vals=implode(',',$vals);
	return ['c'=>$cols, 'v'=>$vals];
}
function getMember($table,$email){
	$qry=mysql_query("select * from $table where email='$email'");
	$row = mysql_fetch_assoc($qry);
	unset($row['password']);
	return $row;
}
function emailExist($table,$email){
	$qry=mysql_query("select email from $table where email='$email'");
	return mysql_num_rows($qry)>='1';
}
function insert($t,$c,$v){
	return mysql_query("insert into $t ($c) values ($v)")?true:mysql_error();
}
if(strtolower($_SERVER['CONTENT_TYPE'])=='application/json;charset=utf-8'){	
	$jsInput=json_decode(file_get_contents("php://input"),1);sanitize($jsInput);}
else{sanitize($_POST);}