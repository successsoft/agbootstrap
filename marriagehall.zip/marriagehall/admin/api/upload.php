<?php
session_start();
if(!isset($_SESSION['userloged'])){ die('Invalid Access'); }

include "../../config.php";
include "imageEditor.php";
include "functions.php";

//print_r($_SESSION);die;
if($action=='uploadUserPicture'){
    //[type] => user [type] => advertisers
    
	
	$file_name = $_FILES['file']['name'];
	$file_tmp = $_FILES['file']['tmp_name'];
	
	$ext = pathinfo($file_name, PATHINFO_EXTENSION);
	$newfilename = hash("crc32b",$email).$count.".$ext";
    $location='../uploads/user/'.$newfilename;
	if(move_uploaded_file($file_tmp,$location)){		
		img_resize($location,$location,'400','400',$ext);
		if(mysql_query("update user set photo$count='$newfilename', photo".$count."a='0' where id='$userId'")){
			op(array('m'=>true,'img'=>$newfilename));
		}else{ op(array('m'=>mysql_error())); }
	}
}else if($action=='uploadAdvPicture'){
    
    //echo $advId;die;
    $query = mysql_query("SELECT email FROM advertisers WHERE id='$advId'");
    $advResult = mysql_fetch_assoc($query);
    //print_r($advResult);die;
    $email = $advResult['email'];
    
	$file_name = $_FILES['file']['name'];
	$file_tmp = $_FILES['file']['tmp_name'];
	
	$ext = pathinfo($file_name, PATHINFO_EXTENSION);
	$newfilename = hash("crc32b",$email).$count.".$ext";
    $location='../../uploads/advertisers/'.$newfilename;
	if(move_uploaded_file($file_tmp,$location)){		
		img_resize($location,$location,'400','400',$ext);
		if(mysql_query("update advertisers set photo$count='$newfilename', photo".$count."a='0' where id='$advId'")){
			op(array('m'=>true,'img'=>$newfilename));
		}else{ op(array('m'=>mysql_error())); }
	}
}else if($action=='uploadAdvPhoto'){
    //print_r($_SESSION);die;
    $id = $_SESSION['userloged'];
    $query = mysql_query("SELECT username FROM admin WHERE id='$id'");
    $userResult = mysql_fetch_assoc($query);
    //print_r($advResult);die;
    $username = $userResult['username'];
    
	$file_name = $_FILES['file']['name'];
	$file_tmp = $_FILES['file']['tmp_name'];
	
	$ext = pathinfo($file_name, PATHINFO_EXTENSION);
	$newfilename = hash("crc32b",$selService).".$ext";
    $location='../../uploads/services/'.$newfilename;
	if(move_uploaded_file($file_tmp,$location)){		
		img_resize($location,$location,'250','98',$ext);
		if(mysql_query("update formdata set photo='$newfilename' where value='$selService'")){
			op(array('m'=>true,'img'=>$newfilename));
		}else{ 
            op(array('m'=>mysql_error())); 
        }
	}
}else{
    
}
