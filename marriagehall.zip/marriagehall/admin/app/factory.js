app.factory('toast',function($timeout){
    return function(m){
        var toast = angular.element('<div class="toast">'+m+'</div>');
        angular.element('.toaster').append(toast);
        $timeout(function() {
            toast.remove();
        }, 4000);
        toast.click(function(){toast.remove();})
    }
});