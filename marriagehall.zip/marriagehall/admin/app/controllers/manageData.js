app.controller('dataCtrl',function($scope, $rootScope, $http, $timeout, toast, Upload){
    
    function array_lower(a){
        var op=[];
        if(angular.isArray(a)){
            angular.forEach(a,function(i){
                op.push(i.label.toLowerCase());
            });
        } return op;
    }
    $scope.fData={newVal:'',selected:'',rename:''};
    $scope.is_newVal_valid=false;
    $scope.is_rename_valid=false;
    $scope.$watch('fData.newVal', function(n) {
        if(n==''){ $scope.is_newVal_valid=true; }
        else if($scope.lower_array.length >= 0){
            $scope.is_newVal_valid = $scope.lower_array.indexOf(n.toLowerCase())>=0;
        }
    });
    $scope.$watch('fData.rename', function(n) {
        if(n=='' || $scope.fData.selected==''){$scope.is_rename_valid=true;}
        else{ $scope.is_rename_valid = $scope.lower_array.indexOf(n.toLowerCase())>=0; }
    });
    
    //console.log($rootScope.languages)
    
    $scope.inMode='language';
    var lang_a=['addLanguage','delLanguage','updLanguage'];
    var religion_a=['addReligion','delReligion','updReligion'];
    var caste_a=['addCaste','delCaste','updCaste'];
    var serve_a=['addService','delService','updService'];

    $scope.language={'label':'language','add':lang_a[0],'del':lang_a[1],'upd':lang_a[2],'data':$rootScope.languages};
    $scope.services={'label':'services','add':serve_a[0],'del':serve_a[1],'upd':serve_a[2],'data':$rootScope.services};

    $scope.religion={'label':'religion','add':religion_a[0],'del':religion_a[1],'upd':religion_a[2],'data':$rootScope.religion};
    $scope.caste={'label':'caste','add':caste_a[0],'del':caste_a[1],'upd':caste_a[2],'data':$rootScope.religion};
    
    
    $scope.mode=$scope.language;
    $scope.lower_array = array_lower($scope.mode.data);

    //console.log($scope.lower_array);

    $scope.editableFruitNames=['Apple', 'Banana', 'Orange'];
    
    $scope.modeCaste=false;
    $scope.modeService=false;
    $scope.updateMode=function(m){
        $scope.modeCaste=false;
        $scope.modeService=false
        $scope.mode = $scope[m];
        //console.log($scope.mode);
        $scope.fData={rename:'',selected:'',newVal:''};
        if(m=='caste'){
            $scope.modeCaste=true;
        }
        if(m=='services'){
            $scope.modeService=true;
        }
        
        if($scope.mode.data === undefined){
            modeData = $rootScope.m
        }else{
            modeData = $scope.mode.data
        }
        
        $scope.lower_array = array_lower( modeData );
        //$scope.validNew($scope.pro.product,'');
    };

    $scope.selectedParent='';
    $scope.fillValue=function(n,s){
        $scope.selService = n
        if(['language','religion','services'].indexOf($scope.mode.label)>=0 || angular.isDefined(s)){
            $scope.fData.rename=n;
            $scope.selectedParent = jQuery('.__parent_selector option:selected').data('parent');
        }
        else{
            var religion = $rootScope.religion, caste = $rootScope.caste, output=[];
            for(var i=0;i<religion.length;i++){ if(religion[i].label === n){var ind=i;break;} }
            for(i=0; i<caste.length; i++){
                if(caste[i]['parent']==religion[ind]['id']){
                    output.push(caste[i].label);
                }
            }
            $scope.castes=output;
        }
        
        //console.log($scope.inMode)
        if($scope.inMode == 'services'){
            $scope.serdata = $scope['services'];
            $.each($scope.serdata.data, function(index, value){
                if(value.label == n){
                    //console.log(value.photo)
                    $scope.fData.photo = value.photo;
                } 
            });
        }
    };
    
    
    $scope.CRUD=function(a,l,d) {
        d.action=a;
        d.data=l;

        if(caste_a.indexOf(a)>=0){ d.parent=$scope.selectedParent; }
        //else if(sup_a.indexOf(a)>=0){d.dtype='Supplier';}

        $http.post('api/',d).then(function(r){
            var a = angular.isDefined(r.data.language);
            var b = angular.isDefined(r.data.religion);
            var c = angular.isDefined(r.data.caste);
            var e = angular.isDefined(r.data.services);
            if(a){$scope.mode.data=$rootScope.language= r.data.language;}
            if(b){$scope.mode.data=$rootScope.religion=r.data.religion;}
            if(e){$scope.mode.data=$rootScope.services=r.data.services;}


            if(a || b || e){
                $scope.lower_array = array_lower($scope.mode.data);
                $scope.fData.selected='';
                $scope.fData.rename='';
            }

            toast(r.data.m);

            if(['addLanguage','addReligion','addCaste','addService'].indexOf(d.action) >= 0){
                $scope.fData.newVal='';
            }
            /*if( r.data.m=='Product Updated' ){
                Object.defineProperty($rootScope.stocks, d.newName,
                    Object.getOwnPropertyDescriptor($rootScope.stocks, d.oldName));
                delete $rootScope.stocks[d.oldName];
            }*/
        });
    };
    
    $scope.$watch('img', function () { $scope.uploadFiles($scope.img); });
    $scope.uploadFiles = function(file) {
        $scope.f = file;
        //console.log( $scope.selService )
        if( $scope.selService ){
            if (file) {
                jQuery('#upProgress').show();
                file.upload=Upload.upload({url:'api/upload',data:{file:file,action:'uploadAdvPhoto',selService: $scope.selService}});
    
                file.upload.then(function (response) {
                    if(response.data.m===true){
                        var img = response.data.img;
                        $scope.fData['photo']=img;
                   }
                    $timeout(function(){
                        jQuery('#upProgress').hide();
                    },1000);
                }, function (response) {
                    if (response.status > 0)
                        $scope.errorMsg = response.status + ': ' + response.data;
                }, function (evt) {
                    file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
                });
            }
        }   
    }
    
    $scope.deleteImg = function(fileName){
        $http.post('api/delete',{action:'deletServiceImg',file:fileName}).then(function(r){
            if(r.data.m===true){
                $rootScope.fData['photo']='';
                $rootScope.fData['photo']='0';
                $scope.fData['photo']='';
                $scope.fData['photo']='0';
            }else{alert(r.data.m)}
        });
    };
});