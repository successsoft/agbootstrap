app.controller('commentsCtrl',function($scope, $http, $compile, $uibModal){
    var vis='_MENU_ <span class="hidden-xs">Records | </span><a class="btn btn-primary btn-sm" id="commentsTable">Refresh</a>';
    $scope.commentsTable = jQuery('#comments').DataTable({
        "ajax":{"data":function(d){
            d.action="comments";
        }},
        "columns":[
            {"data":"eq_name"},
            {"data":"eq_email_id"},
            {"data":"eq_mobile_no"},
            {"data":"eq_comment"},
            {"data":"status"},
            {"data":"name"},
            {"data":"company"}
        ],
        "language": { "lengthMenu": vis},
    });
    $('#commentsTable').click(function(){ $scope.commentsTable.ajax.reload(); });
    
    $scope.statusClick = function(id, status){
        if(status == 0){
            status = 1;
        }else{
            status = 0;
        }
        $http.post('api/status',{action:'comment', Id: id, status: status}).then(function(r){
            var data = r.data;
            if(data.m == false){
                $('#alert-msg').removeClass('alert-danger');
                $('#alert-msg').addClass('alert-success');
                
                $scope.strongMsg = "Success: ";
                $scope.spanMsg = "Status updated successfully...";
                $scope.alertMsg = true
                 
            }else{
                $('#alert-msg').removeClass('alert-success');
                $('#alert-msg').addClass('alert-danger');
                
                $scope.strongMsg = "Error: ";
                $scope.spanMsg = "Status updated failed...";
                $scope.alertMsg = true
            }
            $scope.commentsTable.ajax.reload();
        });
    };
    
    $scope.deleteAgent = function(id){
        var modalInstance = $uibModal.open({
            templateUrl: 'myModalContent.html',
            controller: 'deleteAgentCtrl',
            size: 'md',
            resolve:{items:function(){return id;}}
        });

        modalInstance.result.then(function(){

        },function(){});
    };
    
    $scope.close = function () {
        $scope.alertMsg = false
    };
});

app.controller('deleteAgentCtrl', function($scope, $rootScope, $http, $compile, $uibModalInstance, items, toast ) {
    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
    $scope.close = function () {
        $scope.alertMsg = false
    };
    
    $scope.del = function(){
        $http.post('api/delete',{action:'deleteAgent',id:items}).then(function(r){
            var data = r.data;
            if(data.m == false){
                $('#alert-msg').removeClass('alert-danger');
                $('#alert-msg').addClass('alert-success');
                
                $scope.strongMsg = "Success: ";
                $scope.spanMsg = "Deleted successfully...";
                $scope.alertMsg = true
                 
            }else{
                $('#alert-msg').removeClass('alert-success');
                $('#alert-msg').addClass('alert-danger');
                
                $scope.strongMsg = "Error: ";
                $scope.spanMsg = "Deletion failed...";
                $scope.alertMsg = true
            }
            $uibModalInstance.dismiss('cancel');
            $('#comments').dataTable().fnDraw();
        });
    }
});