app.controller('cmsCtrl',function($scope,$http){
    jQuery("textarea#contentEditor").ckeditor();
    $scope.editor = CKEDITOR.instances.contentEditor;

    $scope.loadContent=function (page) {
        $http.post('api/',{action:'loadContent',id:page}).then(function(r){
            $scope.editor.setData(r.data.m);
        });
    };

    $scope.updateContent=function(){
        var content = $scope.editor.getData();
        $http.post('api/',{action:'updateContent',id:$scope.page,content:content}).then(function(r){
            alert(r.data.m);
        });
    };
});