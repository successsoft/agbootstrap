app.controller('membersCtrl',function ($scope, $compile, $http, $uibModal) {
    var vis='_MENU_ <span class="hidden-xs">Records | </span><a class="btn btn-primary btn-sm" id="membersTable">Refresh</a>';
    $scope.membersTable = jQuery('#members').DataTable({
        "ajax":{"data":function(d){d.action="members";}},
        "columns":[
            {"data":"id"},
            {"data":"matId"},
            {"data":"name"},
            {"data":"gender"},
            {"data":"email"},
            {"data":"registered"},
            {"data":"membership"},
            {"data":"status"},
            {"data":"action",orderable: false}],
        "language": { "lengthMenu": vis},
        "fnRowCallback": function(nRow){
            return angular.element($compile(nRow)($scope));
        },
        "fnDrawCallback": function (){
            $('._COLVIS li').each(function(){
                var h = $(this).children('a').attr('href');
                var column = $scope.purchseOrderTable.column(h);
                if(column.visible()){$(this).addClass('active');}else{$(this).removeClass('active');}
            });
        }
    });
    $('#membersTable').click(function() { $scope.membersTable.ajax.reload(); });

    function format ( d ) {
        return '<table class="table-condensed">'+
            '<tr>'+
            '<td>Full name:</td>'+
            '<td>'+d.name+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Extension number:</td>'+
            '<td>'+d.email+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Extra info:</td>'+
            '<td>And any further details here (images etc)...</td>'+
            '</tr>'+
            '</table>';
    }
    jQuery('#members tbody').on('click', '._vm', function () {
        var tr = $(this).closest('tr');
        var row = $scope.membersTable.row(tr);
        if(row.child.isShown()){row.child.hide(200);tr.removeClass('shown');}
        else{row.child( format(row.data()) ).show(200);tr.next('tr').addClass('_newlyOpendRow');}
    });

    $scope.viewMore = function(id){
        var modalInstance = $uibModal.open({
            templateUrl: 'app/tpl/userInfo.html',
            controller: 'ModalInstanceCtrl',
            size:'lg',
            resolve:{items:function(){return id;}}
        });

        modalInstance.result.then(function(){

        },function(){});
    };
    
    $scope.statusClick = function(id, status){
        if(status == 0){
            status = 1;
        }else{
            status = 0;
        }
        $http.post('api/status',{action:'members', Id: id, status: status}).then(function(r){
            var data = r.data;
            if(data.m == false){
                $('#alert-msg').removeClass('alert-danger');
                $('#alert-msg').addClass('alert-success');
                
                $scope.strongMsg = "Success: ";
                $scope.spanMsg = "Status updated successfully...";
                $scope.alertMsg = true
                 
            }else{
                $('#alert-msg').removeClass('alert-success');
                $('#alert-msg').addClass('alert-danger');
                
                $scope.strongMsg = "Error: ";
                $scope.spanMsg = "Status updated failed...";
                $scope.alertMsg = true
            }
            $scope.membersTable.ajax.reload();
        });
    };
    
    $scope.deleteMember = function(id){
        var modalInstance = $uibModal.open({
            templateUrl: 'myModalContent.html',
            controller: 'deleteMemberCtrl',
            size: 'md',
            resolve:{items:function(){return id;}}
        });

        modalInstance.result.then(function(){

        },function(){});
    };
    $scope.close = function () {
        $scope.alertMsg = false
    };
});

app.controller('deleteMemberCtrl', function($scope, $rootScope, $http, $compile, $uibModalInstance, items, toast ) {
    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
    $scope.close = function () {
        $scope.alertMsg = false
    };
    
    $scope.del = function(){
        $http.post('api/delete',{action:'deleteMember',id:items}).then(function(r){
            var data = r.data;
            if(data.m == false){
                $('#alert-msg').removeClass('alert-danger');
                $('#alert-msg').addClass('alert-success');
                
                $scope.strongMsg = "Success: ";
                $scope.spanMsg = "Deleted successfully...";
                $scope.alertMsg = true
                 
            }else{
                $('#alert-msg').removeClass('alert-success');
                $('#alert-msg').addClass('alert-danger');
                
                $scope.strongMsg = "Error: ";
                $scope.spanMsg = "Deletion failed...";
                $scope.alertMsg = true
            }
            $uibModalInstance.dismiss('cancel');
            $('#members').dataTable().fnDraw();
        });
    }
});

app.controller('ModalInstanceCtrl',function($scope,$http,$uibModalInstance,userLabel,items,toast) {
    $scope.userLabel={
        left:{
            'Basic Informations':userLabel['Basic Informations'],
            'Socio Religious Attributes':userLabel['Socio Religious Attributes'],
            'Education and Occupation':userLabel['Education and Occupation'],
            'Physical Attributes':userLabel['Physical Attributes'],
            'Contact Details':userLabel['Contact Details']
        },
        right:{
            'Family Details':userLabel['Family Details'],
            "Father's Details":userLabel["Father's Details"],
            "Mother's Details":userLabel["Mother's Details"],
            'Profile Details':userLabel['Profile Details'],
            'Partner Preference':userLabel['Partner Preference'],
            'Hobbies and Interests':userLabel['Hobbies and Interests']
        }
    };
    $http.post('api/',{action:'getMemberInfo',userId:items}).then(function(r){
        $scope.dbDatas = r.data;
    });
    $scope.default={
        paymode:'Cash',
        plan: 'Silver',
    };
    angular.copy($scope.default,$scope.C2PM);
    $scope.aJX=function(d,a){
        d.action=a;
        d.matid = $scope.dbDatas.matid;
        $http.post('api/',d).then(function(r){
            toast(r.data.m);
            if(r.data.m=='Membership Updated'){
                $scope.C2PM = $scope.default;
            }
        });
    };
    $scope.ok = function () {
        $uibModalInstance.close($scope.selected.item);
    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
});