app.controller('agentsCtrl',function($scope, $http, $compile, $uibModal){
    var vis='_MENU_ <span class="hidden-xs">Records | </span><a class="btn btn-primary btn-sm" id="agentsTable">Refresh</a>';
    $scope.agentsTable = jQuery('#agents').DataTable({
        "ajax":{"data":function(d){
            d.action="agents";
        }},
        "columns":[
            {"data":"agentid"},
            {"data":"name"},
            {"data":"address"},
            {"data":"contact"},
            {"data":"email"},
            {"data":"status"},
            {"data":"action",orderable: false}],
        "language": { "lengthMenu": vis},
        "fnRowCallback": function(nRow){
            return angular.element($compile(nRow)($scope));
        }
    });
    $('#agentsTable').click(function(){ $scope.agentsTable.ajax.reload(); });
    
    $scope.statusClick = function(id, status){
        if(status == 0){
            status = 1;
        }else{
            status = 0;
        }
        $http.post('api/status',{action:'agent', Id: id, status: status}).then(function(r){
            var data = r.data;
            if(data.m == false){
                $('#alert-msg').removeClass('alert-danger');
                $('#alert-msg').addClass('alert-success');
                
                $scope.strongMsg = "Success: ";
                $scope.spanMsg = "Status updated successfully...";
                $scope.alertMsg = true
                 
            }else{
                $('#alert-msg').removeClass('alert-success');
                $('#alert-msg').addClass('alert-danger');
                
                $scope.strongMsg = "Error: ";
                $scope.spanMsg = "Status updated failed...";
                $scope.alertMsg = true
            }
            $scope.agentsTable.ajax.reload();
        });
    };
    
    $scope.deleteAgent = function(id){
        var modalInstance = $uibModal.open({
            templateUrl: 'myModalContent.html',
            controller: 'deleteAgentCtrl',
            size: 'md',
            resolve:{items:function(){return id;}}
        });

        modalInstance.result.then(function(){

        },function(){});
    };
    
    $scope.close = function () {
        $scope.alertMsg = false
    };
});

app.controller('deleteAgentCtrl', function($scope, $rootScope, $http, $compile, $uibModalInstance, items, toast ) {
    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
    $scope.close = function () {
        $scope.alertMsg = false
    };
    
    $scope.del = function(){
        $http.post('api/delete',{action:'deleteAgent',id:items}).then(function(r){
            var data = r.data;
            if(data.m == false){
                $('#alert-msg').removeClass('alert-danger');
                $('#alert-msg').addClass('alert-success');
                
                $scope.strongMsg = "Success: ";
                $scope.spanMsg = "Deleted successfully...";
                $scope.alertMsg = true
                 
            }else{
                $('#alert-msg').removeClass('alert-success');
                $('#alert-msg').addClass('alert-danger');
                
                $scope.strongMsg = "Error: ";
                $scope.spanMsg = "Deletion failed...";
                $scope.alertMsg = true
            }
            $uibModalInstance.dismiss('cancel');
            $('#agents').dataTable().fnDraw();
        });
    }
});