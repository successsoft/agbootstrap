app.controller('advertisersCtrl',function($scope, $http, $compile, $uibModal){
    var vis='_MENU_ <span class="hidden-xs">Records | </span><a class="btn btn-primary btn-sm" id="advertiserTable">Refresh</a>';
    $scope.advertisersTable = jQuery('#advertisers').DataTable({
        "ajax":{"data":function(d){
            d.action="advertisers";
        }},
        "columns":[
            {"data":"id"},
            {"data":"name"},
            {"data":"company"},
            {"data":"service"},
            {"data":"city"},
            {"data":"pin"},
            {"data":"payment"},
            {"data":"status"},
            {"data":"action",orderable: false}],
        "language": { "lengthMenu": vis},
        "fnRowCallback": function(nRow){
            return angular.element($compile(nRow)($scope));
        },
        "destroy" : true,
        "fnDrawCallback": function (){
            $('._COLVIS li').each(function(){
                var h = $(this).children('a').attr('href');
                var column = $scope.purchseOrderTable.column(h);
                if(column.visible()){$(this).addClass('active');}else{$(this).removeClass('active');}
            });
        }
    });
    $('#advertiserTable').click(function(){ $scope.advertisersTable.ajax.reload(); });

    function format ( d ) {
        return '<table class="table-condensed">'+
            '<tr>'+
            '<td>Address:</td>'+
            '<td>'+d.address+', '+d.city+', '+d.state+', PIN: '+d.pin+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Area:</td>'+
            '<td>'+d.area+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Email:</td>'+
            '<td>'+d.email+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Contact Numbers:</td>'+
            '<td>'+d.contact+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Company Description:</td>'+
            '<td>'+d.description+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Title 1:</td>'+
            '<td>'+d.title1+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Description 1:</td>'+
            '<td>'+d.description1+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Title 2:</td>'+
            '<td>'+d.title2+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Description 2:</td>'+
            '<td>'+d.description2+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Title 3:</td>'+
            '<td>'+d.title3+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Description 3:</td>'+
            '<td>'+d.description3+'</td>'+
            '</tr>'+
            '</table>';
    }
    jQuery('#advertisers tbody').on('click', '._vm', function () {
        var tr = $(this).closest('tr');
        var row = $scope.advertisersTable.row(tr);
        if(row.child.isShown()){row.child.hide(200);tr.removeClass('shown');}
        else{row.child( format(row.data()) ).show(200);tr.next('tr').addClass('_newlyOpendRow');}
    });
    
    $scope.viewImage = function(id){
        var modalInstance = $uibModal.open({
            templateUrl: 'app/tpl/photos.html',
            controller: 'ModalPhotoCtrl',
            size:'lg',
            resolve:{items:function(){return id;}}
        });

        modalInstance.result.then(function(){

        },function(){});
    };
    
    $scope.viewMore = function(id){
        var modalInstance = $uibModal.open({
            templateUrl: 'enquiryModal.html',
            controller: 'ModalEnquiryCtrl',
            size:'lg',
            resolve:{items:function(){return id;}}
        });

        modalInstance.result.then(function(){

        },function(){});
    };
    
    $scope.viewComments = function(id){
        var modalInstance = $uibModal.open({
            templateUrl: 'viewComments.html',
            controller: 'viewCommentsCtrl',
            size: 'md',
            resolve:{items:function(){return id;}}
        });

        modalInstance.result.then(function(){

        },function(){});
    };
    
    $scope.deleteAdv = function(id){
        var modalInstance = $uibModal.open({
            templateUrl: 'myModalContent.html',
            controller: 'deleteCtrl',
            size: 'md',
            resolve:{items:function(){return id;}}
        });

        modalInstance.result.then(function(){

        },function(){});
    };
    
    
    $scope.statusClick = function(id, status){
        if(status == 0){
            status = 1;
        }else{
            status = 0;
        }
        $http.post('api/status',{action:'advertisers',advId: id, status: status}).then(function(r){
            var data = r.data;
            if(data.m == false){
                $('#alert-msg').removeClass('alert-danger');
                $('#alert-msg').addClass('alert-success');
                
                $scope.strongMsg = "Success: ";
                $scope.spanMsg = "Status updated successfully...";
                $scope.alertMsg = true
                 
            }else{
                $('#alert-msg').removeClass('alert-success');
                $('#alert-msg').addClass('alert-danger');
                
                $scope.strongMsg = "Error: ";
                $scope.spanMsg = "Status updated failed...";
                $scope.alertMsg = true
            }
            $scope.advertisersTable.ajax.reload();
        });
    };
    $scope.close = function () {
        $scope.alertMsg = false
    };
    
    
    
});

app.controller('deleteCtrl', function($scope, $rootScope, $http, $compile, $uibModalInstance, items, toast ) {
    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
    $scope.close = function () {
        $scope.alertMsg = false
    };
    
    $scope.del = function(){
        $http.post('api/delete',{action:'deleteAdv',advId:items}).then(function(r){
            var data = r.data;
            if(data.m == false){
                $('#alert-msg').removeClass('alert-danger');
                $('#alert-msg').addClass('alert-success');
                
                $scope.strongMsg = "Success: ";
                $scope.spanMsg = "Deleted successfully...";
                $scope.alertMsg = true
                 
            }else{
                $('#alert-msg').removeClass('alert-success');
                $('#alert-msg').addClass('alert-danger');
                
                $scope.strongMsg = "Error: ";
                $scope.spanMsg = "Deletion failed...";
                $scope.alertMsg = true
            }
            $uibModalInstance.dismiss('cancel');
            $('#advertisers').dataTable().fnDraw();
        });
    }
});

app.controller('viewCommentsCtrl', function($scope, $rootScope, $http, $compile, $uibModalInstance, items, toast ) {
    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };

    $http.post('api/',{action:'getCommentList',advId:items}).then(function(r){
        var data = r.data;
        if(data.error == false){
            $scope.tableDataNotAva = false;
            $scope.tableDataAva = true;
            $scope.eqList = data.msg;
            $rootScope.eqList = data.msg;
        }else{
            $scope.tableDataAva = false;
            $scope.tableDataNotAva = true;
        }
        
        $('#advertisers').dataTable().fnDraw();
    });
    jQuery('#comments').DataTable({
       "destroy" : true, 
    });
});
app.controller('ModalEnquiryCtrl',function($scope, $rootScope, $http, $compile, $uibModalInstance, items, toast) {
    $http.post('api/',{action:'getEnquiryList',advId:items}).then(function(r){
        var data = r.data;
        if(data.error == false){
            //console.log(data.msg)
            $scope.tableDataNotAva = false;
            $scope.tableDataAva = true;
            $scope.eqList = data.msg;
            $rootScope.eqList = data.msg;
        }else{
            $scope.tableDataAva = false;
            $scope.tableDataNotAva = true;
        }
        $('#advertisers').dataTable().fnDraw();
    });
    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
});

app.controller('ModalPhotoCtrl',function($scope,$rootScope,$http,$uibModalInstance,$timeout,items,toast,Upload) {
    
    $http.post('api/',{action:'getAdvertisersInfo',advId:items}).then(function(r){
        $rootScope.appUser = r.data;
        $scope.dbDatas = r.data;
    });
    
    $scope.deleteImg = function(fileName,i){
        $http.post('api/delete',{action:'deletAdvertisersImage',id:i,file:fileName,advId:items}).then(function(r){
            if(r.data.m===true){
                $rootScope.appUser['photo'+i]='';
                $rootScope.appUser['photo'+i+'a']='0';
                $scope.dbDatas['photo'+i]='';
                $scope.dbDatas['photo'+i+'a']='0';
            }else{alert(r.data.m)}
        });
    };
    //$cookies.getObject('userInfo',r.data.user);

	$scope.$watch('img1', function () { $scope.uploadFiles($scope.img1,1); });
    $scope.$watch('img2', function () { $scope.uploadFiles($scope.img2,2); });
    $scope.$watch('img3', function () { $scope.uploadFiles($scope.img3,3); });

	$scope.uploadFiles = function(file,count) {
        $scope.f = file;
        //$scope.errFile = errFiles && errFiles[0];
        if (file) {
            jQuery('#upProgress').show();
            file.upload=Upload.upload({url:'api/upload',data:{file:file,action:'uploadAdvPicture',count:count,advId:items}});

            file.upload.then(function (response) {
                if(response.data.m===true){
                    var img = response.data.img;
                    $rootScope.appUser['photo'+count]=img;
                    $rootScope.appUser['photo'+count+'a']='0';
                    $scope.dbDatas['photo'+count]=img;
                    $scope.dbDatas['photo'+count+'a']='0';
                }
                $timeout(function(){
                    jQuery('#upProgress').hide();
                },1000);
            }, function (response) {
                if (response.status > 0)
                    $scope.errorMsg = response.status + ': ' + response.data;
            }, function (evt) {
                file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
            });
        }   
    }
    
    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
}); 