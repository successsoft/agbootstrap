app.directive('asideMenu',function(){
    return function(scope, element){
        element.find('li').has('ul').addClass('hasSubMenu');
        var a=element.find('a');
        a.on('click',function(e){
            var t=jQuery(this),
                pli=t.parent('li'),
                _aa = pli.parent('ul').children('li').not(pli);
            if(t.attr('href')=='#'){
                _aa.find('ul').slideUp(200);
                t.next('ul').slideToggle(200);
                return false;
            }
        });
    };
});