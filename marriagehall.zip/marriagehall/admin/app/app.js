angular.module('Authentication',[]);
var app = angular.module('adminApp',
    ['Authentication','ui.router','ngCookies','angularScreenfull','ngAnimate','ngMessages','ui.bootstrap','ngFileUpload']);
app
.run(['$rootScope', '$location', '$cookieStore', '$http', '$state', '$stateParams',
function ($rootScope, $location, $cookieStore, $http, $state, $stateParams) {
    $rootScope.$state = $state;
    $rootScope.$stateParams = $stateParams;

    $.extend($.fn.dataTable.defaults, {
        "processing": true,
        "serverSide": true,
        "ajax": {"url": "api/json.php","type": "POST"},
        "iDisplayLength": 10,
        "pagingType": "full_numbers",
        "autoWidth": false,
        stateSave: true/**/
    });

    // keep user logged in after page refresh
    $rootScope.globals = $cookieStore.get('globals') || {};
    if ($rootScope.globals.currentUser) {
        $http.defaults.headers.common['Authorization'] = 'Basic '+$rootScope.globals.currentUser.authdata;

        $http.post('api/',{action:'getPageDatas'}).then(function(r){
            var op=r.data;
            $rootScope.languages = op.language;
            $rootScope.religion = op.religion;
            $rootScope.caste = op.caste;
            $rootScope.services = op.services;
        });
    }


    $rootScope.$on('$locationChangeStart',function(){
        if ($location.path() !== '/login' && !$rootScope.globals.currentUser) {
            $location.path('/login');
        }else{

        }
    });
}])
.config(function($stateProvider, $urlRouterProvider, $httpProvider){
    $urlRouterProvider.otherwise('/a/dashboard');
    $stateProvider.
    state('a',{
        abstract: true,
        url: '/a',
        templateUrl: 'app/tpl/app.html'
    }).
    state('a.dashboard',{
        url: '/dashboard',
        templateUrl: 'app/tpl/dashboard.html'
    }).
    state('a.members',{
        url: '/members',
        templateUrl: 'app/tpl/members.html',
        controller:'membersCtrl'
    }).
    state('a.advertisers',{
        url: '/advertisers',
        templateUrl: 'app/tpl/advertisers.html',
        controller:'advertisersCtrl'
    }).
    state('a.agents',{
        url: '/agents',
        templateUrl: 'app/tpl/agents.html',
        controller:'agentsCtrl'
    }).
    state('a.datas',{
        url: '/datas',
        templateUrl: 'app/tpl/manageData.html',
        controller:'dataCtrl'
    }).
    state('a.cms',{
        url: '/cms',
        templateUrl: 'app/tpl/cms.html',
        controller:'cmsCtrl'
    }).
    state('a.comments',{
        url: '/comments',
        templateUrl: 'app/tpl/comments.html',
        controller:'commentsCtrl'
    }).
    state('a.enquiry',{
        url: '/enquiry',
        templateUrl: 'app/tpl/enquiry.html',
        controller:'enquiryCtrl'
    }).
    state('a.theme',{
        url: '/theme',
        templateUrl: 'app/tpl/theme.html'
    }).
    state('login',{
        url: '/login',
        templateUrl: 'app/tpl/login.html'
    });

    $httpProvider.interceptors.push(function () {
        return {
            request:function(config){ return config; },
            response:function(response){ return response; },
            requestError:function(reqErr){ return reqErr; },
            responseError:function(resErr){ return resErr; }
        };
    });
});
app.controller('bodyCtrl',function($scope){
    $scope.toggleMenu=0;
    $scope.asideToggle=function(i){$scope.toggleMenu=i?0:1;};
});