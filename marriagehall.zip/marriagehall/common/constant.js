app.constant('userLabel',{
    "Basic Informations":{
        name: {label:"Name",type:'text'},
        gender: {label:"Gender",type:'radio'},
        dob: {label:"Date of Birth",type:'text'},
        maritalStatus: {label:"Marital Status",type:'radio'},
        noOChildren: {label:"No. of Childrens",type:''},
        cls: {label:"Children Living Status",type:''},
        language: {label:"Mother tongue",type:''},
        religion: {label:"Religion",type:''},
        caste: {label:"Caste",type:''},
        subCaste: {label:"Sub Caste",type:''},
        createdBy: {label:"Profile Created by",type:''},
        reference: {label:"Reference by",type:''}
    },
    "Socio Religious Attributes":{
        star: {label:"Star", type:''},
        moonsign: {label:"Moon Sign", type:''},
        gothram: {label:"Gothram", type:''},
        horosmatch: {label:"Horoscope Match", type:''},
        manglik: {label:"Manglik", type:''},
        pob: {label:"Place of Birth", type:''},
        tob: {label:"Time of Birth", type:''}
    },
    "Education and Occupation":{
        education: {label:"Education", type:''},
        educationInfo: {label:"Education Info", type:''},
        annualIncome: {label:"Annual Income", type:''},
        occupation: {label:"Occupation", type:''},
        occupationInfo: {label:"Occupation Info", type:''},
        employedIn: {label:"Employed In", type:''},
        currentCountry: {label:"Current Country", type:''}
    },
    "Physical Attributes":{
        height: {label:"Height", type:''},
        weight: {label:"Weight", type:''},
        blood: {label:"Blood Group", type:''},
        complexion: {label:"Complexion", type:''},
        bodyType: {label:"Body Type", type:''},
        diet: {label:"Diet", type:''},
        smoke: {label:"Smoke", type:''},
        drink: {label:"Drink", type:''}
    },
    "Contact Details":{
        address: {label:"Address", type:''},
        area: {label:"Area", type:''},
        country: {label:"Country", type:''},
        state: {label:"State", type:''},
        district: {label:"District", type:''},
        email: {label:"Email", type:''},
        phone: {label:"Phone", type:''},
        mobile: {label:"Mobile", type:''},
        residencyAs: {label:"Residency As", type:''}
    },
    "Family Details":{
        familyDetails: {label:"Family Details", type:''},
        familyValues: {label:"Family Values", type:''},
        familyType: {label:"Family Type", type:''},
        familyStatus: {label:"Family Status", type:''},
        familyOrigin: {label:"Family Origin", type:''},
        cLocation: {label:"Current Location", type:''},
        noOfBro: {label:"No. of Brothers", type:''},
        noOfSis: {label:"No. of Sisters", type:''},
        noOfBro_m: {label:"No. of Brothers Married", type:''},
        noOfSis_m: {label:"No. of Sisters Married", type:''}
    },
    "Father's Details":{
        fatherName: {label:"Father Name", type:''},
        dadLiveStat: {label:"Father Alive/", type:''},
        fOccupation: {label:"Father Occupation", type:''}
    },
    "Mother's Details":{
        motherName: {label:"Mother Name", type:''},
        momLiveStat: {label:"Father Alive?", type:''},
        mOccupation: {label:"Mother Occupation", type:''}
    },
    "Profile Details":{
        profile: {label:'', type:''}
    },
    "Partner Preference":{
        looking: {label:"Looking For", type:''},
        peFromAge: {label:"From Age", type:''},
        peToAge: {label:"To Age", type:''},
        pExpectations: {label:"Expectations", type:''},
        peCountry: {label:"Country Living in", type:''},
        peHeight: {label:"Height", type:''},
        peComplexion: {label:"Complexion", type:''},
        peEducation: {label:"Education", type:''},
        peReligion: {label:"Religion", type:''},
        peCaste: {label:"Caste", type:''},
        peResident: {label:"Resident Status", type:''},
        peIncome: {label:"Income", type:''}
    },
    "Hobbies and Interests":{
        hobbies: {label:"Hobbies", type:''},
        otherHobbies: {label:"Other Hobbies", type:''},
        interests: {label:"Interests", type:''},
        otherInterests: {label:"Other Interests", type:''}
    }
}).constant('options',{
   countries :['India','United States','Malaysia','Saudi Arabia','UAE','Sri Lanka','United Kingdom','South Africa','Canada','Mauritius','Nepal','Singapore','Kuwait','Andorra','Afghanistan','Antigua And Barbuda','Anguilla','Albania','Algeria','Angola','Argentina','American Samoa','Austria','Australia','Azerbaijan','Bosnia And Herzegovina','Barbados','Bangladesh','Belgium','Burkina Faso','Bulgaria','Bahrain','Burundi','Benin','Bermuda','Brunei Darussalam','Bolivia','Brazil','Bahamas','Bhutan','Bouvet Island','Botswana','Belarus','Belize','Cocos Islands','Congo The Democratic Republic','Central African Republic','Congo','Cote dlvoire','Cook Islands','Chile','Cameroon','Comoros','China','Colombia','Costa Rica','Czechoslovakia','Cuba','Cape Verde','Christmas Island','Cyprus','Czech Republic','Djibouti','Denmark','Dominica','Dominican Republic','Ecuador','Estonia','Egypt','Western Sahara','Eritrea','Spain','Ethiopia','Finland','Fiji','Falkland Islands (Malvinas)','Micronesia','Faroe Islands','France','France Metropolitan','Gabon','United Kingdom','Grenada','Georgia','French Guiana','Ghana','Gibraltar','Greenland','Gambia','Guinea','Germany','Guadeloupe','Equatorial Guinea','Greece','Guatemala','Guam','Guinea-bissau','Guyana','Hong Kong','Heard And Mcdona','Honduras','Croatia','Haiti','Hungary','Indonesia','Ireland','Israel','British Indian Ocean Territory','Iraq','Islamic Republic Of Iran','Iceland','Italy','Jamaica','Jordan','Japan','Kenya','Kyrgyzstan','Cambodia','Kiribati','St. Kitts And Nevis','North Korea','South Korea','Cayman Islands','Kazakhstan','Laos','Lebanon','Saint Lucia','Liechtenstein','Liberia','Lesotho','Lithuania','Luxembourg','Latvia','Libyan Arab Jamahiriya','Morocco','Monaco','Moldova','Madagascar','Marshall Islands','Macedonia','Mali','Myanmar','Mongolia','Macau','Northern Mariana Islands','Martinique','Mauritania','Montserrat','Malta','Maldives','Malawi','Mexico','Mozambique','Namibia','New Caledonia','Niger','Norfolk Island','Nigeria','Nicaragua','Netherlands Antilles','Netherlands','Norway','Nauru','Niue','New Zealand','Oman','Panama','Peru','French Polynesia','Papua New Guinea','Philippines','Pakistan','Poland','St. Pierre And Miquelon','Pitcairn','Puerto Rico','Portugal','Palau','Paraguay','Qatar','Reunion','Romania','Russian Federation','Rwanda','Solomon Islands','Seychelles','Sudan','Sweden','St. Helena','Slovenia','Svalbard And Jan Mayen Islands','Slovakia','Sierra Leone','San Marino','Senegal','Somalia','Switzerland','Suriname','Sao Tome And Principe','El Salvador','Syrian Arab Republic','Swaziland','Turks And Caicos Islands','Chad','Tanzania','Ukraine','Uganda','United States Minor Outlying Islands','Uruguay','Uzbekistan','Venezuela','Vietnam','Vanuatu','Wallis And Futuna','Samoa','Yemen','Mayotte','Yugoslavia','Zambia','Zimbabwe','Asia','Dubai'],
   education :{"Any Bachelors in Engineering / Computers":["Aeronautical Engineering","B.E/B.Tech","B.C.A","B.Arch","B.Sc IT / Computer Science"],"Any Masters in Engineering / Computers":["M.E/M.Tech","M.S(Engineering)","M.C.A","M.Arch","M.Sc IT / Computer Science"],"Any Bachelors in Arts / Science / Commerce":["BA","B.Com","B.Sc","B.Phil","B.Ed","B.H.M","B.COM(ACS)","Aviation Degree","BFA","BFT","BMM (MASS MEDIA)","BSW"],"Any Masters in Arts / Science / Commerce":["MA","M.Com","M.Sc.","M.Phil","M.Ed","MHM","M.P.Ed","M.S.W","MFA","MSc"],"Any Bachelors in Management":["BBA","MBA / PGDM / PGDBM","BBM","BFM (Financial Management)","BHM (Hotel Management"],"Any Masters in Management":["MBA","MBE","ACS","MFM (Financial Management)","MHM (Hotel Management)","MHRM (Human Resource Management)","PGDM"],"Any Bachelors in Medicine in General / Dental / Surgeon":["MBBS","BDS","BVSc","B.Pharm","BAMS","BHMS","BSMS","BPT","BUMS"],"Any Masters in Medicine - General / Dental / Surgeon":["MD/MS(Medical)","MDS","MVSc","MPT","M.Pharm","MD"],"Any Bachelors in Legal":["BL/BGL/LLB","BUS"],"Any Masters in Legal":["ML/LLM","MLIS"],"Any Financial Qualification - ICWAI / CA / CS/ CFA":["CA","ICWA","M.F.C","CFA (Chartered Financial Analyst)","CS"],"Service - IAS / IPS / IRS / IES / IFS":["IAS","IPS","IRS","IES","IFS"],"PhD":["Ph.D"],"Any Diploma":["Diploma","D.pharm","D.T.ED","Polytechnic","Trade School"],"Higher Secondary / Secondary":["High School / Higher Secondary / Below"],"Others":["Others","Nursing","Master Degree","MS/MD/MBA","BE/MCA","Any Degree","PG Degree","BE/B.TECH/ME/M.TECH","BE/MBA","BEM.S","BE/ME","B.E/M.E/MCA/M.SC/MBA","BE/MCA/MBA/CA","U.G Degree","MBBS/M D","Any Professional Degree","M.Tech/MS(Engg)/MD(Doctor)","BA,L.L.B","BE,M.S(USA)","BE,MS","B.Pharam","CC","Medical/IT professional","M.Res","Engineering master degree or doctor MD MS","ME,MBA,MS","Medical","B.D.S/M.D.S/M.B.B.S/M.D","Doctor or Engineer","MBBS,MD","MIB","B.S,M.S","B.A..M.S","B.H.,M.S"]},
   occupation:{"ADMIN":["Manager","Supervisor","Administrative Professional","Clerk","Human Resources Professional"],"AGRICULTURE":['Agriculture & Farming Professional'],"AIRLINE":['Pilot','Air Hostess','Airline Professional'],"ARCHITECT & DESIGN":['Architect','Interior Designer'],"BANKING & FINANCE":['Chartered Accountant','Company Secretary','Accounts/Finance Professional','Banking Service Professional','Auditor','Financial Accountant','Financial Analyst / Planning'],"BEAUTY & FASHION":['Fashion Designer','Beautician'],"CIVIL SERVICES":['Civil Services (IAS/IPS/IRS/IES/IFS)'],"DEFENCE":['Army','Navy','Airforce'],"EDUCATION":['Professor / Lecturer','Teaching / Academician','Education Professional'],"HOSPITALITY":['Hotel / Hospitality Professional'],"IT & ENGINEERING":['Software Professional','Hardware Professional','Engineer - Non IT','Designer - IT & Engineering'],"LEGAL":['Lawyer & Legal Professional'],"LAW ENFORCEMENT":['Law Enforcement Officer'],"MEDICAL":['Doctor','Health Care Professional','Paramedical Professional','Nurse'],"MARKETING & SALES":['Marketing Professional','Sales Professional'],"MEDIA & ENTERTAINMENT":['Journalist','Media Professional','Entertainment Professional','Event Management Professional','Advertising / PR Professional','Designer - Media & Entertainment'],"MERCHANT NAVY":['Mariner / Merchant Navy'],"SCIENTIST":['Scientist / Researcher'],"TOP MANAGEMENT":['CXO / President, Director, Chairman','Business Analyst'],"OTHERS":['Librarian','Student','Arts & Craftsman','Technician','Sportsman','Social Worker','Customer Care Professional','Consultant','Self Employed / Employed','Self Employed','Business Owner','Employed','Contract','Job Hunter','Unemployed']},
   stars:['Anusham','Aswini','Avittam','Ayilyam','Bharani','Chithirai','Hastham','Kettai','Krithigai','Maham','Moolam','Mrigasirisham','Poosam','Punarpusam','Puradam','Puram','Puratathi','Revathi','Rohini','Sadayam','Swathi','Thiruvadirai','Thiruvonam','Uthradam','Uthram','Uthratadhi','Visakam'],
   raasi:{'Aries':'Mesh','Taurus':'Vrishabh','Gemini':'Mithun','Cancer':'Karka','Leo':'Simha','Virgo':'Kanya','Libra':'Tula','Scorpio':'Vrischika','Sagittarius':'Dhanu','Capricorn':'Makar','Aquarius':'Kumbha','Pisces':'Meen'},
   blood:['Dont Know','A+','A-','A1 +','A1 -','A1B +','A1B -','A2 +','A2 -','A2B +','A2B -','AB+','AB-','B+','B-','O+','O-']
});