<?php
//$sql_details = array('user'=>'manojkum_mat','pass'=>'+ze9h{Trg#&3','db'=>'manojkum_matrimony','host'=>'localhost');
//$sql_details = array('user'=>'marriage_xcpout','pass'=>'9XO0n#T%y{u.','db'=>'marriage_xcpinp','host'=>'localhost');
$sql_details = array('user'=>'root','pass'=>'','db'=>'marriagehall','host'=>'192.168.1.33');
$connect  = mysql_connect("localhost",$sql_details['user'],$sql_details['pass']);
$selectDB = mysql_select_db($sql_details['db'], $connect);
date_default_timezone_set('Asia/Kolkata');
?>